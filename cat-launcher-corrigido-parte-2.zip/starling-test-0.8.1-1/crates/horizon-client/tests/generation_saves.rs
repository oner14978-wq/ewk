//! Streaming keeps generation consistent when the player leaves an area and
//! comes back, and across a restart (#249): every column is finished once,
//! after its own decoration and its eight neighbours', and chunks that
//! decoration wrote to are saved rather than generated again without those
//! writes. Bastions lost whole chunks of pieces this way.
extern crate horizon_client_lib as horizon_client;
use horizon_client::{
    assets::Assets,
    biome::Biomes,
    blocks::BlockFacts,
    chunk::Chunk,
    light::LightTables,
    mesher::MeshTables,
    models,
    streaming::{ChunkGenerator, Proto, Streaming, WorkerContext},
    world::World,
};
use horizon_world::{native_load_context::DataLoadOrigin, registry::BlockStateId};
#[path = "../src/test_resources.rs"]
mod test_resources;
use std::{
    collections::HashMap,
    path::Path,
    sync::{Arc, Mutex},
    thread,
    time::{Duration, Instant},
};

fn resources() -> Option<std::path::PathBuf> {
    let root = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../../.local/horizon-client")
        .join(horizon_core::VANILLA_VERSION);
    root.join("items.json").exists().then_some(root)
}

/// A proto chunk that records the decorations that wrote to it.
#[derive(Clone)]
struct Recorded {
    x: i32,
    z: i32,
    decorated: bool,
    writes: Vec<(i32, i32)>,
}
/// Generation with an in-memory save, like `Persistent`.
#[derive(Default)]
struct Recorder {
    protos: Mutex<HashMap<(i32, i32), Recorded>>,
    chunks: Mutex<HashMap<(i32, i32), Chunk>>,
    /// Each column as it was when it was finished, once per finish.
    finished: Mutex<HashMap<(i32, i32), Vec<Recorded>>>,
    /// The proto chunks a light job was given a view of, as they were.
    viewed: Mutex<Vec<Recorded>>,
}
impl Recorder {
    fn save_chunk(&self, chunk: &Chunk) {
        let mut saved = chunk.clone();
        saved.fresh = false;
        saved.generated = false;
        self.chunks
            .lock()
            .unwrap()
            .insert((chunk.x, chunk.z), saved);
    }
}
impl ChunkGenerator for Recorder {
    type Worker = ();
    fn worker(&self) {}
    fn load(&self, x: i32, z: i32) -> Option<Chunk> {
        self.chunks.lock().unwrap().get(&(x, z)).cloned()
    }
    fn proto(&self, _: &mut (), x: i32, z: i32) -> Proto {
        let saved = self.protos.lock().unwrap().get(&(x, z)).cloned();
        Box::new(saved.unwrap_or(Recorded {
            x,
            z,
            decorated: false,
            writes: Vec::new(),
        }))
    }
    fn decorates(&self) -> bool {
        true
    }
    fn decorate(&self, _: &mut (), region: &mut [Proto; 9]) {
        let center = region[4].downcast_ref::<Recorded>().unwrap();
        let center = (center.x, center.z);
        for proto in region.iter_mut() {
            proto
                .downcast_mut::<Recorded>()
                .unwrap()
                .writes
                .push(center);
        }
        region[4].downcast_mut::<Recorded>().unwrap().decorated = true;
    }
    fn finish(&self, proto: Proto) -> Chunk {
        let proto = proto.downcast::<Recorded>().unwrap();
        let mut chunk = Chunk::empty(proto.x, proto.z);
        chunk.fresh = true;
        self.finished
            .lock()
            .unwrap()
            .entry((proto.x, proto.z))
            .or_default()
            .push(*proto);
        chunk
    }
    fn is_decorated(&self, proto: &Proto) -> bool {
        proto.downcast_ref::<Recorded>().unwrap().decorated
    }
    fn light_view(&self, proto: &Proto) -> Option<Chunk> {
        let proto = proto.downcast_ref::<Recorded>().unwrap();
        self.viewed.lock().unwrap().push(proto.clone());
        Some(Chunk::empty(proto.x, proto.z))
    }
    fn save_protos(&self, protos: &[&Proto]) {
        let mut saved = self.protos.lock().unwrap();
        for proto in protos {
            let proto = proto.downcast_ref::<Recorded>().unwrap();
            saved.insert((proto.x, proto.z), proto.clone());
        }
    }
    fn save_finished(&self, chunk: Chunk) {
        self.save_chunk(&chunk);
    }
}

/// The game's part: columns saved when they unload and when the world saves.
struct Session {
    streaming: Streaming,
    world: World,
    generator: Arc<Recorder>,
}
impl Session {
    fn new(generator: Arc<Recorder>, context: Arc<WorkerContext>) -> Self {
        let mut streaming = Streaming::new(generator.clone(), context, 3);
        streaming.radius = 4;
        Self {
            streaming,
            world: World::new(BlockStateId(0), 0),
            generator,
        }
    }
    fn update(&mut self) {
        let (_, unloaded) = self.streaming.update(&mut self.world);
        for chunk in unloaded {
            if self.world.modified.remove(&(chunk.x, chunk.z)) {
                self.generator.save_chunk(&chunk);
            }
        }
    }
    /// Run until generation around `center` is done and nothing changes.
    fn settle_at(&mut self, center: (i32, i32)) {
        self.streaming.center = center;
        let deadline = Instant::now() + Duration::from_secs(120);
        let mut quiet = 0;
        while quiet < 40 {
            assert!(Instant::now() < deadline, "generation never settled");
            let before = (self.streaming.generated_total, self.world.chunks.len());
            self.update();
            thread::sleep(Duration::from_millis(5));
            let idle = !self.streaming.busy()
                && before == (self.streaming.generated_total, self.world.chunks.len());
            quiet = if idle { quiet + 1 } else { 0 };
        }
    }
    /// The autosave: proto chunks are saved on a worker, nothing waits.
    fn autosave(&mut self) {
        self.streaming.save(&mut self.world, false);
    }
    fn save(&mut self) {
        let deadline = Instant::now() + Duration::from_secs(120);
        'save: loop {
            assert!(Instant::now() < deadline, "incremental save never finished");
            let tick_deadline = Instant::now() + Duration::from_millis(2);
            loop {
                match self
                    .streaming
                    .prepare_poll_save(&mut self.world, tick_deadline)
                {
                    horizon_client::streaming::SaveStep::Pending => break,
                    horizon_client::streaming::SaveStep::Full(chunk) => {
                        self.streaming.save_finished(chunk)
                    }
                    horizon_client::streaming::SaveStep::Protos(protos) => {
                        if self.streaming.submit_protos(protos) {
                            break 'save;
                        }
                        break;
                    }
                }
            }
            thread::sleep(Duration::from_millis(1));
        }
        for key in std::mem::take(&mut self.world.modified) {
            if let Some(chunk) = self.world.chunks.get(&key) {
                self.generator.save_chunk(chunk);
            }
        }
    }
}

fn worker_context(root: &Path) -> Arc<WorkerContext> {
    let assets = Arc::new(Assets::load(root).unwrap());
    let render = Arc::new(
        assets
            .reload(&horizon_assets::resource_source::ResourceRoot::directory(
                root.to_path_buf(),
            ))
            .unwrap(),
    );
    let facts = BlockFacts::load(root, assets.registry).unwrap();
    let visibility = models::load_visibility(root, assets.registry).unwrap();
    Arc::new(WorkerContext {
        tables: Arc::new(MeshTables::new(&assets, &render, &facts, visibility, None).unwrap()),
        light: Arc::new(LightTables::load(root, assets.registry, &facts).unwrap()),
        biomes: Arc::new(
            Biomes::load(&horizon_assets::resource_source::ResourceRoot::directory(
                root.to_path_buf(),
            ))
            .unwrap(),
        ),
        assets,
        render: render.clone(),
        hidden_states: Arc::from([]),
    })
}

/// What native mods hear (`native_chunk_load`): a column just generated is
/// new, one read back from the save isn't, and each arrival is told once.
#[test]
fn a_new_column_is_told_apart_from_a_saved_one() {
    let Some(root) = resources() else {
        return;
    };
    let context = worker_context(&root);
    let generator = Arc::new(Recorder::default());
    let mut session = Session::new(generator.clone(), context.clone());
    session.settle_at((0, 0));
    let first = std::mem::take(&mut session.world.loaded_chunks);
    assert!(first.contains(&(0, 0, true)), "{first:?}");
    assert!(first.iter().all(|c| c.2), "{first:?}");
    let residents = session.world.chunks.len();
    assert_eq!(first.len(), residents, "one arrival for each column");
    session.save();
    drop(session);
    let mut session = Session::new(generator, context);
    session.settle_at((0, 0));
    let again = std::mem::take(&mut session.world.loaded_chunks);
    assert!(again.contains(&(0, 0, false)), "{again:?}");
}

#[test]
fn chunks_left_behind_keep_their_decoration() {
    let Some(root) = resources() else {
        return;
    };
    let context = worker_context(&root);
    let generator = Arc::new(Recorder::default());
    let mut session = Session::new(generator.clone(), context.clone());
    // Generate an area, walk away from it in steps (its edge unloads a ring
    // at a time), teleport far, come back past where the edge was; then
    // save, restart and look again.
    session.settle_at((0, 0));
    for step in 1..=4 {
        session.settle_at((step * 3, 0));
        session.autosave();
    }
    session.settle_at((300, 300));
    session.autosave();
    session.settle_at((0, 0));
    session.settle_at((-4, 0));
    session.save();
    drop(session);
    let mut session = Session::new(generator.clone(), context);
    session.settle_at((6, 0));
    session.settle_at((0, 0));
    let finished = generator.finished.lock().unwrap();
    let mut checked = 0;
    for (&(x, z), finishes) in finished.iter() {
        assert_eq!(
            finishes.len(),
            1,
            "({x}, {z}) was generated again after it was finished"
        );
        let column = &finishes[0];
        assert!(column.decorated, "({x}, {z}) was finished undecorated");
        let mut writes = column.writes.clone();
        writes.sort_unstable();
        let neighbours: Vec<(i32, i32)> = (-1..=1)
            .flat_map(|dx| (-1..=1).map(move |dz| (x + dx, z + dz)))
            .collect();
        assert_eq!(
            writes, neighbours,
            "({x}, {z}) must hold each neighbour's decoration exactly once"
        );
        checked += 1;
    }
    for x in -4..=4 {
        for z in (-4..=4).filter(|z| x * x + z * z <= 16) {
            assert!(
                session.world.chunks.contains_key(&(x, z)),
                "({x}, {z}) did not load back"
            );
        }
    }
    assert!(checked > 200, "only {checked} columns finished");
}

/// The columns at the edge light against their decorated neighbours past
/// the area; each such proto chunk is turned into a view once while it stays
/// as it is, however many columns it neighbours or light jobs wait on it.
#[test]
fn proto_chunks_are_viewed_once_per_state() {
    let Some(root) = resources() else {
        return;
    };
    let assets = Arc::new(Assets::load(&root).unwrap());
    let render = Arc::new(
        assets
            .reload(&horizon_assets::resource_source::ResourceRoot::directory(
                root.to_path_buf(),
            ))
            .unwrap(),
    );
    let facts = BlockFacts::load(&root, assets.registry).unwrap();
    let visibility = models::load_visibility(&root, assets.registry).unwrap();
    let context = Arc::new(WorkerContext {
        tables: Arc::new(MeshTables::new(&assets, &render, &facts, visibility, None).unwrap()),
        light: Arc::new(LightTables::load(&root, assets.registry, &facts).unwrap()),
        biomes: Arc::new(
            Biomes::load(&horizon_assets::resource_source::ResourceRoot::directory(
                root.to_path_buf(),
            ))
            .unwrap(),
        ),
        assets,
        render: render.clone(),
        hidden_states: Arc::from([]),
    });
    let generator = Arc::new(Recorder::default());
    let mut session = Session::new(generator.clone(), context);
    for step in 0..=4 {
        session.settle_at((step * 3, 0));
    }
    let viewed = generator.viewed.lock().unwrap();
    let mut states: Vec<((i32, i32), Vec<(i32, i32)>)> = viewed
        .iter()
        .map(|p| ((p.x, p.z), p.writes.clone()))
        .collect();
    let total = states.len();
    states.sort_unstable();
    states.dedup();
    assert!(total > 20, "only {total} proto chunks were viewed");
    assert_eq!(
        states.len(),
        total,
        "a proto chunk was viewed again unchanged"
    );
}

/// A saved proto chunk comes back exactly: the bastion region of #249, its
/// centre decorated (writing into all nine chunks), saved and restored onto
/// chunks generated again finishes into the same columns.
#[test]
fn saved_proto_chunks_restore_exactly() {
    use horizon_client::{
        save::{Persistent, SaveDir},
        vanillagen::VanillaTerrain,
    };
    let Some(root) = resources() else {
        return;
    };
    let assets = Arc::new(Assets::load(&root).unwrap());
    let biomes = Arc::new(
        Biomes::load(&horizon_assets::resource_source::ResourceRoot::directory(
            root.to_path_buf(),
        ))
        .unwrap(),
    );
    let item_data = test_resources::item_data(&root, DataLoadOrigin::ServerDataLoad).unwrap();
    let terrain = VanillaTerrain::for_dimension(
        horizon_client::vanillagen::TerrainResources {
            data: None,
            dir: &root.join("worldgen"),
            registry: assets.registry,
            biomes: &biomes,
            item_data: &item_data,
        },
        -1860902098141295193,
        "minecraft:the_nether",
    )
    .unwrap();
    let dir = std::env::temp_dir().join(format!("horizon-proto-saves-{}", std::process::id()));
    let _ = std::fs::remove_dir_all(&dir);
    let save = Arc::new(SaveDir::new(
        dir.clone(),
        horizon_client::save::LevelShape::OVERWORLD,
    ));
    let generator = Persistent {
        inner: Arc::new(terrain),
        save: save.clone(),
        registry: assets.clone(),
        biomes,
    };
    let mut worker = generator.worker();
    let keys: Vec<(i32, i32)> = (0..9).map(|i| (3 + i % 3 - 1, 7 + i / 3 - 1)).collect();
    let mut region: [Proto; 9] =
        std::array::from_fn(|i| generator.proto(&mut worker, keys[i].0, keys[i].1));
    generator.decorate(&mut worker, &mut region);
    assert!(generator.is_decorated(&region[4]));
    generator.save_protos(&region.iter().collect::<Vec<_>>());
    let mut seeded = generator.inner.saved_proto(&region[4]).unwrap();
    let extras = seeded.column.saved.get_or_insert_with(Default::default);
    let extras = Arc::make_mut(extras);
    extras
        .root
        .insert("example:unknown".into(), horizon_core::nbt::Tag::Int(42));
    let attachment = horizon_core::nbt::Compound::from_iter([(
        "example:data".into(),
        horizon_core::nbt::Tag::Int(9),
    )]);
    extras.attachments =
        horizon_mod_runtime::attachments::Attachments::from_nbt(attachment.clone());
    save.save_protos(vec![seeded], assets.registry, &generator.biomes)
        .unwrap();
    save.flush().unwrap();
    let mut restored: [Proto; 9] = std::array::from_fn(|i| {
        let (x, z) = keys[i];
        generator.proto(&mut worker, x, z)
    });
    // Decoration mutates the checked-out region after the unknown key is restored.
    generator.decorate(&mut worker, &mut region);
    generator.decorate(&mut worker, &mut restored);
    generator.save_protos(&[&restored[4]]);
    save.flush().unwrap();
    let proto = save
        .load_proto(keys[4].0, keys[4].1, assets.registry, &generator.biomes)
        .unwrap();
    assert_eq!(
        proto
            .column
            .saved
            .as_ref()
            .unwrap()
            .root
            .get(&"example:unknown".into()),
        Some(&horizon_core::nbt::Tag::Int(42))
    );
    assert_eq!(
        proto.column.saved.as_ref().unwrap().attachments.to_nbt(),
        attachment
    );
    for (i, (original, restored)) in region.into_iter().zip(restored).enumerate() {
        assert_eq!(generator.is_decorated(&restored), i == 4);
        let (a, b) = (generator.finish(original), generator.finish(restored));
        let (x, z) = keys[i];
        if i == 4 {
            save.save(&[Arc::new(b.clone())], assets.registry, &generator.biomes)
                .unwrap();
            let loaded = save.load(x, z, assets.registry, &generator.biomes).unwrap();
            let extras = loaded.saved.unwrap();
            assert_eq!(
                extras.root.get(&"example:unknown".into()),
                Some(&horizon_core::nbt::Tag::Int(42))
            );
            assert_eq!(extras.attachments.to_nbt(), attachment);
        }
        for y in horizon_client::chunk::MIN_Y..horizon_client::chunk::MIN_Y + 384 {
            for lz in 0..16 {
                for lx in 0..16 {
                    assert_eq!(
                        a.get(lx, y, lz),
                        b.get(lx, y, lz),
                        "block {} {y} {} differs",
                        x * 16 + lx,
                        z * 16 + lz
                    );
                }
            }
        }
        assert_eq!(
            format!("{:?}", a.block_entities),
            format!("{:?}", b.block_entities)
        );
        assert_eq!(a.postprocess, b.postprocess, "chunk {x} {z}");
        assert_eq!(a.entities, b.entities, "chunk {x} {z}");
        assert_eq!(a.structure_refs, b.structure_refs, "chunk {x} {z}");
        let ticks = |c: &Chunk| {
            c.saved
                .as_ref()
                .map(|s| (s.block_ticks.clone(), s.fluid_ticks.clone()))
                .unwrap_or_default()
        };
        assert_eq!(ticks(&a), ticks(&b), "chunk {x} {z}");
    }
    drop(generator);
    drop(save);
    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn saved_proto_block_entities_keep_their_id() {
    use horizon_client::{
        save::{Persistent, SaveDir},
        vanillagen::VanillaTerrain,
    };
    use {
        horizon_core::nbt::{Limits, Tag},
        horizon_world::region::RegionFile,
    };
    let Some(root) = resources() else {
        return;
    };
    let assets = Arc::new(Assets::load(&root).unwrap());
    let biomes = Arc::new(
        Biomes::load(&horizon_assets::resource_source::ResourceRoot::directory(
            root.to_path_buf(),
        ))
        .unwrap(),
    );
    let item_data = test_resources::item_data(&root, DataLoadOrigin::ServerDataLoad).unwrap();
    let terrain = VanillaTerrain::for_dimension(
        horizon_client::vanillagen::TerrainResources {
            data: None,
            dir: &root.join("worldgen"),
            registry: assets.registry,
            biomes: &biomes,
            item_data: &item_data,
        },
        12345,
        "minecraft:overworld",
    )
    .unwrap();
    let dir = std::env::temp_dir().join(format!("horizon-proto-ids-{}", std::process::id()));
    let _ = std::fs::remove_dir_all(&dir);
    let save = Arc::new(SaveDir::new(
        dir.clone(),
        horizon_client::save::LevelShape::OVERWORLD,
    ));
    let generator = Persistent {
        inner: Arc::new(terrain),
        save: save.clone(),
        registry: assets.clone(),
        biomes,
    };
    let mut worker = generator.worker();
    // A cold ocean ruin of seed 12345: its suspicious gravel is placed with a
    // loot table and no type.
    let keys: Vec<(i32, i32)> = (0..9).map(|i| (43 + i % 3 - 1, 21 + i / 3 - 1)).collect();
    let mut region: [Proto; 9] =
        std::array::from_fn(|i| generator.proto(&mut worker, keys[i].0, keys[i].1));
    generator.decorate(&mut worker, &mut region);
    generator.save_protos(&region.iter().collect::<Vec<_>>());
    save.flush().unwrap();
    let mut file = RegionFile::open(dir.join("region/r.1.0.mca")).unwrap();
    let mut suspicious = 0;
    for &(x, z) in &keys {
        let Some(record) = file
            .read(horizon_core::position::ChunkPos::new(x, z))
            .unwrap()
        else {
            continue;
        };
        let root = record.nbt(Limits::default()).unwrap();
        let Some(Tag::List(entities)) = root.tag.get("block_entities") else {
            continue;
        };
        for e in entities {
            assert!(e.get("id").is_some(), "chunk {x} {z}: {e:?}");
            if let Some(Tag::String(table)) = e.get("LootTable") {
                suspicious += usize::from(table.to_string_lossy().contains("archaeology/"));
            }
        }
    }
    assert!(suspicious > 0, "the ruin placed no suspicious blocks");
    drop(generator);
    drop(save);
    let _ = std::fs::remove_dir_all(&dir);
}

/// What the game's generator, `Persistent`, passes on of beside-final decoration: the block
/// entities a decoration made in a chunk saved by an older version reach `World` only if
/// `Persistent` forwards `final_block_entities` (the trait default is none).
#[test]
fn persistent_forwards_the_block_entities_decoration_made_in_a_final_chunk() {
    use horizon_client::{
        chunk::block_entity::BlockEntity,
        save::{Persistent, SaveDir},
    };
    struct Marked;
    impl ChunkGenerator for Marked {
        type Worker = ();
        fn worker(&self) {}
        fn proto(&self, _: &mut (), _: i32, _: i32) -> Proto {
            Box::new(())
        }
        fn finish(&self, _: Proto) -> Chunk {
            Chunk::empty(0, 0)
        }
        fn final_block_entities(
            &self,
            entries: &[(&Proto, &[([i32; 3], u32)])],
        ) -> Vec<((i32, i32, i32), BlockEntity)> {
            entries
                .iter()
                .flat_map(|(_, writes)| writes.iter())
                .map(|([x, y, z], _)| ((*x, *y, *z), BlockEntity::Chest(Vec::new())))
                .collect()
        }
    }
    let Some(root) = resources() else {
        return;
    };
    let assets = Arc::new(Assets::load(&root).unwrap());
    let biomes = Arc::new(
        Biomes::load(&horizon_assets::resource_source::ResourceRoot::directory(
            root.to_path_buf(),
        ))
        .unwrap(),
    );
    let dir = std::env::temp_dir().join(format!("horizon-final-be-{}", std::process::id()));
    let _ = std::fs::remove_dir_all(&dir);
    let generator = Persistent {
        inner: Arc::new(Marked),
        save: Arc::new(SaveDir::new(
            dir.clone(),
            horizon_client::save::LevelShape::OVERWORLD,
        )),
        registry: assets,
        biomes,
    };
    let proto = Box::new(()) as Proto;
    let made = generator.final_block_entities(&[(&proto, &[([1, 64, 2], 5)])]);
    assert_eq!(made.len(), 1, "Persistent drops the block entities");
    assert_eq!(made[0].0, (1, 64, 2));
    let _ = std::fs::remove_dir_all(&dir);
}

/// `NoiseGeneratorSettings.disableMobGeneration` reaches the client's
/// `spawnOriginalMobs` gate from the shipped presets: the End asks for no
/// creature packs at generation and the overworld and nether ask for them.
#[test]
fn the_end_asks_for_no_creature_packs_and_the_overworld_does() {
    use horizon_client::{assets::Assets, biome::Biomes, vanillagen::VanillaTerrain};
    let Some(root) = resources() else {
        return;
    };
    let assets = Arc::new(Assets::load(&root).unwrap());
    let biomes = Arc::new(
        Biomes::load(&horizon_assets::resource_source::ResourceRoot::directory(
            root.clone(),
        ))
        .unwrap(),
    );
    let item_data = test_resources::item_data(&root, DataLoadOrigin::ServerDataLoad).unwrap();
    for (dimension, want) in [
        ("minecraft:overworld", false),
        ("minecraft:the_nether", false),
        ("minecraft:the_end", true),
    ] {
        let terrain = VanillaTerrain::for_dimension(
            horizon_client::vanillagen::TerrainResources {
                data: None,
                dir: &root.join("worldgen"),
                registry: assets.registry,
                biomes: &biomes,
                item_data: &item_data,
            },
            12345,
            dimension,
        )
        .unwrap();
        assert_eq!(
            terrain.disable_mob_generation(),
            want,
            "disable_mob_generation of {dimension}"
        );
    }
}
