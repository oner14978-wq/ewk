//! Every column the player comes close to gets meshed (#228): columns that
//! load with their light, past the render distance, used to drop their
//! sections' mesh requests there, and nothing asked again once the player
//! came closer, so they stayed invisible until a block in them changed.
//! Relit columns remesh only where their light changed (#270), and every
//! mesh still matches the world.
extern crate horizon_client_lib as horizon_client;
use horizon_client::{
    assets::Assets,
    biome::Biomes,
    blocks::BlockFacts,
    chunk::{Chunk, HEIGHT},
    graphics::LeafCullingMode,
    light::LightTables,
    mesher::{MeshTables, Mesher, Region, SectionMesh, borrow},
    models,
    streaming::{ChunkGenerator, Proto, Streaming, WorkerContext},
    world::World,
};
use horizon_core::biome::BiomeZoom;
use horizon_world::registry::BlockStateId;
use std::{
    collections::{HashMap, HashSet},
    path::Path,
    sync::Arc,
    thread,
    time::{Duration, Instant},
};

fn resources() -> Option<std::path::PathBuf> {
    let root = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../../.local/horizon-client")
        .join(horizon_core::VANILLA_VERSION);
    root.join("items.json").exists().then_some(root)
}

/// A saved world: every column loads with its light, as saved chunks do.
struct Saved;
impl ChunkGenerator for Saved {
    type Worker = ();
    fn worker(&self) {}
    fn load(&self, x: i32, z: i32) -> Option<Chunk> {
        let mut chunk = Chunk::empty(x, z);
        chunk.lit = true;
        chunk.light_loaded = true;
        Some(chunk)
    }
    fn proto(&self, _: &mut (), _: i32, _: i32) -> Proto {
        unreachable!("every column is saved")
    }
    fn finish(&self, _: Proto) -> Chunk {
        unreachable!("every column is saved")
    }
}

#[test]
fn columns_loaded_past_the_render_distance_mesh_when_they_come_in_range() {
    let Some(root) = resources() else {
        return;
    };
    let assets = Arc::new(Assets::load(&root).unwrap());
    let render = Arc::new(
        assets
            .reload(&horizon_assets::resource_source::ResourceRoot::directory(
                root.to_path_buf(),
            ))
            .unwrap(),
    );
    let facts = BlockFacts::load(&root, assets.registry).unwrap();
    let visibility = models::load_visibility(&root, assets.registry).unwrap();
    let context = Arc::new(WorkerContext {
        tables: Arc::new(MeshTables::new(&assets, &render, &facts, visibility, None).unwrap()),
        light: Arc::new(LightTables::load(&root, assets.registry, &facts).unwrap()),
        biomes: Arc::new(
            Biomes::load(&horizon_assets::resource_source::ResourceRoot::directory(
                root.to_path_buf(),
            ))
            .unwrap(),
        ),
        assets,
        render: render.clone(),
        hidden_states: Arc::from([]),
    });
    let mut streaming = Streaming::new(Arc::new(Saved), context, 3);
    streaming.radius = 4;
    let mut world = World::new(BlockStateId(0), 0);
    let mut meshed = HashSet::new();
    let settle_at = |streaming: &mut Streaming,
                     world: &mut World,
                     center: (i32, i32),
                     meshed: &mut HashSet<(i32, i32, i32)>| {
        streaming.center = center;
        let deadline = Instant::now() + Duration::from_secs(60);
        let mut quiet = 0;
        while quiet < 40 {
            assert!(Instant::now() < deadline, "streaming never settled");
            let before = (world.chunks.len(), meshed.len());
            let (uploads, _) = streaming.update(world);
            meshed.extend(uploads.iter().map(|(key, _)| *key));
            // As the game does once they are uploaded: a worker frees them,
            // and nothing comes back (`pending` empties).
            streaming.free(uploads);
            thread::sleep(Duration::from_millis(5));
            let idle = !streaming.busy() && before == (world.chunks.len(), meshed.len());
            quiet = if idle { quiet + 1 } else { 0 };
        }
    };
    // Columns up to three chunks past the render distance load around the
    // first position; the second brings some of them within it.
    settle_at(&mut streaming, &mut world, (0, 0), &mut meshed);
    settle_at(&mut streaming, &mut world, (3, 0), &mut meshed);
    let (cx, cz): (i32, i32) = (3, 0);
    let all_in_range = |meshed: &HashSet<(i32, i32, i32)>| {
        let mut checked = 0;
        for x in cx - 4..=cx + 4 {
            for z in cz - 4..=cz + 4 {
                if (x - cx).pow(2) + (z - cz).pow(2) > 16 {
                    continue;
                }
                for sy in 0..HEIGHT / 16 {
                    assert!(
                        meshed.contains(&(x, sy, z)),
                        "section {x} {sy} {z} is in range but was never meshed"
                    );
                }
                checked += 1;
            }
        }
        checked
    };
    assert_eq!(all_in_range(&meshed), 49);

    // `LevelExtractor.allChanged` (F3+A and a changed render distance) drops
    // every displayed section. Streaming must produce all of them again.
    meshed.clear();
    streaming.reload_sections(&mut world);
    settle_at(&mut streaming, &mut world, (3, 0), &mut meshed);
    assert_eq!(all_in_range(&meshed), 49);
}

/// A one-block cave under the sky: a stone floor at y 62 with a glowstone,
/// and a roof at y 64 with holes, so that every light change in the cave is
/// sampled by a face.
fn roofed(x: i32, z: i32, stone: u32, glowstone: u32) -> Chunk {
    let mut chunk = Chunk::empty(x, z);
    for lz in 0..16 {
        for lx in 0..16 {
            chunk.set(lx, 62, lz, stone);
            if (lx + 3 * lz + x * 5 + z * 7).rem_euclid(11) != 0 {
                chunk.set(lx, 64, lz, stone);
            }
        }
    }
    chunk.set(
        (x * 3).rem_euclid(16),
        62,
        (z * 5).rem_euclid(16),
        glowstone,
    );
    chunk
}

/// A column that changes next to lit ones relights them, and remeshes only
/// where their light changed (#270): every mesh still matches the world,
/// before and after the missing column arrives.
#[test]
fn relit_columns_keep_every_mesh_current() {
    let Some(root) = resources() else {
        return;
    };
    let assets = Arc::new(Assets::load(&root).unwrap());
    let render = Arc::new(
        assets
            .reload(&horizon_assets::resource_source::ResourceRoot::directory(
                root.to_path_buf(),
            ))
            .unwrap(),
    );
    let facts = BlockFacts::load(&root, assets.registry).unwrap();
    let visibility = models::load_visibility(&root, assets.registry).unwrap();
    let context = Arc::new(WorkerContext {
        tables: Arc::new(MeshTables::new(&assets, &render, &facts, visibility, None).unwrap()),
        light: Arc::new(LightTables::load(&root, assets.registry, &facts).unwrap()),
        biomes: Arc::new(
            Biomes::load(&horizon_assets::resource_source::ResourceRoot::directory(
                root.to_path_buf(),
            ))
            .unwrap(),
        ),
        assets: assets.clone(),
        render: render.clone(),
        hidden_states: Arc::from([]),
    });
    let state = |name: &str| assets.registry.default_state(name).unwrap().0;
    let (stone, glowstone, torch) = (
        state("minecraft:stone"),
        state("minecraft:glowstone"),
        state("minecraft:torch"),
    );
    // Columns from a server, one of them not sent yet. They keep the light
    // the server sent (#824, as vanilla's `enableChunkLight`), so its
    // neighbours are lit too.
    let mut streaming = Streaming::new(Arc::new(Saved), context.clone(), 3);
    streaming.radius = 4;
    streaming.remote = true;
    let mut world = World::new(BlockStateId(0), 0);
    for x in -5..=5 {
        for z in -5..=5 {
            if (x, z) != (2, 0) {
                streaming.insert_remote(&mut world, roofed(x, z, stone, glowstone));
            }
        }
    }
    let mut meshes: HashMap<(i32, i32, i32), SectionMesh> = HashMap::new();
    let mut settle = |streaming: &mut Streaming, world: &mut World| {
        let deadline = Instant::now() + Duration::from_secs(60);
        let mut quiet = 0;
        while quiet < 40 {
            assert!(Instant::now() < deadline, "streaming never settled");
            let (uploads, _) = streaming.update(world);
            let idle = uploads.is_empty() && !streaming.busy();
            meshes.extend(uploads);
            thread::sleep(Duration::from_millis(5));
            quiet = if idle { quiet + 1 } else { 0 };
        }
    };
    settle(&mut streaming, &mut world);
    assert!(streaming.is_lit(1, 0) && streaming.is_lit(0, 0));
    // Open the roof and put torches in the cave on a ring two blocks inside
    // the unlit (1, 0): its lit neighbours are relit, and their meshes change
    // only through light (no edit is next to them).
    for i in 2..14 {
        for (lx, lz) in [(i, 2), (i, 13), (2, i), (13, i)] {
            let (bx, bz) = (16 + lx, lz);
            world.set(bx, 64, bz, BlockStateId(0)).unwrap();
            if i % 3 == 0 {
                world.set(bx, 63, bz, BlockStateId(torch)).unwrap();
            }
        }
    }
    settle(&mut streaming, &mut world);
    streaming.insert_remote(&mut world, roofed(2, 0, stone, glowstone));
    settle(&mut streaming, &mut world);
    let mut checked = 0;
    for (&(x, sy, z), mesh) in &meshes {
        let region: Region = std::array::from_fn(|dz| {
            std::array::from_fn(|dx| {
                world
                    .chunks
                    .get(&(x + dx as i32 - 1, z + dz as i32 - 1))
                    .cloned()
            })
        });
        let mut mesher = Mesher {
            nether_shading: false,
            shader_pack_lighting: false,
            separate_ao: false,
            shader_pack: false,
            zoom: BiomeZoom::new(0),
            blend_radius: 2,
            smooth_lighting: true,
            cutout_leaves: true,
            opaque_ice: false,
            translucent_layers: &[],
            leaf_culling: LeafCullingMode::Off,
            assets: &context.assets,
            render: &context.render,
            tables: &context.tables,
            hidden_states: &context.hidden_states,
            biomes: &context.biomes,
            visibility: context.tables.visibility.clone(),
        };
        // The workers sort solid quads by side, as uploads expect.
        let mut fresh = mesher.mesh(&borrow(&region), sy);
        fresh.sort_solid();
        let bytes = |m: &SectionMesh| {
            [
                bytemuck::cast_slice::<_, u8>(&m.solid).to_vec(),
                bytemuck::cast_slice::<_, u8>(&m.translucent).to_vec(),
            ]
        };
        assert!(
            bytes(mesh) == bytes(&fresh) && mesh.visibility == fresh.visibility,
            "section {x} {sy} {z} kept a stale mesh"
        );
        checked += 1;
    }
    assert!(checked >= 45 * 24, "only {checked} sections checked");
    for x in 0..=3 {
        for z in -1..=1 {
            assert!((0..24).all(|sy| meshes.contains_key(&(x, sy, z))));
        }
    }
}

/// A server keeps an area loaded around each player (`Streaming::extra`):
/// every column within `radius + 1` of an area's centre (Chebyshev, as
/// vanilla's ticket levels) loads, with several areas at once and after the
/// areas change between updates. `update` trusts the cover it refreshed at
/// its start; debug builds check it against the areas on every column.
#[test]
fn every_extra_area_loads_however_the_areas_change() {
    let Some(root) = resources() else {
        return;
    };
    let assets = Arc::new(Assets::load(&root).unwrap());
    let render = Arc::new(
        assets
            .reload(&horizon_assets::resource_source::ResourceRoot::directory(
                root.clone(),
            ))
            .unwrap(),
    );
    let facts = BlockFacts::load(&root, assets.registry).unwrap();
    let visibility = models::load_visibility(&root, assets.registry).unwrap();
    let context = Arc::new(WorkerContext {
        hidden_states: Default::default(),
        tables: Arc::new(MeshTables::new(&assets, &render, &facts, visibility, None).unwrap()),
        light: Arc::new(LightTables::load(&root, assets.registry, &facts).unwrap()),
        biomes: Arc::new(
            Biomes::load(&horizon_assets::resource_source::ResourceRoot::directory(
                root.clone(),
            ))
            .unwrap(),
        ),
        assets,
        render,
    });
    let mut streaming = Streaming::new(Arc::new(Saved), context, 3);
    // A server's thread: nothing is meshed.
    streaming.mesh = false;
    streaming.radius = 2;
    let mut world = World::new(BlockStateId(0), 0);
    let settle = |streaming: &mut Streaming, world: &mut World| {
        let deadline = Instant::now() + Duration::from_secs(60);
        let mut quiet = 0;
        while quiet < 40 {
            assert!(Instant::now() < deadline, "streaming never settled");
            let before = world.chunks.len();
            let _ = streaming.update(world);
            thread::sleep(Duration::from_millis(5));
            quiet = if !streaming.busy() && before == world.chunks.len() {
                quiet + 1
            } else {
                0
            };
        }
    };
    let missing = |world: &World, areas: &[((i32, i32), i32)]| {
        let mut missing = Vec::new();
        for &((cx, cz), r) in areas {
            for x in cx - r - 1..=cx + r + 1 {
                for z in cz - r - 1..=cz + r + 1 {
                    if !world.chunks.contains_key(&(x, z)) {
                        missing.push((x, z));
                    }
                }
            }
        }
        missing
    };
    let first = [((40, 0), 2), ((-40, 10), 3)];
    streaming.extra = first.to_vec();
    settle(&mut streaming, &mut world);
    assert_eq!(missing(&world, &first), []);
    // One player left, two came: the next update reads the new areas.
    let second = [((40, 0), 2), ((0, -40), 1), ((60, 60), 2)];
    streaming.extra = second.to_vec();
    settle(&mut streaming, &mut world);
    assert_eq!(missing(&world, &second), []);
}

/// Finished meshes the game has not uploaded yet count against the room for
/// new mesh jobs, as the jobs in flight do: while uploads fall behind (a low
/// frame rate at a wide render distance) meshing waits instead of piling up
/// gigabytes of meshes, and it resumes once the game takes them.
#[test]
fn meshes_waiting_for_upload_hold_back_new_mesh_jobs() {
    let Some(root) = resources() else {
        return;
    };
    let assets = Arc::new(Assets::load(&root).unwrap());
    let source = horizon_assets::resource_source::ResourceRoot::directory(root.clone());
    let render = Arc::new(assets.reload(&source).unwrap());
    let facts = BlockFacts::load(&root, assets.registry).unwrap();
    let visibility = models::load_visibility(&root, assets.registry).unwrap();
    let context = Arc::new(WorkerContext {
        tables: Arc::new(MeshTables::new(&assets, &render, &facts, visibility, None).unwrap()),
        light: Arc::new(LightTables::load(&root, assets.registry, &facts).unwrap()),
        biomes: Arc::new(Biomes::load(&source).unwrap()),
        assets,
        render,
        hidden_states: Arc::from([]),
    });
    let workers = 3;
    let mut streaming = Streaming::new(Arc::new(Saved), context, workers);
    streaming.radius = 2;
    let mut world = World::new(BlockStateId(0), 0);
    let settle = |streaming: &mut Streaming, world: &mut World| {
        let mut meshed = HashSet::new();
        let deadline = Instant::now() + Duration::from_secs(60);
        let mut quiet = 0;
        while quiet < 40 {
            assert!(Instant::now() < deadline, "streaming never settled");
            let before = (world.chunks.len(), meshed.len());
            let (uploads, _) = streaming.update(world);
            meshed.extend(uploads.iter().map(|(key, _)| *key));
            streaming.free(uploads);
            thread::sleep(Duration::from_millis(5));
            let idle = !streaming.busy() && before == (world.chunks.len(), meshed.len());
            quiet = if idle { quiet + 1 } else { 0 };
        }
        meshed
    };
    // The game holds as many meshes as the workers' whole room (32 each).
    streaming.upload_backlog = workers * 32;
    assert_eq!(
        settle(&mut streaming, &mut world).len(),
        0,
        "sections meshed"
    );
    assert!(world.chunks.contains_key(&(0, 0)), "the columns still load");
    // The game uploaded them: the columns in range mesh.
    streaming.upload_backlog = 0;
    let meshed = settle(&mut streaming, &mut world);
    for sy in 0..HEIGHT / 16 {
        assert!(
            meshed.contains(&(0, sy, 0)),
            "section 0 {sy} 0 was never meshed"
        );
    }
}
