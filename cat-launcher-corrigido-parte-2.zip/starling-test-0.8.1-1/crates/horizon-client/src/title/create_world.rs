//! CreateWorldScreen: the Game, World and More tabs under a MenuTabBar, with
//! Create New World and Cancel in a 33-pixel footer.
use super::{Button, Title};
use crate::{
    hud::{HudAtlas, HudBatch},
    text::Text,
    ui,
};

/// MenuTabBar.HEIGHT: the header above the tab area.
const TAB_BAR: f32 = 24.0;
/// HeaderAndFooterLayout's default footer height.
const FOOTER: f32 = 33.0;
const TABS: [&str; 3] = [
    "createWorld.tab.game.title",
    "createWorld.tab.world.title",
    "createWorld.tab.more.title",
];
/// Difficulty ids, in the cycle button's order.
pub const DIFFICULTIES: [&str; 4] = ["peaceful", "easy", "normal", "hard"];

/// WorldCreationUiState beyond the name and seed. Kept as JSON when the game starts again to
/// create the world with other content mods (world_content.rs `request_create`).
#[derive(Clone, Debug, PartialEq, serde::Serialize, serde::Deserialize)]
#[serde(default)]
pub struct WorldOptions {
    /// Selected data-pack preset; none selects `world_type`.
    pub custom_preset: Option<String>,
    /// Committed editor output, saved as the world's dimension stems (not kept across a restart).
    #[serde(skip)]
    pub preset_dimensions: Option<horizon_core::nbt::Tag>,
    /// Available enabled data-pack presets, refreshed when the pack selection changes.
    #[serde(skip)]
    pub presets: std::collections::BTreeMap<String, horizon_core::nbt::Tag>,
    /// The enabled `minecraft:normal` world-preset tag's selection order.
    pub preset_order: Vec<String>,
    /// The open tab: Game, World or More.
    pub tab: usize,
    /// Survival locked to Hard, one life (`SelectedGameMode.HARDCORE`).
    pub hardcore: bool,
    /// Index in `DIFFICULTIES`.
    pub difficulty: usize,
    /// Allow Cheats as toggled; unset follows the game mode.
    pub commands: Option<bool>,
    /// The world preset the world is created with.
    pub world_type: crate::save::WorldPreset,
    /// The biome the single-biome preset fixes (`CreateBuffetWorldScreen`'s
    /// choice), `minecraft:plains` until another is picked.
    pub single_biome: String,
    /// CreateFlatWorldScreen's layers and biome, kept with the world type.
    pub flat_settings: Option<super::flat::FlatSettings>,
    pub structures: bool,
    pub bonus_chest: bool,
    /// `getGameRules`: the Game Rules screen's values, saved with the world.
    #[serde(with = "rules_text")]
    pub rules: crate::gamerules::GameRules,
    /// The Data Packs screen's selection, lowest priority first.
    pub data_packs: Vec<String>,
    /// The folder of packs for the new world (vanilla's `mcworld-`
    /// temporary folder), made when Data Packs first opens.
    pub pack_dir: Option<std::path::PathBuf>,
    /// Starling: the content mods adding blocks or items the world plays with; none chosen, the
    /// ones running now (world_content.rs).
    pub mods: Option<std::collections::BTreeSet<String>>,
    /// Additional repository sources retained for this creation configuration (not kept in the
    /// JSON a restart reads back).
    #[serde(skip)]
    pub additional_data_packs: std::sync::Arc<[std::sync::Arc<crate::datapack::DataPack>]>,
}

/// The rules by name as their text, set back through [`GameRules::set_string`].
///
/// [`GameRules::set_string`]: crate::gamerules::GameRules::set_string
mod rules_text {
    use crate::gamerules::GameRules;
    use std::collections::BTreeMap;

    pub fn serialize<S: serde::Serializer>(rules: &GameRules, s: S) -> Result<S::Ok, S::Error> {
        let text: BTreeMap<String, String> = rules
            .by_name()
            .into_keys()
            .filter_map(|name| {
                let value = rules.get(&name)?.to_string();
                Some((name, value))
            })
            .collect();
        serde::Serialize::serialize(&text, s)
    }
    pub fn deserialize<'de, D: serde::Deserializer<'de>>(d: D) -> Result<GameRules, D::Error> {
        let text: BTreeMap<String, String> = serde::Deserialize::deserialize(d)?;
        let mut rules = GameRules::default();
        // A name this game doesn't know is left out (set_string says so).
        for (name, value) in &text {
            rules.set_string(name, value);
        }
        Ok(rules)
    }
}
impl Default for WorldOptions {
    fn default() -> Self {
        Self {
            custom_preset: None,
            preset_dimensions: None,
            presets: Default::default(),
            preset_order: crate::save::WorldPreset::ALL
                .iter()
                .map(|p| p.id().into())
                .collect(),
            tab: 0,
            hardcore: false,
            difficulty: 2,
            commands: None,
            world_type: crate::save::WorldPreset::Normal,
            single_biome: "minecraft:plains".into(),
            flat_settings: None,
            structures: true,
            bonus_chest: false,
            rules: crate::gamerules::GameRules::default(),
            data_packs: vec!["vanilla".into()],
            pack_dir: None,
            mods: None,
            additional_data_packs: std::sync::Arc::from([]),
        }
    }
}
impl WorldOptions {
    /// Refresh additional sources and insert required packs while preserving
    /// the chosen ids, including folder packs already copied to the new world.
    pub fn set_additional_data_packs(
        &mut self,
        packs: std::sync::Arc<[std::sync::Arc<crate::datapack::DataPack>]>,
    ) {
        let mut available: Vec<_> = packs
            .iter()
            .filter_map(|pack| pack.selection.as_ref())
            .map(crate::pack_screen::PackInfo::selectable)
            .collect();
        for id in &self.data_packs {
            if !available.iter().any(|pack| pack.id == *id) {
                available.push(crate::packs::Selectable::optional(id, true));
            }
        }
        self.data_packs = crate::packs::SelectionModel::new(available, &self.data_packs)
            .selected
            .into_iter()
            .rev()
            .map(|pack| pack.id)
            .collect();
        self.additional_data_packs = packs;
    }
    /// A fresh Create New World in the game folder (the working directory): the defaults, with
    /// the packs this game folder gives every new world.
    pub(super) fn for_new_world() -> Self {
        let seeded = std::env::current_dir()
            .ok()
            .and_then(|dir| crate::datapack::seed_create_world(&dir));
        let mut options = Self::default();
        if let Some((dir, ids)) = seeded {
            options.pack_dir = Some(dir);
            options.data_packs.extend(ids);
        }
        options
    }
    /// Re-Create: the saved world's choices.
    pub(super) fn of_world(
        level: &crate::save::Level,
        commands: bool,
        dir: &std::path::Path,
        registry: std::sync::Arc<crate::gamerules::RuleRegistry>,
    ) -> Self {
        let generation = crate::save::WorldGen::read(dir).unwrap_or_default();
        let (pack_dir, data_packs) = crate::datapack::for_recreate(dir);
        Self {
            hardcore: level.hardcore,
            difficulty: DIFFICULTIES
                .iter()
                .position(|d| *d == level.difficulty)
                .unwrap_or(2),
            commands: Some(commands),
            world_type: generation.preset,
            single_biome: fixed_biome(dir).unwrap_or_else(|| "minecraft:plains".into()),
            flat_settings: (generation.preset == crate::save::WorldPreset::Flat)
                .then(|| super::flat::FlatSettings::from_world(dir))
                .flatten(),
            structures: generation.structures,
            bonus_chest: generation.bonus_chest,
            rules: crate::gamerules::GameRules::load_with_registry(
                dir,
                &level.enabled_features,
                registry,
            ),
            data_packs,
            pack_dir,
            ..Self::default()
        }
    }
    /// Re-Create's repository enables the original world's feature packs.
    pub(super) fn restore_feature_packs(
        &mut self,
        resources: &std::path::Path,
        level: &crate::save::Level,
    ) {
        let packs = self.available_packs(resources);
        if let Some((enabled, disabled)) = &level.data_packs {
            let mut selected: Vec<_> = enabled
                .iter()
                .filter(|id| id.as_str() == "vanilla" || packs.iter().any(|p| &p.id == *id))
                .cloned()
                .collect();
            for id in &self.data_packs {
                if !selected.contains(id) && !disabled.contains(id) {
                    selected.push(id.clone());
                }
            }
            self.data_packs = selected;
        }
        let provided: Vec<_> = packs
            .iter()
            .filter(|p| self.data_packs.contains(&p.id))
            .flat_map(|p| p.features())
            .collect();
        let mut missing: Vec<_> = level
            .enabled_features
            .iter()
            .filter(|f| f.as_str() != "minecraft:vanilla" && !provided.contains(f))
            .cloned()
            .collect();
        for pack in packs.iter().filter(|p| !p.id.starts_with("file/")) {
            let required = pack.features();
            if required.iter().any(|f| missing.contains(f))
                && required.iter().all(|f| level.enabled_features.contains(f))
                && !self.data_packs.contains(&pack.id)
            {
                self.data_packs.push(pack.id.clone());
                missing.retain(|f| !required.contains(f));
            }
        }
    }
    pub(super) fn available_packs(
        &self,
        resources: &std::path::Path,
    ) -> Vec<crate::datapack::DataPack> {
        let mut packs = crate::datapack::feature_packs(resources);
        packs.extend(
            self.additional_data_packs
                .iter()
                .map(|pack| (**pack).clone()),
        );
        if let Some(dir) = &self.pack_dir {
            packs.extend(crate::datapack::discover_folder(dir));
        }
        packs
    }
    /// WorldDataConfiguration's selected feature packs over vanilla's flags.
    pub fn enabled_features(&self, resources: &std::path::Path) -> Vec<String> {
        let mut features = vec!["minecraft:vanilla".to_owned()];
        features.extend(
            self.available_packs(resources)
                .iter()
                .filter(|pack| self.data_packs.contains(&pack.id))
                .flat_map(|pack| pack.features()),
        );
        features.sort();
        features.dedup();
        features
    }
    /// `getDifficulty`: Hardcore is always Hard.
    pub fn difficulty(&self) -> usize {
        if self.hardcore { 3 } else { self.difficulty }
    }
    /// `isAllowCommands`: never in Hardcore, else on for Creative until toggled.
    pub fn commands(&self, creative: bool) -> bool {
        !self.hardcore && self.commands.unwrap_or(creative)
    }
    /// `isBonusChest`: never in Hardcore.
    pub fn bonus_chest(&self) -> bool {
        !self.hardcore && self.bonus_chest
    }
    pub fn world_gen(&self) -> crate::save::WorldGen {
        crate::save::WorldGen {
            preset: self.world_type,
            structures: self.structures,
            bonus_chest: self.bonus_chest(),
        }
    }
    /// The biome the single-biome preset fixes, as
    /// `write_world_gen_settings_with` takes it; none for another preset,
    /// which has no fixed biome to honour.
    pub fn single_biome(&self) -> Option<&str> {
        (self.world_type == crate::save::WorldPreset::SingleBiomeSurface)
            .then_some(self.single_biome.as_str())
    }
    /// The custom layers, as `write_world_gen_settings_with` takes them.
    pub fn flat_settings(&self) -> Option<horizon_core::nbt::Tag> {
        self.flat_settings
            .as_ref()
            .map(super::flat::FlatSettings::to_tag)
    }
    /// A press on one of the open tab's cycle buttons or switches.
    pub(super) fn press(&mut self, id: u8, creative: &mut bool) {
        self.cycle(id, creative, 1);
    }
    /// A step on one of the open tab's cycle buttons or switches (mouse wheel or keyboard).
    pub(super) fn cycle(&mut self, id: u8, creative: &mut bool, step: i32) {
        match id {
            // Survival, Hardcore, Creative.
            20 => {
                let modes = [(false, false), (false, true), (true, false)];
                let cur = (*creative, self.hardcore);
                let idx = modes.iter().position(|&m| m == cur).unwrap_or(0);
                let next_idx = ((idx as i32 + step).rem_euclid(modes.len() as i32)) as usize;
                (*creative, self.hardcore) = modes[next_idx];
            }
            23 => {
                let len = DIFFICULTIES.len() as i32;
                self.difficulty = ((self.difficulty as i32 + step).rem_euclid(len)) as usize;
            }
            24 => self.commands = Some(!self.commands(*creative)),
            25 => {
                self.cycle_preset(step);
                if self.world_type == crate::save::WorldPreset::Flat {
                    // setWorldType starts the generator from the flat preset.
                    self.flat_settings = Some(super::flat::FlatSettings::default());
                }
                // ...and its dimensions replace the ones the preset before it
                // had, so a fixed biome the player chose starts over at the
                // single-biome preset's own.
                self.single_biome = "minecraft:plains".into();
            }
            27 => self.structures = !self.structures,
            28 => self.bonus_chest = !self.bonus_chest,
            _ => {}
        }
    }
}

/// The biome a saved world's fixed biome source names
/// (`CreateBuffetWorldScreen`'s initial selection).
fn fixed_biome(dir: &std::path::Path) -> Option<String> {
    let settings = crate::save::world_gen_settings(dir)?;
    let generator = settings
        .get("dimensions")?
        .get("minecraft:overworld")?
        .get("generator")?;
    crate::save::text(generator.get("biome_source")?.get("biome"))
}

/// `Mth.roundToward`: up to a multiple of `step`.
fn round_toward(value: f32, step: f32) -> f32 {
    (value / step).ceil() * step
}
/// MenuTabBar.arrangeElements: the first tab's x and every tab's width.
fn tabs(w: f32) -> (f32, f32) {
    let width = w.min(400.0) - 28.0;
    (
        round_toward(((w - width) / 2.0).trunc(), 2.0),
        round_toward((width / TABS.len() as f32).trunc(), 2.0),
    )
}
/// The tab under the pointer.
pub(super) fn tab_at(w: f32, (x, y): (f32, f32)) -> Option<usize> {
    let (x0, width) = tabs(w);
    ((0.0..TAB_BAR).contains(&y) && x >= x0)
        .then(|| ((x - x0) / width) as usize)
        .filter(|i| *i < TABS.len())
}
/// `TabNavigationBar.tabs.size()`: the last tab Ctrl+0 and Ctrl+4..9 land on.
pub(super) fn tab_count() -> usize {
    TABS.len()
}
/// `InputConstants.Key.getNumericKeyValue`: the digit a key stands for, on the
/// number row or the keypad, and 0 for the `0` key. `None` for every other key.
fn numeric_key(key: winit::keyboard::KeyCode) -> Option<u8> {
    use winit::keyboard::KeyCode;
    Some(match key {
        KeyCode::Digit0 | KeyCode::Numpad0 => 0,
        KeyCode::Digit1 | KeyCode::Numpad1 => 1,
        KeyCode::Digit2 | KeyCode::Numpad2 => 2,
        KeyCode::Digit3 | KeyCode::Numpad3 => 3,
        KeyCode::Digit4 | KeyCode::Numpad4 => 4,
        KeyCode::Digit5 | KeyCode::Numpad5 => 5,
        KeyCode::Digit6 | KeyCode::Numpad6 => 6,
        KeyCode::Digit7 | KeyCode::Numpad7 => 7,
        KeyCode::Digit8 | KeyCode::Numpad8 => 8,
        KeyCode::Digit9 | KeyCode::Numpad9 => 9,
        _ => return None,
    })
}
/// `TabNavigationBar.getNextTabIndex`: the tab Ctrl plus `key` asks for, before
/// `Mth.clamp` to the tabs there are. A digit is `floorMod(key - 1, 10)`, so
/// Ctrl+1 is the first tab and Ctrl+0 the tenth; Tab steps one tab forward,
/// or back with Shift, wrapping. Every Create World tab is active, so the
/// walk never has to skip one. `None` where the key is neither a digit nor
/// Tab, which the bar ignores and the screen reads itself.
pub(super) fn next_tab_index(
    tab: usize,
    key: winit::keyboard::KeyCode,
    shift: bool,
) -> Option<usize> {
    if let Some(digit) = numeric_key(key) {
        return Some((i32::from(digit) - 1).rem_euclid(10) as usize);
    }
    if key != winit::keyboard::KeyCode::Tab {
        return None;
    }
    let next = tab as i32 + if shift { -1 } else { 1 };
    Some(next.rem_euclid(TABS.len() as i32) as usize)
}
/// GridLayoutTab.doLayout: the open tab's grid, aligned at (0.5, 1/6) in the
/// area between the tab bar and the footer.
fn grid(w: f32, h: f32, tab: usize) -> (f32, f32) {
    // Game: the labelled name box (9 + 4 + 20) and three buttons, 8 apart.
    // World: a button row, the labelled seed box and the SwitchGrid
    // (4 + 20 + 4 + 20 under its empty spacer row). More: three buttons.
    let (gw, gh) = match tab {
        0 => (210.0, 117.0),
        1 => (310.0, 117.0),
        _ => (210.0, 76.0),
    };
    let area = h - TAB_BAR - FOOTER;
    (
        ((w - gw) * 0.5).trunc(),
        TAB_BAR + ((area - gh) * 0.166_666_67).trunc(),
    )
}
/// The text box of `tab`: 0 the name (Game tab), 1 the seed (World tab).
pub(super) fn field_rect(w: f32, h: f32, tab: usize) -> Option<(u8, [f32; 4])> {
    let (gx, gy) = grid(w, h, tab);
    match tab {
        0 => Some((0, [gx + 1.0, gy + 13.0, 208.0, 20.0])),
        1 => Some((1, [gx, gy + 41.0, 308.0, 20.0])),
        _ => None,
    }
}
/// The text box under the pointer: 0 the name, 1 the seed.
pub(super) fn field_at(w: f32, h: f32, tab: usize, (x, y): (f32, f32)) -> Option<u8> {
    let (id, [fx, fy, fw, fh]) = field_rect(w, h, tab)?;
    ui::hovered((x, y), fx, fy, fw, fh).then_some(id)
}

fn tr(key: &str) -> String {
    Text::translate(key, &[]).plain()
}
/// `CycleButton`'s "Label: Value" (`options.generic_value`).
fn labelled(key: &str, value: String) -> String {
    Text::translate(
        "options.generic_value",
        &[Text::translate(key, &[]), Text::literal(value)],
    )
    .plain()
}
fn on_off(on: bool) -> String {
    tr(if on { "options.on" } else { "options.off" })
}
fn game_mode(creative: bool, hardcore: bool) -> &'static str {
    match (creative, hardcore) {
        (true, _) => "selectWorld.gameMode.creative",
        (false, true) => "selectWorld.gameMode.hardcore",
        (false, false) => "selectWorld.gameMode.survival",
    }
}

/// The open tab's buttons and the footer's.
pub(super) fn buttons(
    w: f32,
    h: f32,
    creative: bool,
    o: &WorldOptions,
    editors_ready: bool,
) -> Vec<Button> {
    let b = |x: f32, y: f32, w: f32, label: String, enabled: bool, id: u8| Button {
        x,
        y,
        w,
        label,
        enabled,
        id,
        icon: None,
        trailing: None,
        action: None,
    };
    let (gx, gy) = grid(w, h, o.tab);
    let mut buttons = match o.tab {
        0 => vec![
            b(
                gx,
                gy + 41.0,
                210.0,
                labelled("selectWorld.gameMode", tr(game_mode(creative, o.hardcore))),
                true,
                20,
            ),
            b(
                gx,
                gy + 69.0,
                210.0,
                labelled(
                    "options.difficulty",
                    tr(&format!(
                        "options.difficulty.{}",
                        DIFFICULTIES[o.difficulty()]
                    )),
                ),
                !o.hardcore,
                23,
            ),
            b(
                gx,
                gy + 97.0,
                210.0,
                labelled("selectWorld.allowCommands", on_off(o.commands(creative))),
                !o.hardcore,
                24,
            ),
        ],
        1 => vec![
            b(
                gx,
                gy,
                150.0,
                labelled("selectWorld.mapType", o.preset_label()),
                true,
                25,
            ),
            // PresetEditor.EDITORS: flat worlds have CreateFlatWorldScreen, the
            // single-biome preset CreateBuffetWorldScreen; the other presets
            // have no editor, so the button is disabled for them.
            b(
                gx + 160.0,
                gy,
                150.0,
                tr("selectWorld.customizeType"),
                (editors_ready && super::preset_editors::editor(o.preset_id()).is_some())
                    || (o.custom_preset.is_none()
                        && matches!(
                            o.world_type,
                            crate::save::WorldPreset::Flat
                                | crate::save::WorldPreset::SingleBiomeSurface
                        )),
                26,
            ),
            // SwitchGrid: 44-wide value-only buttons at the grid's right.
            b(gx + 266.0, gy + 73.0, 44.0, on_off(o.structures), true, 27),
            b(
                gx + 266.0,
                gy + 97.0,
                44.0,
                on_off(o.bonus_chest()),
                !o.hardcore,
                28,
            ),
        ],
        // The More tab, as vanilla lays it out: Game Rules, Experiments
        // (the resources' feature packs), Data Packs.
        _ => [
            "selectWorld.gameRules",
            "selectWorld.experiments",
            "selectWorld.dataPacks",
        ]
        .iter()
        .enumerate()
        .map(|(i, key)| b(gx, gy + 28.0 * i as f32, 210.0, tr(key), true, 29 + i as u8))
        .collect(),
    };
    // The footer: two 150-wide buttons 8 apart, centred in its 33 pixels.
    let x = ((w - 308.0) * 0.5).trunc();
    buttons.push(b(
        x,
        h - 27.0,
        150.0,
        crate::lang::get_or("selectWorld.create", "Create New World"),
        true,
        21,
    ));
    buttons.push(
        b(
            x + 158.0,
            h - 27.0,
            150.0,
            crate::lang::get_or("gui.cancel", "Cancel"),
            true,
            22,
        )
        .does(crate::widgets::Action::Cancel),
    );
    buttons
}

/// What button `b` of the screen narrates: the cycle buttons their message
/// and the value a click moves to, the SwitchGrid switches their label (and
/// info) around their value, each with its tooltip; in the order the screen
/// adds them (the tab's widgets after the tab bar, the footer last).
pub(super) fn button_narration(
    b: &Button,
    creative: bool,
    o: &WorldOptions,
) -> crate::widgets::Narratable {
    use crate::widgets::{Narratable, join_for_narration as join};
    let rect = [b.x, b.y, b.w, 20.0];
    let cycle = |next: String| Narratable::cycle(b.label.clone(), next, rect, b.enabled);
    // SwitchGrid: a value-only CycleButton named `""`, narrated as
    // joinForNarration(label, its default narration[, info]).
    let switch = |label: &str, info: Option<&str>, value: bool| {
        let own = Text::translate(
            "options.generic_value",
            &[Text::literal(""), Text::literal(on_off(value))],
        )
        .plain();
        let own = Text::translate("gui.narrate.button", &[Text::literal(own)]).plain();
        let title = match info {
            Some(info) => join(&[&tr(label), &own, &tr(info)]),
            None => join(&[&tr(label), &own]),
        };
        let n = Narratable::new(
            crate::widgets::What::NamedCycle {
                title,
                next: on_off(!value),
                active: b.enabled,
            },
            rect,
        );
        match info {
            Some(info) => n.hint(tr(info)),
            None => n,
        }
    };
    let narratable = match b.id {
        // Survival, Hardcore, Creative.
        20 => {
            let next = match (creative, o.hardcore) {
                (false, false) => game_mode(false, true),
                (false, true) => game_mode(true, false),
                _ => game_mode(false, false),
            };
            cycle(tr(next)).hint(tr(&format!("{}.info", game_mode(creative, o.hardcore))))
        }
        23 => cycle(tr(&format!(
            "options.difficulty.{}",
            DIFFICULTIES[(o.difficulty + 1) % DIFFICULTIES.len()]
        )))
        .hint(tr(&format!(
            "options.difficulty.{}.info",
            DIFFICULTIES[o.difficulty()]
        ))),
        24 => cycle(on_off(!o.commands(creative))).hint(tr("selectWorld.allowCommands.info")),
        25 => {
            let n = cycle(super::preset_editors::preset_label(o.cycled_preset(1)));
            if o.custom_preset.is_none() && o.world_type == crate::save::WorldPreset::Amplified {
                n.hint(tr("generator.minecraft.amplified.info"))
            } else {
                n
            }
        }
        27 => switch(
            "selectWorld.mapFeatures",
            Some("selectWorld.mapFeatures.info"),
            o.structures,
        ),
        28 => switch("selectWorld.bonusItems", None, o.bonus_chest()),
        _ => Narratable::button(b.label.clone(), rect, b.enabled),
    };
    // The World tab adds its type and Customize row before the seed box,
    // which Horizon draws first; the footer is tab order group 1.
    narratable.order(match b.id {
        25 | 26 => -1,
        21 | 22 => 1,
        _ => 0,
    })
}

impl Title {
    /// Everything but the buttons, which `draw` adds after.
    #[allow(clippy::too_many_arguments)]
    pub(super) fn draw_create(
        &self,
        atlas: &HudAtlas,
        batch: &mut HudBatch,
        cursor: (f32, f32),
        name: &str,
        seed: &str,
        focus: u8,
        o: &WorldOptions,
    ) {
        let (w, h) = (batch.width.ceil(), batch.height.ceil());
        // extractMenuBackground: the tab header strip, the menu background under it.
        ui::tiled(
            batch,
            atlas,
            "gui/tab_header_background",
            0.0,
            0.0,
            w,
            TAB_BAR,
            16.0,
            u32::MAX,
        );
        ui::menu_background(batch, atlas, 0.0, TAB_BAR, w, h - TAB_BAR, false);
        // MenuTabBar: header separators either side of the tabs.
        let (x0, tw) = tabs(w);
        let right = x0 + tw * TABS.len() as f32;
        // TabNavigationBar: the tab under the mouse, else the open one, each a
        // GridLayoutTab with no extra narration. The screen adds it first.
        crate::widgets::narratable(|| {
            use crate::widgets::{ListKind, Narratable, Row};
            let tab = |i: usize| {
                let mut row = Row::new(i, tr(TABS[i]));
                row.hint = Some(String::new());
                row
            };
            Narratable::list(
                ListKind::Tabs,
                TABS.len(),
                tab_at(w, cursor).map(tab),
                Some(tab(o.tab)),
                [x0, 0.0, right - x0, TAB_BAR],
            )
            .key(crate::widgets::key_of(&"create_world/tabs"))
            .order(-2)
        });
        for (x, width) in [(0.0, x0), (right, w - right)] {
            ui::tiled_sized(
                batch,
                atlas,
                "gui/header_separator",
                x,
                TAB_BAR - 2.0,
                width,
                2.0,
                [32.0, 2.0],
                u32::MAX,
            );
        }
        for (i, key) in TABS.iter().enumerate() {
            let x = x0 + tw * i as f32;
            let selected = o.tab == i;
            let label = Text::translate(key, &[]);
            crate::widgets::record(&label.plain(), [x, 0.0, tw, TAB_BAR], true);
            crate::widgets::target_as([x, 0.0, tw, TAB_BAR], crate::widgets::Kind::Tab(selected));
            let sprite = match (selected, ui::hovered(cursor, x, 0.0, tw, TAB_BAR)) {
                (true, true) => "gui/sprites/widget/tab_selected_highlighted",
                (true, false) => "gui/sprites/widget/tab_selected",
                (false, true) => "gui/sprites/widget/tab_highlighted",
                (false, false) => "gui/sprites/widget/tab",
            };
            ui::nine_slice(batch, atlas, sprite, x, 0.0, tw, TAB_BAR, u32::MAX);
            let lw = atlas.font.width_text(&label).floor();
            if selected {
                ui::menu_background(batch, atlas, x + 2.0, 2.0, tw - 4.0, TAB_BAR - 2.0, false);
                // renderFocusUnderline.
                let uw = lw.min(tw - 4.0);
                batch.fill(
                    atlas,
                    x + ((tw - uw) / 2.0).floor(),
                    TAB_BAR - 2.0,
                    uw,
                    1.0,
                    u32::MAX,
                );
            }
            ui::menu_tab_label(
                batch,
                atlas,
                &label,
                (x, 0.0, tw, TAB_BAR),
                selected,
                true,
                crate::hud_overlays::now_ms(),
            );
        }
        let (gx, gy) = grid(w, h, o.tab);
        let label = |batch: &mut HudBatch, key: &str, x: f32, y: f32| {
            batch.text_styled(atlas, &Text::translate(key, &[]), x, y, u32::MAX, true);
        };
        match o.tab {
            0 => {
                // CommonLayouts.labeledElement, centred in the 210 column.
                label(batch, "selectWorld.enterName", gx + 1.0, gy);
                self.create_field(
                    atlas,
                    batch,
                    (super::WORLD_NAME, name, 32),
                    [gx + 1.0, gy + 13.0, 208.0],
                    focus == 0,
                    None,
                );
                // Its tooltip: the folder the world will be saved in.
                crate::widgets::last_narratable(|n| {
                    n.hint = Some(
                        Text::translate(
                            "selectWorld.targetFolder",
                            &[Text::literal(self.target_folder(name))],
                        )
                        .plain(),
                    );
                });
            }
            1 => {
                label(batch, "selectWorld.enterSeed", gx, gy + 28.0);
                self.create_field(
                    atlas,
                    batch,
                    (super::WORLD_SEED, seed, 32),
                    [gx, gy + 41.0, 308.0],
                    focus == 1,
                    Some("selectWorld.seedInfo"),
                );
                // SwitchGrid labels, centred on their switch rows.
                label(batch, "selectWorld.mapFeatures", gx, gy + 78.0);
                label(batch, "selectWorld.bonusItems", gx, gy + 102.0);
            }
            _ => {}
        }
        // The footer separator, drawn over the screen.
        ui::tiled_sized(
            batch,
            atlas,
            "gui/footer_separator",
            0.0,
            h - FOOTER - 2.0,
            w,
            2.0,
            [32.0, 2.0],
            u32::MAX,
        );
    }
    /// An EditBox; `hint` shows while it is empty and unfocused.
    fn create_field(
        &self,
        atlas: &HudAtlas,
        batch: &mut HudBatch,
        (id, value, max): (crate::clipboard::FieldId, &str, usize),
        [x, y, width]: [f32; 3],
        focused: bool,
        hint: Option<&str>,
    ) {
        let rect = [x, y, width, 20.0];
        self.caret
            .borrow_mut()
            .draw(batch, atlas, (id, value, max), rect, focused, self.started);
        crate::widgets::name_last_edit_box(|| {
            tr(if id == super::WORLD_NAME {
                "selectWorld.enterName"
            } else {
                "selectWorld.enterSeed"
            })
        });
        let field = ui::EditBox::new(x, y, width, 20.0);
        if let Some(hint) = hint
            && value.is_empty()
            && !focused
        {
            batch.text_styled(
                atlas,
                &Text::translate(hint, &[]).with_color(crate::text::DARK_GRAY),
                field.text_x(),
                field.text_y(),
                u32::MAX,
                true,
            );
        }
    }
    /// The hovered widget's tooltip, wrapped to Tooltip's 170 pixels.
    pub(super) fn create_tooltip(
        &self,
        atlas: &HudAtlas,
        batch: &mut HudBatch,
        cursor: (f32, f32),
        name: &str,
        creative: bool,
        o: &WorldOptions,
    ) {
        let (w, h) = (batch.width.ceil(), batch.height.ceil());
        let (gx, gy) = grid(w, h, o.tab);
        let over = |x: f32, y: f32, width: f32| ui::hovered(cursor, x, y, width, 20.0);
        let text = match o.tab {
            0 if over(gx + 1.0, gy + 13.0, 208.0) => Some(Text::translate(
                "selectWorld.targetFolder",
                &[Text::literal(self.target_folder(name)).italic()],
            )),
            0 if over(gx, gy + 41.0, 210.0) => Some(Text::translate(
                &format!("{}.info", game_mode(creative, o.hardcore)),
                &[],
            )),
            0 if over(gx, gy + 69.0, 210.0) => Some(Text::translate(
                &format!("options.difficulty.{}.info", DIFFICULTIES[o.difficulty()]),
                &[],
            )),
            0 if over(gx, gy + 97.0, 210.0) => {
                Some(Text::translate("selectWorld.allowCommands.info", &[]))
            }
            // WorldTab: the Amplified preset's help text on the type button.
            1 if o.custom_preset.is_none()
                && o.world_type == crate::save::WorldPreset::Amplified
                && over(gx, gy, 150.0) =>
            {
                Some(Text::translate("generator.minecraft.amplified.info", &[]))
            }
            1 if over(gx + 266.0, gy + 73.0, 44.0) => {
                Some(Text::translate("selectWorld.mapFeatures.info", &[]))
            }
            _ => None,
        };
        if let Some(text) = text {
            ui::tooltip(batch, atlas, &atlas.font.split(&text, 170.0), cursor);
        }
    }
}
