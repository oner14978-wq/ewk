//! The Wardrobe's link to Horizon's cosmetics service ([docs/cosmetics.md](../../docs/cosmetics.md)):
//! the catalogue, the account's own items and purchase history, what each slot wears and whether
//! others see it, and whether the Wardrobe has anything to show yet (`Service::shop`). Buying and
//! claiming happen on the website ([`SHOP_URL`]), except the founder set's free claim for players
//! in countries Paddle, the shop's payment provider, doesn't serve (`Claim::here`,
//! `Service::claim`): the service decides who that is, by country.
//!
//! The last answers are kept on disk (`Saved`), so the Wardrobe shows the outfit offline and when
//! the service fails, and a change made offline waits there until the service answers again.
//!
//! The service learns who the player is the way an online-mode server does: it hands out a
//! one-time server id, the launcher tells Mojang's session server that the account joins it
//! (`account::session::join_server`), and the service asks Mojang. The Minecraft token goes to
//! Mojang only; the service gives back a session of its own, kept in memory here.
use crate::i18n::tr;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use std::collections::BTreeMap;
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};

/// Where cosmetics are bought and the founder set is claimed: the website's shop.
pub const SHOP_URL: &str = horizon_addresses::SHOP;

/// Why a request to the service failed, in words for the player.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Error {
    /// No answer: offline, or the service is down.
    Offline,
    /// Mojang didn't confirm the account (the launcher's `join` failed or was refused).
    Account(String),
    /// The service's session ended: sign in to it again.
    SignedOut,
    /// An item the account doesn't own, or one for another slot.
    NotYours,
    /// The Shop's own refusals, by the service's code (`player`, `owned`, `sales_off`...).
    Shop(String),
    /// Anything else the service answered.
    Service(u16),
}

impl Error {
    pub fn message(&self) -> String {
        match self {
            Self::Offline => {
                tr("Could not reach Horizon's cosmetics service. Check your internet connection.")
                    .into()
            }
            Self::Account(e) => tr(e).into(),
            Self::SignedOut => tr("Your Wardrobe session ended. Open the Wardrobe again.").into(),
            Self::NotYours => tr("That item isn't in your Wardrobe.").into(),
            Self::Shop(code) => tr(match code.as_str() {
                "player" | "name" => "No Minecraft: Java Edition account has that name.",
                "owned" | "claimed" => "That account already owns everything in the basket.",
                "sales_off" | "claim_closed" | "claim_not_open" | "not_for_sale" => {
                    "The shop isn't selling right now. Nothing was charged."
                }
                // Paddle sells where the player is: the founder set is claimed through its free
                // checkout, which the Shop opens on playhorizon.dev (`Error::use_checkout`).
                "use_checkout" => {
                    "Where you are, the founder set is claimed through a free checkout on \
                     playhorizon.dev. Claim it from the Shop: it opens the checkout for you."
                }
                "not_offered_here" => "The founder set can't be claimed from your country.",
                _ => "Paddle couldn't start the checkout. Nothing was charged.",
            })
            .into(),
            Self::Service(_) => {
                tr("Horizon's cosmetics service had a problem. Try again later.").into()
            }
        }
    }

    /// The service refused a one-click claim because Paddle sells where the player is: the
    /// claim goes through the free checkout instead (`Claim::one_click` is no longer true).
    pub fn use_checkout(&self) -> bool {
        matches!(self, Self::Shop(code) if code == "use_checkout")
    }

    /// Whether the change that failed should wait and be sent again: the service wasn't
    /// reached, or failed on its side.
    pub fn retry_later(&self) -> bool {
        matches!(self, Self::Offline | Self::Service(500..))
    }
}

#[derive(Clone, Copy, Debug, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum ClaimState {
    NotYet,
    Open,
    Closed,
    /// A state this launcher doesn't know, from a newer service: the answer still reads, and the
    /// rest of it (`open`, the dates) decides.
    #[serde(other)]
    Unknown,
}

/// The founder set: free to claim between `starts_at` and `ends_at` (Unix seconds, `[start,
/// end)`), retired for good after.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq)]
pub struct Claim {
    pub state: ClaimState,
    pub items: Vec<String>,
    pub starts_at: Option<i64>,
    pub ends_at: Option<i64>,
    /// Whether this account claimed it (in `me` only).
    #[serde(default)]
    pub claimed: Option<bool>,
    /// It can be claimed now: the public window, or a preview for an account on the service's
    /// list.
    #[serde(default)]
    pub open: bool,
    /// Open only because the account is on the service's preview list.
    #[serde(default)]
    pub preview: bool,
    /// The service grants the set to this player from the Wardrobe (`POST /v1/claim`): Paddle
    /// doesn't sell where they are, so the site's checkout can't (in `me` only).
    #[serde(default)]
    pub one_click: bool,
}

impl Claim {
    /// Whether the Wardrobe offers "Claim for free": open for this account, not claimed yet, and
    /// the service says the checkout isn't for this player.
    pub fn here(&self) -> bool {
        self.open && self.one_click && self.claimed == Some(false)
    }
}

#[derive(Clone, Debug, Default, Deserialize, Serialize, PartialEq)]
pub struct Entry {
    pub id: String,
    pub hash: String,
    /// `head`, `back`, `shoulder`, `name_tag` (the game draws them) or `theme` (the launcher's).
    pub slot: String,
    /// The item's name per game language code (`en_us`, `fr_fr`...).
    pub names: BTreeMap<String, String>,
    /// A launcher theme's colours (`slot` is `theme`).
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub theme: Option<Theme>,
    /// One line about it per game language code.
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    pub lines: BTreeMap<String, String>,
    /// What it costs per currency code, in the currency's cents, only while it is on sale (the
    /// Shop, `shop.rs`): empty, it isn't sold.
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    pub prices: BTreeMap<String, u32>,
    /// The collection the Shop lists it under.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub collection: Option<String>,
}

/// A launcher theme: the sky's six stops, top to bottom (`#rrggbb`), and the accent's hue.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq)]
pub struct Theme {
    pub sky: [String; 6],
    pub accent_hue: f32,
}

impl Theme {
    /// The sky as `0xrrggbb`, or None if a stop isn't a colour.
    pub fn sky(&self) -> Option<[u32; 6]> {
        let mut out = [0; 6];
        for (o, c) in out.iter_mut().zip(&self.sky) {
            let hex = c.strip_prefix('#').filter(|h| h.len() == 6)?;
            *o = u32::from_str_radix(hex, 16).ok()?;
        }
        Some(out)
    }
}

/// `words` in `lang` (a game language code), else in English.
pub fn words<'a>(words: &'a BTreeMap<String, String>, lang: &str) -> Option<&'a str> {
    (words.get(lang).or_else(|| words.get("en_us"))).map(String::as_str)
}

impl Entry {
    /// The name in `lang` (a game language code), else English, else the id.
    pub fn name(&self, lang: &str) -> &str {
        words(&self.names, lang).unwrap_or(&self.id)
    }

    /// Whether the id and hash are plain parts of a file name, by the game's rule
    /// (`horizon_cosmetics::fetch`): the cache's paths are made of them.
    fn plain(&self) -> bool {
        [&self.id, &self.hash].into_iter().all(|t| {
            !t.is_empty()
                && t.len() <= 64
                && t.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_')
        })
    }
}

#[derive(Clone, Debug, Deserialize, Serialize, PartialEq)]
pub struct Catalogue {
    pub items: Vec<Entry>,
    pub claim: Claim,
    /// The currency codes the Shop offers, in the service's order; prices are in each of them.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub currencies: Vec<String>,
    /// Items sold together, for less than apart.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub sets: Vec<Set>,
    /// The Shop's headings, in order.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub collections: Vec<Collection>,
    /// The Supporter badge: the buyer picks what it costs, between `min` and `max`.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub supporter: Option<Supporter>,
}

#[derive(Clone, Debug, Default, Deserialize, Serialize, PartialEq)]
pub struct Set {
    pub id: String,
    pub names: BTreeMap<String, String>,
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    pub lines: BTreeMap<String, String>,
    /// Item ids, all in the catalogue's `items`.
    pub items: Vec<String>,
    /// For an account that owns none of it, in cents per currency code.
    #[serde(default)]
    pub prices: BTreeMap<String, u32>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub collection: Option<String>,
}

#[derive(Clone, Debug, Default, Deserialize, Serialize, PartialEq)]
pub struct Collection {
    pub id: String,
    pub names: BTreeMap<String, String>,
    #[serde(default, skip_serializing_if = "BTreeMap::is_empty")]
    pub lines: BTreeMap<String, String>,
    /// The set that holds everything the collection sells: the Shop's hero.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub pack: Option<String>,
}

#[derive(Clone, Debug, Default, Deserialize, Serialize, PartialEq)]
pub struct Supporter {
    /// The badge's item id.
    pub item: String,
    pub min: BTreeMap<String, u32>,
    pub max: BTreeMap<String, u32>,
}

/// A Minecraft account as the Shop's lookup knows it (`GET /v1/players/{name}`): a gift's
/// recipient, and what it owns already, which a price leaves out.
#[derive(Clone, Debug, Deserialize, PartialEq)]
pub struct Player {
    pub uuid: String,
    pub name: String,
    #[serde(default)]
    pub owned: Vec<String>,
}

/// A basket to pay (`POST /v1/web/checkout`): item and set ids for `name`'s account.
#[derive(Clone, Debug, Serialize, PartialEq)]
pub struct Order {
    pub name: String,
    pub items: Vec<String>,
    pub currency: String,
    /// The Supporter badge's price, in cents of `currency`.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub amount: Option<u32>,
    #[serde(skip_serializing_if = "std::ops::Not::not")]
    pub gift: bool,
}

/// The checkout the service started with Paddle; it is paid on the website (`shop::pay_url`).
#[derive(Clone, Debug, Deserialize, PartialEq)]
pub struct Checkout {
    pub transaction_id: String,
    pub uuid: String,
}

/// The signed-in account's items: what it owns, what each slot wears, whether others see it.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq)]
pub struct Me {
    pub uuid: String,
    pub name: String,
    pub owned: Vec<String>,
    pub equipped: BTreeMap<String, String>,
    /// "Show my cosmetics": off, other players see this account without them.
    #[serde(default = "shown")]
    pub visible: bool,
    pub claim: Claim,
    /// What the account claimed or bought through Paddle, newest first (the purchase history
    /// Mojang's guidelines ask for).
    #[serde(default)]
    pub purchases: Vec<Purchase>,
}

/// One order, as the cosmetics service keeps it; Paddle is the merchant of record.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq)]
pub struct Purchase {
    /// Paddle's transaction id (`txn_…`): the order number on Paddle's receipt.
    pub transaction_id: String,
    /// An item id, or `founder_set`.
    pub item: String,
    /// Paid, tax included, in the lowest unit of `currency`.
    pub amount: i64,
    pub currency: String,
    /// `paid`, `partly_refunded`, `refunded` or `charged_back`.
    pub status: String,
    /// Unix seconds.
    pub at: i64,
}

impl Purchase {
    /// The amount as people write it: `2.99 USD`; `None` for nothing paid.
    pub fn price(&self) -> Option<String> {
        (self.amount > 0).then(|| {
            let (whole, cents) = (self.amount / 100, self.amount % 100);
            format!("{whole}.{cents:02} {}", self.currency)
        })
    }
}

fn shown() -> bool {
    true
}

/// A change to the outfit, sent at once or, offline, kept until the service answers.
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum Change {
    /// Wear `item` in `slot`, or nothing there.
    Equip { slot: String, item: Option<String> },
    /// "Show my cosmetics".
    Visible(bool),
}

impl Me {
    /// What the outfit looks like with `change` made, before the service confirms it.
    pub fn apply(&mut self, change: &Change) {
        match change {
            Change::Equip {
                slot,
                item: Some(item),
            } => {
                self.equipped.insert(slot.clone(), item.clone());
            }
            Change::Equip { slot, item: None } => {
                self.equipped.remove(slot);
            }
            Change::Visible(on) => self.visible = *on,
        }
    }
}

/// What the Wardrobe keeps on disk per account: the last catalogue and answer, and the changes
/// still to send. No session or token is ever kept.
#[derive(Clone, Debug, Default, Deserialize, Serialize, PartialEq)]
pub struct Saved {
    pub catalogue: Option<Catalogue>,
    pub me: Option<Me>,
    pub pending: Vec<Change>,
}

impl Saved {
    /// `<dir>/<uuid>.json`.
    pub fn path(dir: &Path, uuid: &str) -> PathBuf {
        dir.join(format!("{uuid}.json"))
    }

    pub fn load(dir: &Path, uuid: &str) -> Self {
        std::fs::read(Self::path(dir, uuid))
            .ok()
            .and_then(|b| serde_json::from_slice(&b).ok())
            .unwrap_or_default()
    }

    pub fn save(&self, dir: &Path, uuid: &str) -> std::io::Result<()> {
        std::fs::create_dir_all(dir)?;
        let path = Self::path(dir, uuid);
        let tmp = path.with_extension("json.tmp");
        std::fs::write(
            &tmp,
            serde_json::to_vec(self).map_err(std::io::Error::other)?,
        )?;
        std::fs::rename(tmp, path)
    }

    /// Make `change` here: the outfit shows it at once and it waits to be sent. A newer change of
    /// the same slot (or of visibility) replaces an older one still waiting.
    pub fn change(&mut self, change: Change) {
        if let Some(me) = &mut self.me {
            me.apply(&change);
        }
        let same = |c: &Change| match (c, &change) {
            (Change::Equip { slot: a, .. }, Change::Equip { slot: b, .. }) => a == b,
            (Change::Visible(_), Change::Visible(_)) => true,
            _ => false,
        };
        self.pending.retain(|c| !same(c));
        self.pending.push(change);
    }
}

/// A session with the service: an opaque token, good for the time it said.
pub struct Session {
    token: String,
    until: Instant,
    pub uuid: String,
    pub name: String,
}

impl std::fmt::Debug for Session {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "Session({}, <hidden>)", self.name)
    }
}

impl Session {
    /// A made-up session for the launcher's screenshot preview (`HORIZON_LAUNCHER_PAGE=wardrobe`):
    /// it carries no credential, so the service refuses anything sent with it.
    pub fn preview(uuid: &str, name: &str) -> Self {
        Self {
            token: String::new(),
            until: Instant::now() + Duration::from_secs(3600),
            uuid: uuid.into(),
            name: name.into(),
        }
    }

    pub fn live(&self) -> bool {
        Instant::now() < self.until
    }
    /// Whether this is the account `uuid`'s session and it has not run out.
    pub fn for_account(&self, uuid: &str) -> bool {
        self.uuid == uuid && self.live()
    }
}

pub struct Service {
    base: String,
}

impl Service {
    /// The service the game asks too (`HORIZON_COSMETICS_API` overrides it).
    pub fn live() -> Self {
        Self::at(
            &std::env::var("HORIZON_COSMETICS_API")
                .unwrap_or_else(|_| horizon_cosmetics::API.to_owned()),
        )
    }

    pub fn at(base: &str) -> Self {
        Self {
            base: base.trim_end_matches('/').to_owned(),
        }
    }

    /// The service's host, for a failure's details.
    pub fn host(&self) -> &str {
        self.base.split_once("://").map_or(&self.base, |(_, h)| h)
    }

    /// Where the founder set's claim stands for everyone (`GET /v1/shop`, no session): whether
    /// the Wardrobe has anything to show yet. An account on the service's preview list learns it from its own
    /// answer (`Me::claim`), with its session.
    pub fn shop(&self) -> Result<Claim, Error> {
        parse(self.call("GET", "/v1/shop", None, None)?)
    }

    pub fn catalogue(&self) -> Result<Catalogue, Error> {
        parse(self.call("GET", "/v1/catalogue", None, None)?)
    }

    /// The Minecraft account named `name`, and what it owns.
    pub fn player(&self, name: &str) -> Result<Player, Error> {
        let plain = |n: &str| {
            (1..=16).contains(&n.len()) && n.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_')
        };
        if !plain(name) {
            return Err(Error::Shop("name".into()));
        }
        parse(self.call("GET", &format!("/v1/players/{name}"), None, None)?)
    }

    /// Starts Paddle's checkout for `order`; the service answers for the account it names.
    pub fn checkout(&self, order: &Order) -> Result<Checkout, Error> {
        let body = serde_json::to_value(order).map_err(|_| Error::Service(0))?;
        parse(self.call("POST", "/v1/web/checkout", None, Some(body))?)
    }

    /// One item's file, checked against the format's limits.
    pub fn item(&self, entry: &Entry) -> Result<horizon_cosmetics::Item, Error> {
        horizon_cosmetics::Item::parse(&self.item_bytes(entry)?).map_err(|_| Error::Service(200))
    }

    fn item_bytes(&self, entry: &Entry) -> Result<Vec<u8>, Error> {
        let url = format!("{}/v1/items/{}?hash={}", self.base, entry.id, entry.hash);
        let response = match agent(&url).get(&url).call() {
            Ok(r) => r,
            Err(ureq::Error::Status(status, _)) => return Err(Error::Service(status)),
            Err(ureq::Error::Transport(_)) => return Err(Error::Offline),
        };
        let mut bytes = Vec::new();
        std::io::Read::read_to_end(
            &mut std::io::Read::take(response.into_reader(), 1 << 20),
            &mut bytes,
        )
        .map_err(|_| Error::Offline)?;
        Ok(bytes)
    }

    /// Sign `name` in: `join` tells Mojang the account joins the server id the service chose
    /// (`account::session::join_server` for a real account).
    pub fn sign_in(
        &self,
        name: &str,
        join: impl FnOnce(&str) -> Result<(), String>,
    ) -> Result<Session, Error> {
        #[derive(Deserialize)]
        struct Start {
            server_id: String,
        }
        #[derive(Deserialize)]
        struct Finish {
            session: String,
            uuid: String,
            name: String,
            expires_in: u64,
        }
        let start: Start = parse(self.call("POST", "/v1/auth/start", None, Some(json!({})))?)?;
        join(&start.server_id).map_err(Error::Account)?;
        let body = json!({ "server_id": start.server_id, "name": name });
        let finish: Finish = match self.call("POST", "/v1/auth/finish", None, Some(body)) {
            Err(Error::SignedOut) => {
                return Err(Error::Account(
                    tr("Mojang could not confirm your account. Sign in again and retry.").into(),
                ))
            }
            other => parse(other?)?,
        };
        Ok(Session {
            token: finish.session,
            // A minute early, so a request never races the end.
            until: Instant::now() + Duration::from_secs(finish.expires_in.saturating_sub(60)),
            uuid: finish.uuid,
            name: finish.name,
        })
    }

    pub fn me(&self, session: &Session) -> Result<Me, Error> {
        parse(self.call("GET", "/v1/me", Some(session), None)?)
    }

    /// Claim the founder set here (only where `Claim::here`): the account's answer after it. One
    /// the service already recorded is no failure.
    pub fn claim(&self, session: &Session) -> Result<Me, Error> {
        match self.call("POST", "/v1/claim", Some(session), Some(json!({}))) {
            // Claimed already (another launcher, a double click): the account's answer.
            Err(Error::Service(409)) => self.me(session),
            Err(Error::Shop(code)) if code == "claimed" => self.me(session),
            other => parse(other?),
        }
    }

    /// Wear `item` in `slot`, or nothing there (`None`).
    pub fn equip(&self, session: &Session, slot: &str, item: Option<&str>) -> Result<Me, Error> {
        let body = json!({ "slot": slot, "item": item });
        parse(self.call("PUT", "/v1/equipped", Some(session), Some(body))?)
    }

    /// "Show my cosmetics": off, other players see this account without them.
    pub fn set_visible(&self, session: &Session, visible: bool) -> Result<Me, Error> {
        let body = json!({ "visible": visible });
        parse(self.call("PUT", "/v1/visible", Some(session), Some(body))?)
    }

    /// Send the changes still waiting, oldest first. Each one the service takes, or refuses for
    /// good (an item no longer owned), leaves `saved.pending`; the first that should be tried
    /// again stops the rest and is the error. `saved.me` is the service's last answer, with what
    /// still waits applied on top.
    pub fn sync(&self, session: &Session, saved: &mut Saved) -> Result<(), Error> {
        while let Some(change) = saved.pending.first().cloned() {
            let sent = match &change {
                Change::Equip { slot, item } => self.equip(session, slot, item.as_deref()),
                Change::Visible(on) => self.set_visible(session, *on),
            };
            match sent {
                Ok(me) => saved.me = Some(me),
                Err(e) if e.retry_later() || e == Error::SignedOut => return Err(e),
                Err(_) => {}
            }
            saved.pending.remove(0);
        }
        Ok(())
    }

    /// Send the changes waiting and read the account's own answer with `session`, which is kept
    /// while it is live: the account is proved with Mojang once per service session, not once
    /// per refresh. The service's 401 (its session ended) signs in once more and retries; any
    /// other failure stands.
    pub fn sync_with_session(
        &self,
        name: &str,
        uuid: &str,
        session: &mut Option<std::sync::Arc<Session>>,
        saved: &mut Saved,
        join: impl Fn(&str) -> Result<(), String>,
    ) -> Result<(), Error> {
        let mut renewed = false;
        loop {
            let current = match session.clone().filter(|s| s.for_account(uuid)) {
                Some(current) => current,
                None => {
                    let signed = std::sync::Arc::new(self.sign_in(name, &join)?);
                    *session = Some(signed.clone());
                    signed
                }
            };
            if let Err(e) = self.sync(&current, saved) {
                if e == Error::SignedOut && !renewed {
                    *session = None;
                    renewed = true;
                    continue;
                }
                return Err(e);
            }
            match self.me(&current) {
                Ok(mut me) => {
                    for change in &saved.pending {
                        me.apply(change);
                    }
                    saved.me = Some(me);
                    return Ok(());
                }
                Err(Error::SignedOut) if !renewed => {
                    *session = None;
                    renewed = true;
                }
                Err(e) => return Err(e),
            }
        }
    }

    /// An item's file, from `cache` (`<id>-<hash>.json`, kept by hash: it never changes for one)
    /// or the service, then kept there. An entry whose id or hash isn't `Entry::plain` is refused
    /// before the disk or the service is touched.
    pub fn item_cached(
        &self,
        entry: &Entry,
        cache: &Path,
    ) -> Result<horizon_cosmetics::Item, Error> {
        if !entry.plain() {
            return Err(Error::Service(200));
        }
        let path = cache.join(format!("{}-{}.json", entry.id, entry.hash));
        if let Some(item) = std::fs::read(&path)
            .ok()
            .and_then(|b| horizon_cosmetics::Item::parse(&b).ok())
        {
            return Ok(item);
        }
        let bytes = self.item_bytes(entry)?;
        let item = horizon_cosmetics::Item::parse(&bytes).map_err(|_| Error::Service(200))?;
        if std::fs::create_dir_all(cache).is_ok() {
            let _ = std::fs::write(&path, &bytes);
        }
        Ok(item)
    }

    fn call(
        &self,
        method: &str,
        path: &str,
        session: Option<&Session>,
        body: Option<Value>,
    ) -> Result<Value, Error> {
        let url = format!("{}{path}", self.base);
        let mut request = agent(&url)
            .request(method, &url)
            .set("Accept", "application/json");
        if let Some(s) = session {
            if !s.live() {
                return Err(Error::SignedOut);
            }
            request = request.set("Authorization", &format!("Bearer {}", s.token));
        }
        let result = match body {
            Some(b) => request.send_json(b),
            None => request.call(),
        };
        let response = match result {
            Ok(r) => r,
            Err(ureq::Error::Status(status, r)) => {
                let code: Value = r.into_json().unwrap_or(Value::Null);
                return Err(match (status, code["error"].as_str().unwrap_or("")) {
                    (401, _) => Error::SignedOut,
                    (403, "not_owned") | (400, "wrong_slot") | (404, "item") => Error::NotYours,
                    (
                        _,
                        code @ ("player" | "name" | "owned" | "claimed" | "sales_off"
                        | "claim_closed" | "claim_not_open" | "not_for_sale" | "paddle"
                        | "amount" | "currency" | "items" | "overlap" | "use_checkout"
                        | "not_offered_here"),
                    ) => Error::Shop(code.into()),
                    (status, _) => Error::Service(status),
                });
            }
            Err(ureq::Error::Transport(_)) => return Err(Error::Offline),
        };
        response.into_json().map_err(|_| Error::Service(200))
    }
}

fn parse<T: for<'de> Deserialize<'de>>(v: Value) -> Result<T, Error> {
    serde_json::from_value(v).map_err(|_| Error::Service(200))
}

/// The launcher's user agent, a 15 s timeout and the player's proxy.
fn agent(url: &str) -> ureq::Agent {
    crate::proxy::agent(
        ureq::AgentBuilder::new()
            .timeout(Duration::from_secs(15))
            .user_agent(&format!("horizon-launcher/{}", crate::backend::VERSION)),
        url,
    )
    .build()
}

#[cfg(test)]
mod tests;
