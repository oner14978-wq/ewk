//! A tela "Selecionar Versões" do Cat Launcher: a barra roxa com o botão de voltar, o título e o
//! botão de atualizar, as abas Recentes, Antigas, Beta, Snapshot e Cobook e os cartões das
//! versões em colunas. Ela substitui a página de versões (`versions_page`).
//!
//! As versões são as oficiais do Minecraft: Java Edition, da lista da Mojang
//! (`minecraft_versions`): Recentes são as releases mais novas, Antigas as releases mais velhas e
//! as Alpha, Beta as Beta antigas e Snapshot os snapshots. Cobook é o sistema próprio do projeto:
//! as builds do Horizon (do GitHub) e as feitas ou importadas aqui.
//!
//! Instalar uma versão do Minecraft baixa os arquivos dela (`download_version_for_owner`, o mesmo
//! download do Jogar, que exige a conta que tem o jogo) e marca a pasta como baixada. Escolher
//! uma instalada abre a instância Java dela (a cria se não houver) para o Jogar iniciar.
use super::*;
use crate::new_instance::VersionList;
use gpui::{img, linear_color_stop, linear_gradient, rgb, Image, ImageFormat, ObjectFit};
use horizon_launcher::minecraft_versions::Kind as McKind;
use std::sync::{Arc, LazyLock};
use std::time::Duration;

const PIXEL: &str = "Pixelify Sans";
const GREEN: u32 = 0x3ddc97;
const VIOLET: u32 = 0x8b5cf6;
const PLATE: u32 = 0x140a2e;

/// As três miniaturas de Minecraft, recortadas da imagem de referência: os cartões as usam em
/// rodízio (o primeiro, o segundo e o terceiro cartão da lista têm as da referência).
static THUMBS: [LazyLock<Arc<Image>>; 3] = [
    LazyLock::new(|| {
        Arc::new(Image::from_bytes(
            ImageFormat::Png,
            include_bytes!("../assets/cat/thumb1.png").to_vec(),
        ))
    }),
    LazyLock::new(|| {
        Arc::new(Image::from_bytes(
            ImageFormat::Png,
            include_bytes!("../assets/cat/thumb2.png").to_vec(),
        ))
    }),
    LazyLock::new(|| {
        Arc::new(Image::from_bytes(
            ImageFormat::Png,
            include_bytes!("../assets/cat/thumb3.png").to_vec(),
        ))
    }),
];

/// As abas da tela.
#[derive(Clone, Copy, PartialEq, Eq, Default)]
pub(super) enum CatTab {
    #[default]
    Recent,
    Old,
    Beta,
    Snapshot,
    Cobook,
}

impl CatTab {
    const ALL: [CatTab; 5] = [
        CatTab::Recent,
        CatTab::Old,
        CatTab::Beta,
        CatTab::Snapshot,
        CatTab::Cobook,
    ];

    fn label(self) -> &'static str {
        match self {
            CatTab::Recent => "Recentes",
            CatTab::Old => "Antigas",
            CatTab::Beta => "Beta",
            CatTab::Snapshot => "Snapshot",
            CatTab::Cobook => "Cobook",
        }
    }

    fn badge(self) -> &'static str {
        match self {
            CatTab::Recent | CatTab::Old => "Release",
            CatTab::Beta => "Beta",
            CatTab::Snapshot => "Snapshot",
            CatTab::Cobook => "Cobook",
        }
    }

    fn about(self) -> &'static str {
        match self {
            CatTab::Recent | CatTab::Old => "Versão estável com todos os recursos",
            CatTab::Beta => "Versão de testes, pode ter falhas",
            CatTab::Snapshot => "Build diária com as novidades mais recentes",
            CatTab::Cobook => "Build feita ou importada neste computador",
        }
    }

    fn icon(self) -> Option<&'static str> {
        match self {
            CatTab::Recent => Some("favourite"),
            CatTab::Old => Some("clock"),
            CatTab::Beta => None,
            CatTab::Snapshot => Some("flash"),
            CatTab::Cobook => Some("package-01"),
        }
    }
}

/// De onde vem um cartão.
enum Source {
    /// Uma versão oficial do Minecraft: Java Edition (id e sha1 da lista da Mojang).
    Minecraft { sha1: String, kind: McKind },
    /// Uma build do Horizon (do GitHub), ou uma feita ou importada aqui (sem `Release`).
    Build(Option<Release>),
}

/// Um cartão: a versão e o que se sabe dela.
struct Card {
    id: String,
    title: String,
    date: String,
    source: Source,
    installed: bool,
    in_use: bool,
}

fn color(c: u32) -> Hsla {
    rgb(c).into()
}

fn alpha(c: u32, a: f32) -> Hsla {
    Hsla::from(rgb(c)).opacity(a)
}

/// O número da versão como o cartão o escreve: o nome da build sem o prefixo.
fn short_title(release: &Release) -> String {
    let name = release
        .name
        .split_once(": ")
        .map(|(_, rest)| rest.to_string())
        .unwrap_or_else(|| release.name.clone());
    let name = if name.is_empty() { release.tag.clone() } else { name };
    name.trim_start_matches('v').to_string()
}

/// A marca de que os arquivos de uma versão do Minecraft já foram baixados (a mesma que o Jogar
/// de uma instância Java usa).
fn downloaded_marker(id: &str) -> Option<std::path::PathBuf> {
    if id.is_empty() || id.contains(['/', '\\']) || id.contains("..") {
        return None;
    }
    Some(
        horizon_launcher::backend::data_dir()
            .join("minecraft")
            .join("versions")
            .join(id)
            .join(".downloaded"),
    )
}

/// Mais que isso por aba deixaria a lista pesada de desenhar.
const MAX_CARDS: usize = 60;

impl Launcher {
    /// As versões que uma aba mostra.
    fn cat_cards(&self, tab: CatTab) -> Vec<Card> {
        let selected_java = self
            .selected_instance()
            .and_then(|i| i.java.as_ref())
            .map(|j| j.minecraft.clone());
        let mc = |v: &horizon_launcher::minecraft_versions::Version| Card {
            id: v.id.clone(),
            title: v.id.clone(),
            date: v.released.get(..10).unwrap_or("").to_string(),
            source: Source::Minecraft {
                sha1: v.sha1.clone(),
                kind: v.kind,
            },
            installed: downloaded_marker(&v.id).is_some_and(|m| m.is_file()),
            in_use: selected_java.as_deref() == Some(v.id.as_str()),
        };
        if tab != CatTab::Cobook {
            let VersionList::Ready(list) = &self.instances.versions else {
                return Vec::new();
            };
            let releases = || list.all.iter().filter(|v| v.kind == McKind::Release);
            return match tab {
                CatTab::Recent => releases().take(9).map(mc).collect(),
                CatTab::Old => releases()
                    .skip(9)
                    .chain(list.all.iter().filter(|v| v.kind == McKind::OldAlpha))
                    .take(MAX_CARDS)
                    .map(mc)
                    .collect(),
                CatTab::Beta => list
                    .all
                    .iter()
                    .filter(|v| v.kind == McKind::OldBeta)
                    .take(MAX_CARDS)
                    .map(mc)
                    .collect(),
                _ => list
                    .all
                    .iter()
                    .filter(|v| v.kind == McKind::Snapshot)
                    .take(MAX_CARDS)
                    .map(mc)
                    .collect(),
            };
        }
        // Cobook: o sistema do projeto, as builds do Horizon.
        let mut cards: Vec<Card> = Vec::new();
        if let Load::Ready(releases) = &self.releases {
            for r in releases.iter().take(MAX_CARDS) {
                cards.push(Card {
                    id: r.tag.clone(),
                    title: short_title(r),
                    date: crate::glass_versions::published(&r.date, &r.time),
                    source: Source::Build(Some(r.clone())),
                    installed: self.installed.contains(&r.tag),
                    in_use: self.selected().map(String::as_str) == Some(r.tag.as_str()),
                });
            }
        }
        for v in self
            .installed
            .iter()
            .filter(|v| native_mods::is_native(v) || build_import::is_imported(v))
        {
            if cards.iter().any(|c| &c.id == v) {
                continue;
            }
            cards.push(Card {
                id: v.clone(),
                title: horizon_launcher::nightly::label(v).unwrap_or_else(|| v.clone()),
                date: String::new(),
                source: Source::Build(None),
                installed: true,
                in_use: self.selected().map(String::as_str) == Some(v.as_str()),
            });
        }
        cards
    }

    /// Pergunta a lista de versões à Mojang, na primeira vez que a tela abre.
    fn cat_ask_versions(&mut self, cx: &mut Context<Self>) {
        self.load_versions(cx);
    }

    /// O botão de atualizar: a lista da Mojang e as builds do Horizon de novo.
    fn cat_refresh(&mut self, cx: &mut Context<Self>) {
        self.instances.versions = VersionList::NotAsked;
        self.load_versions(cx);
        self.fetch_releases();
    }

    /// Baixa os arquivos de uma versão do Minecraft, com o progresso na tela.
    fn cat_install_mc(&mut self, id: String, sha1: String, cx: &mut Context<Self>) {
        if self.cat_installing.is_some() {
            return;
        }
        let Some(marker) = downloaded_marker(&id) else {
            self.cat_error = Some((id, "Nome de versão inválido.".to_string()));
            return;
        };
        self.cat_installing = Some(id.clone());
        self.cat_error = None;
        let (job_id, job_sha1) = (id.clone(), sha1);
        let task = cx.background_executor().spawn(async move {
            horizon_launcher::backend::download_version_for_owner(&job_id, &job_sha1, &|_line| {})?;
            if let Some(dir) = marker.parent() {
                let _ = std::fs::create_dir_all(dir);
            }
            std::fs::write(&marker, "").map_err(|e| format!("{}: {e}", marker.display()))
        });
        cx.spawn(async move |this, cx| {
            let done = task.await;
            let _ = this.update(cx, |this, cx| {
                this.cat_installing = None;
                if let Err(e) = done {
                    this.cat_error = Some((id, e));
                }
                cx.notify();
            });
        })
        .detach();
        // Redesenha enquanto baixa, para o progresso andar.
        cx.spawn(async move |this, cx| loop {
            cx.background_executor().timer(Duration::from_millis(300)).await;
            match this.update(cx, |this, cx| {
                cx.notify();
                this.cat_installing.is_some()
            }) {
                Ok(true) => {}
                _ => break,
            }
        })
        .detach();
    }

    /// Escolhe uma versão do Minecraft já baixada para jogar: a instância Java dela (feita agora
    /// se não houver), que o Jogar inicia.
    fn cat_pick_mc(&mut self, id: &str) {
        let existing = self
            .instances
            .list
            .iter()
            .find(|i| i.java.as_ref().is_some_and(|j| j.minecraft == id))
            .cloned();
        let instance = match existing {
            Some(i) => i,
            None => match instances::create_java(&format!("Minecraft {id}"), id) {
                Ok(i) => {
                    self.reload_instances();
                    i
                }
                Err(e) => {
                    self.cat_error = Some((id.to_string(), e));
                    return;
                }
            },
        };
        self.select_instance(&instance);
    }

    /// A tela inteira, no lugar da página de versões.
    pub(super) fn cat_versions(&mut self, cx: &mut Context<Self>) -> Div {
        if matches!(self.instances.versions, VersionList::NotAsked) {
            self.cat_ask_versions(cx);
        }
        let width = self.window_width.max(640.);
        let s = (width / 2231.).max(0.3);
        let tab = self.cat_tab;
        let columns = if width >= 1000. { 3. } else if width >= 700. { 2. } else { 1. };
        let gutter = 30. * s;
        let gap = 38. * s;
        let card_w = (width - gutter * 2. - gap * (columns - 1.)) / columns;

        // ---- A barra roxa, com o botão de voltar ----
        let back = div()
            .id("cat-versions-back")
            .flex()
            .items_center()
            .justify_center()
            .flex_none()
            .size(px(90. * s))
            .rounded(px(45. * s))
            .border(px(3. * s))
            .border_color(color(0xa879ff))
            .bg(color(0x6a2fe0))
            .cursor_pointer()
            .font_family(PIXEL)
            .text_size(px(56. * s))
            .text_color(rgb(0xffffff))
            .child("←")
            .on_click(cx.listener(|this, _: &ClickEvent, _, cx| {
                this.go(Page::Play);
                cx.notify();
            }));
        let bar = div()
            .flex()
            .items_center()
            .w_full()
            .h(px(108. * s))
            .pl(px(5. * s))
            .rounded_b(px(28. * s))
            .bg(linear_gradient(
                90.,
                linear_color_stop(rgb(0x3a1085), 0.),
                linear_color_stop(rgb(0x4b18a8), 1.),
            ))
            .child(back);

        // ---- O título e o botão de atualizar ----
        let loading = matches!(self.instances.versions, VersionList::Loading);
        let refresh = div()
            .id("cat-versions-refresh")
            .flex()
            .items_center()
            .justify_center()
            .flex_none()
            .size(px(94. * s))
            .rounded(px(47. * s))
            .border(px(3. * s))
            .border_color(color(VIOLET))
            .cursor_pointer()
            .opacity(if loading { 0.5 } else { 1. })
            .child(crate::glass_ui::icon("refresh", 46. * s, color(0xe9dcff)))
            .on_click(cx.listener(|this, _: &ClickEvent, _, cx| {
                this.cat_refresh(cx);
                cx.notify();
            }));
        let head = div()
            .flex()
            .items_center()
            .justify_between()
            .px(px(gutter))
            .mt(px(26. * s))
            .child(
                div()
                    .font_family(horizon_theme::glass::FONT)
                    .font_weight(FontWeight::BOLD)
                    .text_size(px(62. * s))
                    .text_color(rgb(0xffffff))
                    .child("Selecionar Versões"),
            )
            .child(refresh);

        // ---- As abas ----
        let mut tabs = div()
            .flex()
            .flex_wrap()
            .items_center()
            .gap(px(28. * s))
            .px(px(gutter))
            .mt(px(40. * s));
        for t in CatTab::ALL {
            let on = t == tab;
            let icon: AnyElement = match t.icon() {
                Some(name) => crate::glass_ui::icon(
                    name,
                    40. * s,
                    color(match (t, on) {
                        (CatTab::Recent, _) => 0x4ade80,
                        (CatTab::Snapshot, _) => 0xff6b6b,
                        _ => 0xb79cff,
                    }),
                )
                .into_any_element(),
                None => div()
                    .text_size(px(40. * s))
                    .text_color(color(0xb79cff))
                    .child("β")
                    .into_any_element(),
            };
            tabs = tabs.child(
                div()
                    .id(SharedString::from(format!("cat-tab-{}", t.label())))
                    .flex()
                    .items_center()
                    .gap(px(18. * s))
                    .h(px(108. * s))
                    .px(px(40. * s))
                    .rounded(px(40. * s))
                    .border(px(3. * s))
                    .border_color(color(if on { 0xe44fd8 } else { 0x2a1a4d }))
                    .bg(color(if on { 0x3a1a7a } else { PLATE }))
                    .cursor_pointer()
                    .font_family(horizon_theme::glass::FONT)
                    .font_weight(FontWeight::MEDIUM)
                    .text_size(px(44. * s))
                    .text_color(rgb(0xffffff))
                    .child(icon)
                    .child(t.label())
                    .on_click(cx.listener(move |this, _: &ClickEvent, _, cx| {
                        this.cat_tab = t;
                        cx.notify();
                    })),
            );
        }

        // ---- Os cartões ----
        let waiting = match (tab, &self.instances.versions, &self.releases) {
            (CatTab::Cobook, _, Load::Loading) => Some("Carregando versões…".to_string()),
            (CatTab::Cobook, _, Load::Failed(e)) => {
                Some(format!("Não foi possível carregar as versões. {e}"))
            }
            (CatTab::Cobook, _, _) => None,
            (_, VersionList::NotAsked | VersionList::Loading, _) => {
                Some("Carregando versões…".to_string())
            }
            (_, VersionList::Failed(e), _) => {
                Some(format!("Não foi possível carregar as versões. {e}"))
            }
            _ => None,
        };
        let error = self.cat_error.clone();
        let body: AnyElement = match waiting {
            Some(text) => self.cat_note(&text, s).into_any_element(),
            None => {
                let cards = self.cat_cards(tab);
                if cards.is_empty() {
                    self.cat_note("Nenhuma versão nesta categoria.", s)
                        .into_any_element()
                } else {
                    let mut grid = div()
                        .flex()
                        .flex_wrap()
                        .gap(px(gap))
                        .px(px(gutter))
                        .mt(px(36. * s))
                        .pb(px(40. * s));
                    for (n, card) in cards.into_iter().enumerate() {
                        grid = grid.child(self.cat_card(card, n, tab, card_w, s, cx));
                    }
                    grid.into_any_element()
                }
            }
        };

        div()
            .flex()
            .flex_col()
            .min_w_0()
            .mx(px(-crate::theme::PAGE_GUTTER))
            .mt(px(-crate::theme::PAGE_GUTTER))
            .bg(linear_gradient(
                180.,
                linear_color_stop(rgb(0x3a1585), 0.),
                linear_color_stop(rgb(0x120626), 1.),
            ))
            .child(bar)
            .child(head)
            .child(tabs)
            .children(error.map(|(id, e)| self.cat_note(&format!("{id}: {e}"), s)))
            .child(body)
    }

    fn cat_note(&self, text: &str, s: f32) -> Div {
        div()
            .px(px(30. * s))
            .mt(px(40. * s))
            .font_family(horizon_theme::glass::FONT)
            .text_size(px(36. * s))
            .text_color(color(0xcbb8ff))
            .child(text.to_string())
    }

    /// Um cartão: a miniatura, o número, a identificação, o nome e a descrição. Instalada: borda
    /// verde e o selo INSTALADA. O clique baixa e instala, ou escolhe a versão para jogar.
    fn cat_card(
        &self,
        card: Card,
        n: usize,
        tab: CatTab,
        w: f32,
        s: f32,
        cx: &mut Context<Self>,
    ) -> Stateful<Div> {
        let id = card.id.clone();
        let installed = card.installed;
        let mc_progress = (self.cat_installing.as_deref() == Some(id.as_str())).then(|| {
            horizon_launcher::mojang::progress().map(|(d, t)| d as f32 / t.max(1) as f32)
        });
        let build_progress = match &card.source {
            Source::Build(_) => self
                .installing
                .as_ref()
                .filter(|(t, _)| *t == id)
                .map(|(_, p)| Some(*p)),
            _ => None,
        };
        let progress: Option<Option<f32>> = mc_progress.or(build_progress);
        let border = if installed { GREEN } else { VIOLET };
        let banner_h = 390. * s;

        let mut art = div()
            .relative()
            .w_full()
            .h(px(banner_h))
            .overflow_hidden()
            .child(
                img(THUMBS[n % 3].clone())
                    .w(px(w))
                    .h(px(banner_h))
                    .object_fit(ObjectFit::Cover),
            );
        if installed {
            art = art.child(
                div()
                    .absolute()
                    .top(px(18. * s))
                    .right(px(18. * s))
                    .flex()
                    .items_center()
                    .h(px(76. * s))
                    .px(px(20. * s))
                    .rounded(px(22. * s))
                    .border(px(3. * s))
                    .border_color(color(GREEN))
                    .bg(alpha(0x000000, 0.8))
                    .font_family(PIXEL)
                    .font_weight(FontWeight::BOLD)
                    .text_size(px(34. * s))
                    .text_color(color(GREEN))
                    .child("✔ INSTALADA"),
            );
        }
        let (badge, about, name) = match &card.source {
            Source::Minecraft { kind, .. } => match kind {
                McKind::Release => ("Release", "Versão estável com todos os recursos", "Minecraft Java Edition"),
                McKind::Snapshot => ("Snapshot", "Prévia com as novidades em teste", "Minecraft Java Edition"),
                McKind::OldBeta => ("Beta", "Versão beta antiga do Minecraft", "Minecraft Java Edition"),
                McKind::OldAlpha => ("Alpha", "Versão alpha antiga do Minecraft", "Minecraft Java Edition"),
            },
            Source::Build(_) => ("Cobook", tab.about(), "Cat Launcher"),
        };
        let status: String = match progress {
            Some(Some(p)) => format!("Instalando {:.0}%", p * 100.),
            Some(None) => "Instalando…".to_string(),
            None if card.in_use => "Selecionada para jogar".to_string(),
            None if installed => "Toque para jogar com esta versão".to_string(),
            None => match &card.source {
                Source::Build(Some(r)) if r.asset.is_none() => {
                    "Sem build para esta plataforma".to_string()
                }
                _ => "Toque para baixar e instalar".to_string(),
            },
        };
        let info = div()
            .flex()
            .flex_col()
            .gap(px(8. * s))
            .p(px(30. * s))
            .bg(color(PLATE))
            .child(
                div()
                    .flex()
                    .items_center()
                    .justify_between()
                    .child(
                        div()
                            .font_family(horizon_theme::glass::FONT)
                            .font_weight(FontWeight::BOLD)
                            .text_size(px(60. * s))
                            .text_color(rgb(0xffffff))
                            .child(card.title.clone()),
                    )
                    .child(
                        div()
                            .flex()
                            .items_center()
                            .h(px(76. * s))
                            .px(px(20. * s))
                            .rounded(px(20. * s))
                            .border(px(3. * s))
                            .border_color(color(0xa879ff))
                            .font_family(PIXEL)
                            .text_size(px(34. * s))
                            .text_color(color(0xd9c8ff))
                            .child(badge),
                    ),
            )
            .child(
                div()
                    .font_family(horizon_theme::glass::FONT)
                    .font_weight(FontWeight::SEMIBOLD)
                    .text_size(px(46. * s))
                    .text_color(color(0xc77dff))
                    .child(name),
            )
            .child(
                div()
                    .font_family(horizon_theme::glass::FONT)
                    .text_size(px(40. * s))
                    .text_color(color(0xcbb8ff))
                    .child(about),
            )
            .children((!card.date.is_empty()).then(|| {
                div()
                    .font_family(horizon_theme::glass::FONT)
                    .text_size(px(34. * s))
                    .text_color(alpha(0xcbb8ff, 0.7))
                    .child(card.date.clone())
            }))
            .child(
                div()
                    .font_family(PIXEL)
                    .text_size(px(34. * s))
                    .text_color(color(if installed || progress.is_some() { GREEN } else { 0xe9dcff }))
                    .child(status),
            )
            .children(progress.map(|p| {
                div()
                    .w_full()
                    .h(px(10. * s))
                    .rounded(px(5. * s))
                    .bg(alpha(0xffffff, 0.15))
                    .child(
                        div()
                            .h_full()
                            .w(relative(p.unwrap_or(0.05).clamp(0., 1.)))
                            .rounded(px(5. * s))
                            .bg(color(GREEN)),
                    )
            }));

        let frame = div()
            .id(SharedString::from(format!("cat-card-{id}")))
            .flex()
            .flex_col()
            .flex_none()
            .w(px(w))
            .overflow_hidden()
            .rounded(px(48. * s))
            .border(px(4. * s))
            .border_color(color(border))
            .child(art)
            .child(info);
        let busy = self.cat_installing.is_some() || self.installing.is_some();
        match card.source {
            Source::Minecraft { sha1, .. } => {
                if installed {
                    frame
                        .cursor_pointer()
                        .on_click(cx.listener(move |this, _: &ClickEvent, _, cx| {
                            this.cat_pick_mc(&id);
                            cx.notify();
                        }))
                } else if !busy {
                    frame
                        .cursor_pointer()
                        .on_click(cx.listener(move |this, _: &ClickEvent, _, cx| {
                            this.cat_install_mc(id.clone(), sha1.clone(), cx);
                            cx.notify();
                        }))
                } else {
                    frame.cursor_default()
                }
            }
            Source::Build(release) => {
                if installed {
                    frame
                        .cursor_pointer()
                        .on_click(cx.listener(move |this, _: &ClickEvent, _, cx| {
                            this.settings.selected = Some(id.clone());
                            this.save_settings();
                            cx.notify();
                        }))
                } else {
                    match release {
                        Some(r) if r.asset.is_some() && !busy => frame
                            .cursor_pointer()
                            .on_click(cx.listener(move |this, _: &ClickEvent, _, cx| {
                                this.install(&r);
                                cx.notify();
                            })),
                        _ => frame.cursor_default(),
                    }
                }
            }
        }
    }
}
