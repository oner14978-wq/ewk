//! What the secret stores share: one lock for the keychain.
use std::sync::Mutex;

/// The process lock of the stores that share one keychain ([`super::SecretStore::operations`]).
pub(super) fn process_lock() -> &'static Mutex<()> {
    static OPERATIONS: Mutex<()> = Mutex::new(());
    &OPERATIONS
}

/// The Wardrobe proves who plays to a service with a Microsoft token, which this launcher no
/// longer has: it never joins.
pub fn join_server(_who: &str, _server_id: &str) -> Result<(), String> {
    Err("The Wardrobe needs a Microsoft account, and this launcher plays offline.".into())
}
