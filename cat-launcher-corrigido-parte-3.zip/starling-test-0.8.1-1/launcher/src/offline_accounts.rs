//! Cat Launcher's accounts: offline only. A profile is a player name, an offline UUID that never
//! changes, and an optional local skin and cape. Nothing here talks to the network and there is
//! no sign-in, no token and no keychain.
//!
//! Everything lives in the launcher's data folder (`backend::data_dir()`):
//!
//! ```text
//! offline_accounts.json            the list and the selected profile
//! offline/<uuid>/skin.png          the profile's skin (optional)
//! offline/<uuid>/cape.png          the profile's cape (optional)
//! ```
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};

const FILE: &str = "offline_accounts.json";
const FOLDER: &str = "offline";
const SKIN_FILE: &str = "skin.png";
const CAPE_FILE: &str = "cape.png";

/// The arm model of a skin.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum SkinModel {
    /// Steve's 4-pixel arms.
    #[default]
    Classic,
    /// Alex's 3-pixel arms.
    Slim,
}

impl SkinModel {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::Classic => "classic",
            Self::Slim => "slim",
        }
    }
}

/// One offline profile (no secrets exist for it).
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct OfflineAccount {
    /// The offline UUID without dashes, made once from the name when the profile is created
    /// and kept even if the profile is edited later.
    pub uuid: String,
    pub name: String,
    #[serde(default)]
    pub skin_model: SkinModel,
    #[serde(default)]
    pub has_skin: bool,
    #[serde(default)]
    pub has_cape: bool,
}

impl OfflineAccount {
    /// This profile's folder inside the launcher's data folder `dir`.
    pub fn folder(&self, dir: &Path) -> PathBuf {
        dir.join(FOLDER).join(&self.uuid)
    }
    /// The local skin, when the profile has one.
    pub fn skin_path(&self, dir: &Path) -> Option<PathBuf> {
        self.has_skin.then(|| self.folder(dir).join(SKIN_FILE))
    }
    /// The local cape, when the profile has one.
    pub fn cape_path(&self, dir: &Path) -> Option<PathBuf> {
        self.has_cape.then(|| self.folder(dir).join(CAPE_FILE))
    }
}

/// The saved profiles and the one that plays.
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct OfflineAccounts {
    pub accounts: Vec<OfflineAccount>,
    /// The UUID of the profile the game starts with; none (or an unknown one): the first.
    pub selected: Option<String>,
}

impl OfflineAccounts {
    pub fn load() -> Self {
        Self::load_from(&crate::backend::data_dir())
    }

    pub fn save(&self) -> Result<(), String> {
        self.save_to(&crate::backend::data_dir())
    }

    pub fn load_from(dir: &Path) -> Self {
        std::fs::read_to_string(dir.join(FILE))
            .ok()
            .and_then(|text| serde_json::from_str(&text).ok())
            .unwrap_or_default()
    }

    /// Written to a temporary file first, so a crash never leaves half a list.
    pub fn save_to(&self, dir: &Path) -> Result<(), String> {
        std::fs::create_dir_all(dir).map_err(|e| e.to_string())?;
        let text = serde_json::to_string_pretty(self).map_err(|e| e.to_string())?;
        let target = dir.join(FILE);
        let temporary = dir.join(format!("{FILE}.tmp"));
        std::fs::write(&temporary, text + "\n").map_err(|e| e.to_string())?;
        std::fs::rename(&temporary, &target).map_err(|e| e.to_string())
    }

    /// The profile that plays: the selected one, else the first.
    pub fn selected(&self) -> Option<&OfflineAccount> {
        self.selected
            .as_ref()
            .and_then(|uuid| self.accounts.iter().find(|a| &a.uuid == uuid))
            .or_else(|| self.accounts.first())
    }

    /// A profile by name (any case) or by UUID (with or without dashes).
    pub fn find(&self, who: &str) -> Option<&OfflineAccount> {
        let undashed = who.replace('-', "").to_lowercase();
        self.accounts
            .iter()
            .find(|a| a.name.eq_ignore_ascii_case(who) || a.uuid == undashed)
    }

    /// Makes a profile and selects it. Everything is checked before anything is written, and
    /// the skin and cape files are copied into the profile's own folder.
    pub fn create(
        &mut self,
        dir: &Path,
        name: &str,
        skin: Option<(&Path, SkinModel)>,
        cape: Option<&Path>,
    ) -> Result<OfflineAccount, String> {
        let name = name.trim();
        valid_name(name)?;
        if self.find(name).is_some() {
            return Err("A profile with that name already exists.".into());
        }
        if let Some((path, _)) = skin {
            check_skin(path)?;
        }
        if let Some(path) = cape {
            check_cape(path)?;
        }
        let account = OfflineAccount {
            uuid: offline_uuid(name),
            name: name.to_owned(),
            skin_model: skin.map_or(SkinModel::Classic, |(_, model)| model),
            has_skin: skin.is_some(),
            has_cape: cape.is_some(),
        };
        let folder = account.folder(dir);
        let copied = (|| -> Result<(), String> {
            if skin.is_some() || cape.is_some() {
                std::fs::create_dir_all(&folder).map_err(|e| e.to_string())?;
            }
            if let Some((path, _)) = skin {
                std::fs::copy(path, folder.join(SKIN_FILE)).map_err(|e| e.to_string())?;
            }
            if let Some(path) = cape {
                std::fs::copy(path, folder.join(CAPE_FILE)).map_err(|e| e.to_string())?;
            }
            Ok(())
        })();
        if let Err(e) = copied {
            let _ = std::fs::remove_dir_all(&folder);
            return Err(e);
        }
        self.selected = Some(account.uuid.clone());
        self.accounts.push(account.clone());
        Ok(account)
    }

    /// Plays as this profile from now on.
    pub fn select(&mut self, who: &str) -> Result<(), String> {
        let uuid = self.find(who).ok_or("No such profile.")?.uuid.clone();
        self.selected = Some(uuid);
        Ok(())
    }

    /// Deletes a profile and its skin and cape. When it was the one that plays, the first of
    /// the others takes over.
    pub fn remove(&mut self, dir: &Path, who: &str) -> Result<(), String> {
        let account = self.find(who).ok_or("No such profile.")?.clone();
        let folder = account.folder(dir);
        if folder.exists() {
            std::fs::remove_dir_all(&folder).map_err(|e| e.to_string())?;
        }
        self.accounts.retain(|a| a.uuid != account.uuid);
        if self.selected.as_deref() == Some(account.uuid.as_str()) {
            self.selected = self.accounts.first().map(|a| a.uuid.clone());
        }
        Ok(())
    }

    /// A new skin for a profile, or none to take its skin away.
    pub fn set_skin(
        &mut self,
        dir: &Path,
        who: &str,
        skin: Option<(&Path, SkinModel)>,
    ) -> Result<(), String> {
        if let Some((path, _)) = skin {
            check_skin(path)?;
        }
        let index = self.index_of(who)?;
        let folder = self.accounts[index].folder(dir);
        match skin {
            Some((path, model)) => {
                std::fs::create_dir_all(&folder).map_err(|e| e.to_string())?;
                std::fs::copy(path, folder.join(SKIN_FILE)).map_err(|e| e.to_string())?;
                self.accounts[index].has_skin = true;
                self.accounts[index].skin_model = model;
            }
            None => {
                let _ = std::fs::remove_file(folder.join(SKIN_FILE));
                self.accounts[index].has_skin = false;
            }
        }
        Ok(())
    }

    /// A new local cape for a profile, or none to take it away.
    pub fn set_cape(&mut self, dir: &Path, who: &str, cape: Option<&Path>) -> Result<(), String> {
        if let Some(path) = cape {
            check_cape(path)?;
        }
        let index = self.index_of(who)?;
        let folder = self.accounts[index].folder(dir);
        match cape {
            Some(path) => {
                std::fs::create_dir_all(&folder).map_err(|e| e.to_string())?;
                std::fs::copy(path, folder.join(CAPE_FILE)).map_err(|e| e.to_string())?;
                self.accounts[index].has_cape = true;
            }
            None => {
                let _ = std::fs::remove_file(folder.join(CAPE_FILE));
                self.accounts[index].has_cape = false;
            }
        }
        Ok(())
    }

    fn index_of(&self, who: &str) -> Result<usize, String> {
        let uuid = &self.find(who).ok_or("No such profile.")?.uuid;
        self.accounts
            .iter()
            .position(|a| &a.uuid == uuid)
            .ok_or_else(|| "No such profile.".to_owned())
    }
}

/// A Minecraft player name: 3 to 16 letters, digits or underscores.
pub fn valid_name(name: &str) -> Result<(), String> {
    let length = name.chars().count();
    if !(3..=16).contains(&length) {
        return Err("The name needs 3 to 16 characters.".into());
    }
    if !name.chars().all(|c| c.is_ascii_alphanumeric() || c == '_') {
        return Err("The name can only have letters, digits and underscores.".into());
    }
    Ok(())
}

/// The UUID Minecraft itself gives an offline player: the version 3 UUID of the MD5 of
/// `OfflinePlayer:<name>` (Java's `UUID.nameUUIDFromBytes`), written without dashes.
pub fn offline_uuid(name: &str) -> String {
    let mut bytes = md5(format!("OfflinePlayer:{name}").as_bytes());
    bytes[6] = (bytes[6] & 0x0f) | 0x30;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    bytes.iter().map(|b| format!("{b:02x}")).collect()
}

/// A PNG's width and height, from its header.
fn png_size(path: &Path) -> Result<(u32, u32), String> {
    use std::io::Read;
    let mut header = [0u8; 24];
    std::fs::File::open(path)
        .and_then(|mut file| file.read_exact(&mut header))
        .map_err(|_| "That file is not a PNG image.".to_owned())?;
    if header[..8] != [0x89, b'P', b'N', b'G', 0x0d, 0x0a, 0x1a, 0x0a] || &header[12..16] != b"IHDR" {
        return Err("That file is not a PNG image.".into());
    }
    let width = u32::from_be_bytes([header[16], header[17], header[18], header[19]]);
    let height = u32::from_be_bytes([header[20], header[21], header[22], header[23]]);
    Ok((width, height))
}

/// A skin is 64x64 or the old 64x32, or either one scaled up by a whole number.
fn check_skin(path: &Path) -> Result<(), String> {
    let (w, h) = png_size(path)?;
    let scaled = w >= 64 && w % 64 == 0 && (h == w || h * 2 == w);
    if scaled {
        Ok(())
    } else {
        Err("A skin must be a 64x64 or 64x32 PNG.".into())
    }
}

/// A cape is 64x32 (or scaled up), or the small 22x17 and 46x22 ones.
fn check_cape(path: &Path) -> Result<(), String> {
    let (w, h) = png_size(path)?;
    let scaled = w >= 64 && w % 64 == 0 && h * 2 == w;
    if scaled || (w, h) == (22, 17) || (w, h) == (46, 22) {
        Ok(())
    } else {
        Err("A cape must be a 64x32 PNG.".into())
    }
}

/// MD5 (RFC 1321), only to make the offline UUID the way Minecraft does.
fn md5(data: &[u8]) -> [u8; 16] {
    const SHIFTS: [u32; 64] = [
        7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5,
        9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10,
        15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21,
    ];
    let constants: Vec<u32> = (0..64)
        .map(|i| ((i as f64 + 1.0).sin().abs() * 4294967296.0) as u32)
        .collect();
    let (mut a0, mut b0, mut c0, mut d0) =
        (0x6745_2301u32, 0xefcd_ab89u32, 0x98ba_dcfeu32, 0x1032_5476u32);
    let mut message = data.to_vec();
    message.push(0x80);
    while message.len() % 64 != 56 {
        message.push(0);
    }
    message.extend_from_slice(&((data.len() as u64).wrapping_mul(8)).to_le_bytes());
    for chunk in message.chunks(64) {
        let mut words = [0u32; 16];
        for (i, word) in words.iter_mut().enumerate() {
            *word = u32::from_le_bytes([
                chunk[4 * i],
                chunk[4 * i + 1],
                chunk[4 * i + 2],
                chunk[4 * i + 3],
            ]);
        }
        let (mut a, mut b, mut c, mut d) = (a0, b0, c0, d0);
        for i in 0..64usize {
            let (f, g) = match i / 16 {
                0 => ((b & c) | (!b & d), i),
                1 => ((d & b) | (!d & c), (5 * i + 1) % 16),
                2 => (b ^ c ^ d, (3 * i + 5) % 16),
                _ => (c ^ (b | !d), (7 * i) % 16),
            };
            let mixed = f
                .wrapping_add(a)
                .wrapping_add(constants[i])
                .wrapping_add(words[g]);
            a = d;
            d = c;
            c = b;
            b = b.wrapping_add(mixed.rotate_left(SHIFTS[i]));
        }
        a0 = a0.wrapping_add(a);
        b0 = b0.wrapping_add(b);
        c0 = c0.wrapping_add(c);
        d0 = d0.wrapping_add(d);
    }
    let mut out = [0u8; 16];
    out[0..4].copy_from_slice(&a0.to_le_bytes());
    out[4..8].copy_from_slice(&b0.to_le_bytes());
    out[8..12].copy_from_slice(&c0.to_le_bytes());
    out[12..16].copy_from_slice(&d0.to_le_bytes());
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A file that starts like a PNG of this size (enough for the size checks).
    fn png(dir: &Path, file: &str, w: u32, h: u32) -> PathBuf {
        let mut bytes = vec![0x89, b'P', b'N', b'G', 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 13];
        bytes.extend_from_slice(b"IHDR");
        bytes.extend_from_slice(&w.to_be_bytes());
        bytes.extend_from_slice(&h.to_be_bytes());
        let path = dir.join(file);
        std::fs::write(&path, bytes).unwrap();
        path
    }

    fn hex(bytes: [u8; 16]) -> String {
        bytes.iter().map(|b| format!("{b:02x}")).collect()
    }

    #[test]
    fn md5_matches_the_reference_values() {
        assert_eq!(hex(md5(b"")), "d41d8cd98f00b204e9800998ecf8427e");
        assert_eq!(hex(md5(b"abc")), "900150983cd24fb0d6963f7d28e17f72");
    }

    #[test]
    fn offline_uuids_are_the_ones_minecraft_makes() {
        assert_eq!(offline_uuid("Notch"), "b50ad385829d3141a2167e7d7539ba7f");
        assert_eq!(offline_uuid("Steve"), "5627dd98e6be3c21b8a8e92344183641");
        assert_eq!(offline_uuid("Gato_123"), "626c20114cea3b3cab371b722410bb58");
    }

    #[test]
    fn names_are_checked() {
        assert!(valid_name("Gato_123").is_ok());
        assert!(valid_name("ab").is_err());
        assert!(valid_name("a_name_way_too_long").is_err());
        assert!(valid_name("with space").is_err());
        assert!(valid_name("açaí").is_err());
    }

    #[test]
    fn create_select_and_remove() {
        let dir = tempfile::tempdir().unwrap();
        let mut list = OfflineAccounts::default();
        let one = list.create(dir.path(), "Gato", None, None).unwrap();
        let two = list.create(dir.path(), "Cachorro", None, None).unwrap();
        assert_eq!(one.uuid, offline_uuid("Gato"));
        assert_eq!(list.accounts.len(), 2);
        // The last one made plays.
        assert_eq!(list.selected().unwrap().uuid, two.uuid);
        list.select("gato").unwrap();
        assert_eq!(list.selected().unwrap().uuid, one.uuid);
        assert!(list.select("Ninguem").is_err());
        // The same name twice, in any case, is refused.
        assert!(list.create(dir.path(), "GATO", None, None).is_err());
        list.remove(dir.path(), "Gato").unwrap();
        assert_eq!(list.accounts.len(), 1);
        assert_eq!(list.selected().unwrap().uuid, two.uuid);
        list.remove(dir.path(), &two.uuid).unwrap();
        assert!(list.accounts.is_empty());
        assert!(list.selected().is_none());
    }

    #[test]
    fn skins_and_capes_are_kept_per_profile() {
        let dir = tempfile::tempdir().unwrap();
        let files = tempfile::tempdir().unwrap();
        let skin = png(files.path(), "skin.png", 64, 64);
        let cape = png(files.path(), "cape.png", 64, 32);
        let mut list = OfflineAccounts::default();
        let a = list
            .create(dir.path(), "Gato", Some((&skin, SkinModel::Slim)), Some(&cape))
            .unwrap();
        let b = list.create(dir.path(), "Cachorro", None, None).unwrap();
        assert!(a.skin_path(dir.path()).unwrap().is_file());
        assert!(a.cape_path(dir.path()).unwrap().is_file());
        assert_eq!(a.skin_model, SkinModel::Slim);
        assert!(b.skin_path(dir.path()).is_none());
        list.set_skin(dir.path(), "Cachorro", Some((&skin, SkinModel::Classic)))
            .unwrap();
        assert!(list.find("Cachorro").unwrap().has_skin);
        list.set_skin(dir.path(), "Cachorro", None).unwrap();
        assert!(!list.find("Cachorro").unwrap().has_skin);
        list.set_cape(dir.path(), "Gato", None).unwrap();
        assert!(!list.find("Gato").unwrap().has_cape);
        // Deleting a profile takes its folder with it.
        let folder = a.folder(dir.path());
        list.remove(dir.path(), "Gato").unwrap();
        assert!(!folder.exists());
    }

    #[test]
    fn bad_images_are_refused_and_nothing_is_made() {
        let dir = tempfile::tempdir().unwrap();
        let files = tempfile::tempdir().unwrap();
        let wide = png(files.path(), "wide.png", 100, 10);
        let text = files.path().join("text.png");
        std::fs::write(&text, "not an image at all, just text").unwrap();
        let mut list = OfflineAccounts::default();
        assert!(list
            .create(dir.path(), "Gato", Some((&wide, SkinModel::Classic)), None)
            .is_err());
        assert!(list
            .create(dir.path(), "Gato", Some((&text, SkinModel::Classic)), None)
            .is_err());
        assert!(list.create(dir.path(), "Gato", None, Some(&wide)).is_err());
        assert!(list.accounts.is_empty());
    }

    #[test]
    fn profiles_survive_a_restart_with_their_uuid() {
        let dir = tempfile::tempdir().unwrap();
        let files = tempfile::tempdir().unwrap();
        let skin = png(files.path(), "skin.png", 64, 64);
        let mut list = OfflineAccounts::default();
        list.create(dir.path(), "Gato", Some((&skin, SkinModel::Slim)), None)
            .unwrap();
        list.create(dir.path(), "Cachorro", None, None).unwrap();
        list.select("Gato").unwrap();
        list.save_to(dir.path()).unwrap();
        let again = OfflineAccounts::load_from(dir.path());
        assert_eq!(again, list);
        assert_eq!(again.selected().unwrap().uuid, offline_uuid("Gato"));
        assert!(again.selected().unwrap().skin_path(dir.path()).unwrap().is_file());
        // A missing or broken file is an empty list, not a crash.
        assert!(OfflineAccounts::load_from(&dir.path().join("nada")).accounts.is_empty());
    }
}
