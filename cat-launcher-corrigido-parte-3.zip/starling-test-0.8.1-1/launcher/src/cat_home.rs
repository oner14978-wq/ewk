//! Home's head as the Cat Launcher screen: the purple pixel night with its trees, the enderman,
//! the two cats and the moon, the logo plate and three buttons. It replaces the glass look's
//! head (`glass_home_head`) at the same place and keeps every action it had: Jogar is Play's own
//! press (play, prepare then play, update, stop), Adicionar a versão opens the version picker
//! (the installed versions and Manage versions, where more are installed), and Criar Conta opens
//! the Microsoft sign-in, or the account page once somebody is signed in.
//!
//! Everything is laid out in the reference picture's own units (2211 × 998) and scaled to the
//! window's width, so the positions and proportions are the picture's.
use super::*;
use crate::glass_ui as ui;
use gpui::{deferred, linear_color_stop, linear_gradient, rgb};

/// The reference picture's size.
const REF_W: f32 = 2211.;
const REF_H: f32 = 998.;

const VOID: u32 = 0x0b0418;
const PLATE: u32 = 0x12062a;
const EDGE: u32 = 0x7c3aed;
const EDGE_LIGHT: u32 = 0xa879ff;
const PINK: u32 = 0xff4fe0;
const INK_LAVENDER: u32 = 0xe9dcff;

/// Where the scene's pieces stand and how big they are, in the picture's units, scaled to the
/// window.
#[derive(Clone, Copy)]
struct Stage {
    s: f32,
}

impl Stage {
    fn rect(self, x: f32, y: f32, w: f32, h: f32, color: u32) -> Div {
        div()
            .absolute()
            .left(px(x * self.s))
            .top(px(y * self.s))
            .w(px(w * self.s))
            .h(px(h * self.s))
            .bg(rgb(color))
    }

    fn rect_a(self, x: f32, y: f32, w: f32, h: f32, color: u32, alpha: f32) -> Div {
        self.rect(x, y, w, h, color)
            .bg(gpui::Hsla::from(rgb(color)).opacity(alpha))
    }

    fn circle(self, cx: f32, cy: f32, r: f32, color: u32) -> Div {
        self.rect(cx - r, cy - r, r * 2., r * 2., color)
            .rounded(px(r * self.s))
    }

    /// A box with stepped (pixel) corners, which is the picture's octagon: `cut` is the corner's
    /// size, the border `edge` wide round the `fill`.
    fn bevel(
        self,
        parent: Div,
        (x, y, w, h): (f32, f32, f32, f32),
        cut: f32,
        edge: f32,
        border: u32,
        fill: u32,
    ) -> Div {
        let mut parent = parent;
        for (inset, color) in [(0., border), (edge, fill)] {
            let (x, y, w, h, cut) = (
                x + inset,
                y + inset,
                w - inset * 2.,
                h - inset * 2.,
                (cut - inset * 0.4).max(2.),
            );
            let step = cut / 3.;
            for k in 0..3 {
                let o = cut - step * (k as f32 + 1.);
                parent = parent.child(self.rect(x + o, y + step * k as f32, w - o * 2., h - step * k as f32 * 2., color));
            }
            parent = parent.child(self.rect(x, y + cut, w, h - cut * 2., color));
        }
        parent
    }

    /// Square pixels of a tree's crown, drawn from fixed seeds so every run is the same picture.
    #[allow(dead_code)]
    fn crown(self, mut parent: Div, x: f32, y: f32, cols: usize, rows: usize, cell: f32, seed: u32) -> Div {
        const SHADES: [u32; 7] = [0x2a1260, 0x3a1b85, 0x4b27a8, 0x6a3fd9, 0x8a5cf0, 0xa883ff, 0x1d0d45];
        let mut state = seed;
        for r in 0..rows {
            for c in 0..cols {
                state = state.wrapping_mul(1664525).wrapping_add(1013904223);
                // Rounded blob: the corners and edges thin out.
                let dx = (c as f32 + 0.5) / cols as f32 - 0.5;
                let dy = (r as f32 + 0.5) / rows as f32 - 0.5;
                let d = (dx * dx + dy * dy).sqrt();
                if d > 0.5 || (d > 0.38 && (state >> 20) % 3 == 0) {
                    continue;
                }
                let shade = SHADES[((state >> 16) as usize) % SHADES.len()];
                parent = parent.child(self.rect_a(
                    x + c as f32 * cell,
                    y + r as f32 * cell,
                    cell - 1.5,
                    cell - 1.5,
                    shade,
                    0.9,
                ));
            }
        }
        parent
    }

    fn star(self, parent: Div, x: f32, y: f32, color: u32) -> Div {
        parent
            .child(self.rect(x - 11., y - 1.5, 22., 3., color))
            .child(self.rect(x - 1.5, y - 11., 3., 22., color))
    }

    fn paw(self, parent: Div, cx: f32, cy: f32) -> Div {
        parent
            .child(self.circle(cx, cy, 60., 0x5a1a78))
            .child(self.circle(cx, cy + 18., 20., PINK))
            .child(self.circle(cx - 33., cy - 4., 10., PINK))
            .child(self.circle(cx - 14., cy - 22., 10., PINK))
            .child(self.circle(cx + 12., cy - 22., 10., PINK))
            .child(self.circle(cx + 31., cy - 4., 10., PINK))
    }

    fn cat_head(self, parent: Div, x: f32, y: f32, w: f32, h: f32, ears: f32) -> Div {
        let mut parent = parent;
        // The ears: stepped triangles.
        for k in 0..6 {
            let up = ears / 6. * k as f32;
            let width = ears * 0.55 - k as f32 * ears * 0.075;
            parent = parent
                .child(self.rect(x + 4. + k as f32 * 4., y - ears + up, width, ears / 6., 0x0a0312))
                .child(self.rect(x + w - 4. - k as f32 * 4. - width, y - ears + up, width, ears / 6., 0x0a0312));
        }
        parent.child(self.rect(x, y, w, h, 0x0a0312))
    }
}

impl Launcher {
    /// What replaces the glass head: the Cat Launcher screen. `tag`/`prepared` are what
    /// `glass_home_head` gets.
    pub(super) fn cat_home_head(
        &mut self,
        tag: &str,
        prepared: bool,
        cx: &mut Context<Self>,
    ) -> Div {
        let java = self.selected_instance().and_then(|i| i.java.clone());
        match (&self.client, self.client_since) {
            (Some(_), None) => self.client_since = Some(std::time::Instant::now()),
            (None, Some(_)) => self.client_since = None,
            _ => {}
        }
        let width = self.window_width.max(640.);
        let st = Stage { s: width / REF_W };
        let height = REF_H * st.s;
        let ready = prepared || java.is_some();

        // ---- Backdrop: the night, the ground and what stands on it ----
        let mut scene = div()
            .absolute()
            .top_0()
            .left_0()
            .w(px(width))
            .h(px(height))
            .overflow_hidden()
            .bg(linear_gradient(
                180.,
                linear_color_stop(rgb(VOID), 0.),
                linear_color_stop(rgb(0x3a1585), 0.8),
            ))
            .child(
                div()
                    .absolute()
                    .top(px(785. * st.s))
                    .left_0()
                    .w(px(width))
                    .h(px((REF_H - 785.) * st.s))
                    .bg(linear_gradient(
                        180.,
                        linear_color_stop(rgb(0x7a35e0), 0.),
                        linear_color_stop(rgb(0x2a0f66), 1.),
                    )),
            );
        // The moon and its glow.
        for (grow, alpha) in [(150., 0.05), (100., 0.07), (55., 0.1)] {
            scene = scene.child(
                st.rect_a(2028. - 75. - grow, 206. - 75. - grow, 150. + grow * 2., 150. + grow * 2., 0xb08cff, alpha)
                    .rounded(px((75. + grow) * st.s)),
            );
        }
        scene = scene
            .child(st.rect(1953., 131., 150., 150., 0xd9c8ef))
            .child(st.rect(1968., 131., 50., 50., 0xa98ad8))
            .child(st.rect(2030., 231., 50., 50., 0xa98ad8));
        // Trees: the crowns' cells, measured from the picture (cat_art.rs).
        for crown in crate::cat_art::CROWNS {
            for &(x, y, color) in crown.cells {
                scene = scene.child(st.rect(x, y, crown.cell - 1.5, crown.cell - 1.5, color));
            }
        }
        for (x, y) in [(40., 340.), (410., 600.), (1790., 640.), (1575., 700.), (500., 690.)] {
            scene = scene.child(st.rect_a(x, y, 14., 110., 0x2a1260, 0.9));
        }
        // Stars.
        for (x, y, c) in [
            (297., 77., 0xd9d0ff),
            (426., 77., PINK),
            (968., 122., 0xd9d0ff),
            (1865., 66., PINK),
            (2137., 209., 0xd9d0ff),
        ] {
            scene = st.star(scene, x, y, c);
        }
        for (x, y) in [(165., 25.), (845., 38.), (1334., 132.), (1926., 118.), (2110., 12.), (524., 298.)] {
            scene = scene.child(st.rect(x, y, 4., 4., 0xe0d4ff));
        }
        // The enderman, on his block.
        scene = scene
            .child(st.rect(145., 347., 118., 110., 0x050208))
            .child(st.rect(194., 400., 26., 14., PINK))
            .child(st.rect(230., 400., 26., 14., PINK))
            .child(st.rect(155., 457., 62., 140., 0x070310))
            .child(st.rect(155., 590., 30., 235., 0x070310))
            .child(st.rect(192., 590., 25., 235., 0x070310));
        for k in 0..14 {
            let k = k as f32;
            scene = scene
                .child(st.rect(150. - k * 5.2, 470. + k * 17., 13., 20., 0x070310))
                .child(st.rect(218. + k * 5.2, 470. + k * 17., 13., 20., 0x070310));
        }
        for (x, y, shade) in [(0., 825., 0x6a3fd9), (57., 825., 0x7a4de6), (113., 825., 0x6a3fd9), (170., 825., 0x8a5cf0), (226., 825., 0x7a4de6), (283., 825., 0x6a3fd9)] {
            scene = scene.child(st.rect(x, y, 56., 28., shade));
        }
        scene = scene.child(st.rect(0., 853., 352., 145., 0x2a1070));
        // The cat on the right, on its block.
        scene = st.cat_head(scene, 1912., 600., 156., 120., 40.);
        scene = scene
            .child(st.rect(1912., 700., 270., 145., 0x0a0312))
            .child(st.circle(2185., 810., 22., 0x0a0312))
            .child(st.rect(1925., 645., 28., 18., PINK))
            .child(st.rect(1978., 645., 28., 18., PINK))
            .child(st.rect(1848., 843., 363., 30., 0x7a4de6))
            .child(st.rect(1848., 873., 363., 125., 0x2a1070));

        // ---- The logo ----
        scene = st.cat_head(scene, 989., 70., 206., 130., 55.);
        scene = scene
            .child(st.rect(1020., 150., 40., 24., PINK))
            .child(st.rect(1124., 150., 40., 24., PINK))
            .child(st.rect(1068., 108., 12., 12., 0x3a1b85))
            .child(st.rect(1096., 108., 12., 12., 0x3a1b85))
            .child(st.rect(1122., 108., 12., 12., 0x3a1b85))
            .child(st.rect(553., 272., 142., 5., 0xb23be8))
            .child(st.rect(1487., 272., 169., 5., 0xb23be8));
        scene = st.paw(scene, 611., 189.);
        scene = st.paw(scene, 1577., 197.);
        scene = st.bevel(scene, (695., 190., 792., 150.), 44., 8., EDGE, PLATE);
        let title = |color: u32, dx: f32, dy: f32| {
            div()
                .absolute()
                .left(px((740. + dx) * st.s))
                .top(px((196. + dy) * st.s))
                .w(px(700. * st.s))
                .h(px(140. * st.s))
                .flex()
                .items_center()
                .justify_center()
                .font_family("Pixelify Sans")
                .font_weight(FontWeight::BOLD)
                .text_size(px(104. * st.s))
                .text_color(rgb(color))
                .child("Cat Launcher")
        };
        scene = scene
            .child(title(0xb23be8, 5., 6.))
            .child(title(INK_LAVENDER, 0., 0.));

        // ---- The three buttons ----
        let version_label = "Adicionar a versão";
        let picker_open = self.picker_open;
        let add = {
            let base = st.bevel(div().absolute().top_0().left_0().w(px(width)).h(px(height)), (628., 397., 937., 133.), 34., 7., EDGE, PLATE);
            div()
                .id("cat-add-version")
                .absolute()
                .left(px(628. * st.s))
                .top(px(397. * st.s))
                .w(px(937. * st.s))
                .h(px(133. * st.s))
                .cursor_pointer()
                .child(
                    // The bevel is drawn in the scene's units; shift it into this box.
                    div()
                        .absolute()
                        .left(px(-628. * st.s))
                        .top(px(-397. * st.s))
                        .w(px(width))
                        .h(px(height))
                        .child(base),
                )
                .child(st.rect(80., 33., 72., 14., 0xffffff).left(px(80. * st.s)).top(px(60. * st.s)).w(px(72. * st.s)).h(px(14. * st.s)))
                .child(st.rect(80., 33., 14., 72., 0xffffff).left(px(109. * st.s)).top(px(31. * st.s)).w(px(14. * st.s)).h(px(72. * st.s)))
                .child(
                    div()
                        .absolute()
                        .left(px(200. * st.s))
                        .top_0()
                        .w(px(560. * st.s))
                        .h_full()
                        .flex()
                        .items_center()
                        .justify_center()
                        .font_family("Pixelify Sans")
                        .font_weight(FontWeight::BOLD)
                        .text_size(px(50. * st.s))
                        .text_color(rgb(INK_LAVENDER))
                        .child(version_label),
                )
                .child(
                    div()
                        .absolute()
                        .left(px(820. * st.s))
                        .top_0()
                        .w(px(100. * st.s))
                        .h_full()
                        .flex()
                        .items_center()
                        .justify_center()
                        .child(ui::icon("arrow-down-01", 56. * st.s, rgb(0xffffff).into())),
                )
                .on_click(cx.listener(|this, event: &ClickEvent, _, cx| {
                    let _ = event;
                    this.picker_open = false;
                    this.go(Page::Versions);
                    cx.notify();
                }))
        };

        let running = self.client.is_some();
        let follows = self.selected_instance().is_some_and(|i| i.version.is_none());
        let update = self
            .updates
            .horizon
            .as_ref()
            .filter(|_| follows && !tag.is_empty())
            .map(|r| r.tag.clone());
        let installing = update
            .as_ref()
            .and_then(|u| self.installing.as_ref().filter(|(t, _)| t == u))
            .map(|(_, p)| *p);
        let own = self
            .selected_instance()
            .and_then(|i| i.version.as_ref())
            .and_then(|v| {
                let queued = self.install_next.as_ref().is_some_and(|r| r.tag == *v);
                let running = self.installing.as_ref().filter(|(t, _)| t == v);
                running.map(|(_, p)| Some(*p)).or(queued.then_some(None))
            });
        let busy: Option<(&str, Option<f32>)> = match (installing, self.preparing, &self.starting_client) {
            (Some(p), _, _) => Some(("Atualizando", Some(p))),
            (_, _, _) if own.is_some() => Some(("Instalando", own.flatten())),
            (_, true, _) => Some((
                "Preparando",
                horizon_launcher::mojang::progress().map(|(d, n)| d as f32 / n.max(1) as f32),
            )),
            (_, _, Some(_)) => Some(("Iniciando", None)),
            _ => None,
        };
        // No sign-in gate: an unprepared game is prepared from the player's own install first.
        let press = play_press(ready, Some(true), false);
        let label = match (busy, running, &update) {
            (Some((l, Some(p))), _, _) => format!("{l} {:.0}%", p * 100.),
            (Some((l, None)), _, _) => format!("{l}…"),
            (None, true, _) => "Parar".to_string(),
            (None, false, Some(_)) => "Atualizar".to_string(),
            _ => "Jogar".to_string(),
        };
        let play = {
            let d = div()
                .id("play")
                .absolute()
                .left(px(654. * st.s))
                .top(px(580. * st.s))
                .w(px(881. * st.s))
                .h(px(190. * st.s))
                .overflow_hidden()
                .rounded(px(26. * st.s))
                .border(px(6. * st.s))
                .border_color(rgb(0xc4a5ff))
                .bg(linear_gradient(
                    180.,
                    linear_color_stop(rgb(0xa77bff), 0.),
                    linear_color_stop(rgb(0x5b21d6), 0.45),
                ))
                .child(
                    div()
                        .absolute()
                        .left(px(100. * st.s))
                        .top_0()
                        .w(px(150. * st.s))
                        .h_full()
                        .flex()
                        .items_center()
                        .justify_center()
                        .text_size(px(110. * st.s))
                        .text_color(rgb(0xf3eaff))
                        .child(if running && busy.is_none() { "■" } else { "▶" }),
                )
                .child(
                    div()
                        .absolute()
                        .left(px(300. * st.s))
                        .top_0()
                        .w(px(560. * st.s))
                        .h_full()
                        .flex()
                        .items_center()
                        .font_family("Pixelify Sans")
                        .font_weight(FontWeight::BOLD)
                        .text_size(px(120. * st.s))
                        .text_color(rgb(0xffffff))
                        .child(label),
                );
            match (busy, running) {
                (Some(_), _) => d.cursor_default(),
                (None, true) => d.cursor_pointer().on_click(cx.listener(|this, _: &ClickEvent, _, cx| {
                    if let Some(client) = &this.client {
                        client.kill();
                    }
                    cx.notify();
                })),
                (None, false) => match (&update, press) {
                    (Some(_), _) => d.cursor_pointer().on_click(cx.listener(|this, _: &ClickEvent, _, cx| {
                        this.install_update();
                        cx.notify();
                    })),
                    (None, PlayPress::Play) => d.cursor_pointer().on_click(cx.listener(|this, _: &ClickEvent, _, cx| {
                        this.picker_open = false;
                        this.play();
                        cx.notify();
                    })),
                    (None, PlayPress::PrepareThenPlay) => {
                        d.cursor_pointer().on_click(cx.listener(|this, _: &ClickEvent, _, cx| {
                            this.picker_open = false;
                            this.play_when_prepared = this.selected().cloned();
                            this.prepare(backend::MinecraftFrom::Install);
                            cx.notify();
                        }))
                    }
                    // Busy: nothing to press.
                    (None, PlayPress::Nothing) => d,
                },
            }
        };

        let account = {
            let base = st.bevel(div().absolute().top_0().left_0().w(px(width)).h(px(height)), (766., 818., 659., 119.), 30., 7., EDGE, PLATE);
            div()
                .id("cat-create-account")
                .absolute()
                .left(px(766. * st.s))
                .top(px(818. * st.s))
                .w(px(659. * st.s))
                .h(px(119. * st.s))
                .cursor_pointer()
                .child(
                    div()
                        .absolute()
                        .left(px(-766. * st.s))
                        .top(px(-818. * st.s))
                        .w(px(width))
                        .h(px(height))
                        .child(base),
                )
                .child(
                    div()
                        .absolute()
                        .left(px(114. * st.s))
                        .top_0()
                        .w(px(110. * st.s))
                        .h_full()
                        .flex()
                        .items_center()
                        .justify_center()
                        .child(ui::icon("user", 76. * st.s, rgb(0xe9dcff).into())),
                )
                .child(
                    div()
                        .absolute()
                        .left(px(230. * st.s))
                        .top_0()
                        .w(px(400. * st.s))
                        .h_full()
                        .flex()
                        .items_center()
                        .font_family("Pixelify Sans")
                        .font_weight(FontWeight::BOLD)
                        .text_size(px(44. * st.s))
                        .text_color(rgb(INK_LAVENDER))
                        .child("Criar Conta"),
                )
                .on_click(cx.listener(move |this, _: &ClickEvent, _, cx| {
                    // The name is chosen in Settings, Account.
                    this.go(Page::Settings);
                    cx.notify();
                }))
        };


        // Personalizar personagem: abre a tela de roupas, acessórios, chapéus e capas.
        let customize = div()
            .id("cat-customize")
            .absolute()
            .left(px(60. * st.s))
            .top(px(818. * st.s))
            .w(px(620. * st.s))
            .h(px(119. * st.s))
            .flex()
            .items_center()
            .gap(px(26. * st.s))
            .px(px(40. * st.s))
            .rounded(px(34. * st.s))
            .border(px(7. * st.s))
            .border_color(rgb(EDGE))
            .bg(rgb(PLATE))
            .cursor_pointer()
            .child(ui::icon("user", 76. * st.s, rgb(0xe9dcff).into()))
            .child(
                div()
                    .font_family("Pixelify Sans")
                    .font_weight(FontWeight::BOLD)
                    .text_size(px(44. * st.s))
                    .text_color(rgb(INK_LAVENDER))
                    .child("Personalizar"),
            )
            .on_click(cx.listener(|this, _: &ClickEvent, _, cx| {
                this.cust_open();
                cx.notify();
            }));

        let mut hero = div()
            .relative()
            .flex_none()
            .w(px(width))
            .h(px(height))
            .child(scene)
            .child(add)
            .child(play)
            .child(account)
            .child(customize);
        if picker_open {
            hero = hero.child(self.cat_picker_menu(&st, cx));
        }
        // The window's own gutter must not crop the picture: it spans the page's full width.
        div()
            .flex()
            .flex_col()
            .min_w_0()
            .mx(px(-crate::theme::PAGE_GUTTER))
            .child(hero)
    }

    /// The picker's menu under the Adicionar a versão button: the installed versions to pick,
    /// and Manage versions, where more are installed and removed.
    fn cat_picker_menu(&self, st: &Stage, cx: &mut Context<Self>) -> Div {
        let t = self.theme;
        let soft = self.look.accent_soft;
        let follows = self.launcher_version().cloned();
        let mut menu = ui::popover(320.)
            .id("picker-menu")
            .occlude()
            .on_mouse_down_out(cx.listener(|this, event: &MouseDownEvent, _, cx| {
                this.picker_open = false;
                this.menu_closed_at = Some(event.position);
                cx.notify();
            }));
        for tag in &self.installed {
            let chosen = self.selected() == Some(tag);
            let latest = follows.as_ref() == Some(tag);
            let name = horizon_launcher::nightly::label(tag)
                .or_else(|| build_import::label(tag))
                .unwrap_or_else(|| tag.clone());
            let note = if latest {
                tr("Newest · follows updates").to_string()
            } else {
                tag.clone()
            };
            let pick = tag.clone();
            menu = menu.child(
                ui::menu_item(format!("pick-{tag}"), name.into(), note, false, &t)
                    .when(chosen, |d| {
                        d.child(ui::icon("tick-02", 17., ui::color(soft)).relative())
                    })
                    .on_click(cx.listener(move |this, _: &ClickEvent, _, cx| {
                        this.pin_version((!latest).then(|| pick.clone()));
                        this.picker_open = false;
                        cx.notify();
                    })),
            );
        }
        menu = menu.child(
            ui::menu_item(
                "manage",
                tr("Manage versions").into(),
                tr("Install, remove and pick versions").into(),
                false,
                &t,
            )
            .on_click(cx.listener(|this, _: &ClickEvent, _, cx| {
                this.go(Page::Versions);
                this.picker_open = false;
                cx.notify();
            })),
        );
        div().absolute().left(px(628. * st.s)).top(px(540. * st.s)).child(
            deferred(menu).with_priority(1),
        )
    }
}
