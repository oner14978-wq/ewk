//! A tela de personalização do personagem do Cat Launcher, no desenho da imagem de referência
//! (2235 × 998): a barra roxa com o voltar, o nome do jogador, o personagem sobre a plataforma
//! com os botões de girar, as abas Roupas, Chapéus, Seleções e Importar e o painel de peças,
//! Importar Skin, Restaurar Padrão e Salvar Alterações.
//!
//! A lógica (catálogo, importação com validação, skin completa, salvamento, desenho do
//! personagem) é `horizon_launcher::customize`; aqui estão a tela e os botões. O que se salva é
//! a skin completa montada e a capa, que o jogo lê (`customize::apply_to_command`).
use super::*;
use gpui::{img, linear_color_stop, linear_gradient, rgb, Image, ImageFormat, ObjectFit};
use horizon_launcher::customize::{self, Category, Outfit, Store, View};
use std::sync::Arc;

const PIXEL: &str = "Pixelify Sans";
const PLATE: u32 = 0x140a2e;
const INK: u32 = 0xe9dcff;
const REF_W: f32 = 2235.;
const REF_H: f32 = 998.;

/// As abas de cima.
#[derive(Clone, Copy, PartialEq, Eq, Default)]
pub(super) enum CustTab {
    #[default]
    Clothes,
    Hats,
    Selections,
    Import,
}

/// O que a tela guarda enquanto está aberta.
#[derive(Default)]
pub(super) struct CustState {
    store: Option<Store>,
    /// O que o personagem veste agora (ainda não salvo, até Salvar Alterações).
    outfit: Outfit,
    tab: CustTab,
    /// A categoria mostrada inteira no painel; nenhuma: a visão geral da referência.
    focus: Option<Category>,
    /// Giro do personagem, em graus.
    yaw: i32,
    preview: Option<Arc<Image>>,
    preview_key: String,
    thumbs: std::collections::HashMap<String, Arc<Image>>,
    /// Aviso no canto do botão de salvar: o texto e se é um erro.
    notice: Option<(String, bool)>,
    busy: bool,
    dirty: bool,
}

fn color(c: u32) -> Hsla {
    rgb(c).into()
}

fn alpha(c: u32, a: f32) -> Hsla {
    Hsla::from(rgb(c)).opacity(a)
}

/// Uma caixa nas unidades da referência.
fn abs(s: f32, x: f32, y: f32, w: f32, h: f32) -> Div {
    div()
        .absolute()
        .left(px(x * s))
        .top(px(y * s))
        .w(px(w * s))
        .h(px(h * s))
}

/// O corpo de um botão em pílula: a borda neon e o fundo, mais claros quando ligado.
fn pill(d: Div, s: f32, radius: f32, on: bool) -> Div {
    d.rounded(px(radius * s))
        .border(px(3. * s))
        .border_color(color(if on { 0xb99aff } else { 0x5b2fc9 }))
        .bg(color(if on { 0x7a3df0 } else { 0x150a33 }))
}

fn label(text: &str, s: f32, size: f32, c: u32) -> Div {
    div()
        .font_family(horizon_theme::glass::FONT)
        .font_weight(FontWeight::MEDIUM)
        .text_size(px(size * s))
        .text_color(color(c))
        .child(text.to_string())
}

/// O nome curto de uma categoria no singular, para a lateral.
fn short(cat: Category) -> &'static str {
    match cat {
        Category::Shirt => "Camisa",
        Category::Pants => "Calça",
        Category::Shorts => "Short",
        Category::Accessory => "Acess.",
        Category::Hat => "Chapéu",
        Category::Shoes => "Calçado",
        Category::Cape => "Capa",
        Category::Skin => "Skin",
    }
}

impl Launcher {
    /// Lê o que foi salvo, na primeira vez que a tela precisa.
    fn cust_load(&mut self) {
        if self.cust.store.is_none() {
            let store = Store::open(customize::default_root());
            self.cust.outfit = store.saved.clone();
            self.cust.store = Some(store);
            self.cust.preview_key.clear();
        }
    }

    /// Abre a tela, pelo botão da Home.
    pub(super) fn cust_open(&mut self) {
        self.cust_load();
        self.cust.notice = None;
        self.go(Page::Customize);
    }

    fn cust_notice(&mut self, text: impl Into<String>, error: bool) {
        self.cust.notice = Some((text.into(), error));
    }

    /// O personagem, desenhado de novo só quando a roupa ou o giro mudam.
    fn cust_preview(&mut self) -> Option<Arc<Image>> {
        let store = self.cust.store.as_ref()?;
        let key = format!("{:?}|{}|{}", self.cust.outfit, self.cust.yaw, store.library.len());
        if self.cust.preview_key != key || self.cust.preview.is_none() {
            let skin = store.compose(&self.cust.outfit);
            let cape = store.cape(&self.cust.outfit);
            let slim = store.is_slim(&self.cust.outfit);
            let view = customize::render(&skin, cape.as_ref(), slim, &View::full(self.cust.yaw));
            self.cust.preview = Some(Arc::new(Image::from_bytes(
                ImageFormat::Png,
                customize::png_bytes(&view),
            )));
            self.cust.preview_key = key;
        }
        self.cust.preview.clone()
    }

    fn cust_thumb(&mut self, cat: Category, id: &str) -> Option<Arc<Image>> {
        if let Some(t) = self.cust.thumbs.get(id) {
            return Some(t.clone());
        }
        let store = self.cust.store.as_ref()?;
        let png = customize::png_bytes(&store.thumbnail(cat, id));
        let image = Arc::new(Image::from_bytes(ImageFormat::Png, png));
        self.cust.thumbs.insert(id.to_string(), image.clone());
        Some(image)
    }

    /// Escolhe uma peça (ou, tocando na que já está, a tira).
    fn cust_pick(&mut self, cat: Category, id: Option<String>) {
        let now = self.cust.outfit.get(cat).cloned();
        let next = if id.is_some() && id == now { None } else { id };
        // A capa se confere de costas.
        if cat == Category::Cape && next.is_some() {
            self.cust.yaw = 180;
        }
        self.cust.outfit.set(cat, next);
        self.cust.dirty = true;
        self.cust.notice = None;
    }

    fn cust_rotate(&mut self, by: i32) {
        self.cust.yaw = (self.cust.yaw + by).rem_euclid(360);
    }

    /// Pede os arquivos, valida e guarda cada um (fora da tela) e põe o último no personagem.
    fn cust_import(&mut self, cat: Category, cx: &mut Context<Self>) {
        if self.cust.busy {
            return;
        }
        self.cust.busy = true;
        let paths = cx.prompt_for_paths(PathPromptOptions {
            files: true,
            directories: false,
            multiple: true,
            prompt: Some("Importar".into()),
        });
        let root = customize::default_root();
        cx.spawn(async move |this, cx| {
            let picked = match paths.await {
                Ok(Ok(Some(p))) => p,
                _ => {
                    let _ = this.update(cx, |this, cx| {
                        this.cust.busy = false;
                        cx.notify();
                    });
                    return;
                }
            };
            let done = cx
                .background_executor()
                .spawn(async move {
                    picked
                        .iter()
                        .map(|p| customize::import_file(&root, cat, p))
                        .collect::<Vec<_>>()
                })
                .await;
            let _ = this.update(cx, |this, cx| {
                this.cust_imported(cat, done);
                cx.notify();
            });
        })
        .detach();
    }

    fn cust_imported(&mut self, cat: Category, results: Vec<Result<customize::Imported, String>>) {
        self.cust.busy = false;
        let (mut ok, mut errors) = (0, Vec::new());
        for r in results {
            match r {
                Ok(item) => {
                    let id = item.id.clone();
                    let added = self.cust.store.as_mut().map(|s| s.add(item));
                    match added {
                        Some(Ok(())) => {
                            ok += 1;
                            self.cust.outfit.set(cat, Some(id));
                            self.cust.dirty = true;
                            if cat == Category::Cape {
                                self.cust.yaw = 180;
                            }
                        }
                        Some(Err(e)) => errors.push(e),
                        None => {}
                    }
                }
                Err(e) => errors.push(e),
            }
        }
        if ok > 0 {
            // O que estava aberto passa a mostrar o que entrou.
            if cat != Category::Skin {
                self.cust.focus = Some(cat);
                self.cust.tab = CustTab::Clothes;
            }
        }
        let text = match (ok, errors.is_empty()) {
            (0, false) => errors.join(" "),
            (n, true) => format!("{n} arquivo(s) importado(s). Salve para usar no jogo."),
            (n, false) => format!("{n} importado(s). {}", errors.join(" ")),
        };
        self.cust_notice(text, ok == 0 || !errors.is_empty());
    }

    fn cust_save(&mut self) {
        let outfit = self.cust.outfit.clone();
        let Some(store) = self.cust.store.as_mut() else { return };
        match store.save(&outfit) {
            Ok(()) => {
                self.cust.dirty = false;
                self.cust_notice(
                    "Salvo. O jogo usa esta skin completa e a capa na próxima vez que abrir.",
                    false,
                );
            }
            Err(e) => self.cust_notice(format!("Não foi possível salvar: {e}"), true),
        }
    }

    fn cust_restore(&mut self) {
        self.cust.outfit = Outfit::default();
        self.cust.yaw = 0;
        let Some(store) = self.cust.store.as_mut() else { return };
        match store.save(&Outfit::default()) {
            Ok(()) => {
                self.cust.dirty = false;
                self.cust_notice("Aparência original restaurada. Seus arquivos importados continuam na lista.", false);
            }
            Err(e) => self.cust_notice(format!("Não foi possível restaurar: {e}"), true),
        }
    }

    /// A skin completa montada, num arquivo PNG na pasta de downloads, para enviar à conta.
    fn cust_export(&mut self) {
        let Some(store) = self.cust.store.as_mut() else { return };
        if store.saved != self.cust.outfit {
            let outfit = self.cust.outfit.clone();
            if let Err(e) = store.save(&outfit) {
                self.cust_notice(format!("Não foi possível salvar antes de exportar: {e}"), true);
                return;
            }
            self.cust.dirty = false;
        }
        let Some(store) = self.cust.store.as_ref() else { return };
        let dir = dirs::download_dir().or_else(dirs::home_dir).unwrap_or_default();
        let dest = dir.join("CatLauncher-skin.png");
        match store.export_skin(&dest) {
            Ok(()) => self.cust_notice(format!("Skin completa exportada em {}", dest.display()), false),
            Err(e) => self.cust_notice(format!("Não foi possível exportar: {e}"), true),
        }
    }

    /// Um quadrado de peça: a miniatura, com a borda acesa na escolhida.
    fn cust_tile(
        &mut self,
        cat: Category,
        id: Option<String>,
        x: f32,
        y: f32,
        s: f32,
        cx: &mut Context<Self>,
    ) -> AnyElement {
        let selected = self.cust.outfit.get(cat) == id.as_ref();
        let key = id.clone().unwrap_or_else(|| "none".into());
        let thumb = id.as_deref().and_then(|i| self.cust_thumb(cat, i));
        let tile = abs(s, x, y, 119., 119.)
            .id(SharedString::from(format!("cust-tile-{}-{key}", cat.key())))
            .rounded(px(32. * s))
            .border(px(3. * s))
            .border_color(color(if selected { 0xf0a8ff } else { 0x4a2aa0 }))
            .bg(color(if selected { 0x2a1260 } else { 0x1a0b3a }))
            .cursor_pointer()
            .flex()
            .items_center()
            .justify_center()
            .overflow_hidden();
        let tile = match thumb {
            Some(t) => tile.child(img(t).w(px(104. * s)).h(px(104. * s)).object_fit(ObjectFit::Contain)),
            None => tile.child(crate::glass_ui::icon("cancel-01", 52. * s, color(0xb79cff))),
        };
        tile.on_click(cx.listener(move |this, _: &ClickEvent, _, cx| {
            this.cust_pick(cat, id.clone());
            cx.notify();
        }))
        .into_any_element()
    }

    /// O quadrado de "+", que importa para a categoria.
    fn cust_add_tile(&self, cat: Category, x: f32, y: f32, s: f32, cx: &mut Context<Self>) -> AnyElement {
        abs(s, x, y, 119., 119.)
            .id(SharedString::from(format!("cust-add-{}", cat.key())))
            .rounded(px(32. * s))
            .border(px(3. * s))
            .border_color(color(0x7c3aed))
            .bg(color(0x150a33))
            .cursor_pointer()
            .flex()
            .items_center()
            .justify_center()
            .child(crate::glass_ui::icon("plus-sign", 52. * s, color(0xcdb6ff)))
            .on_click(cx.listener(move |this, _: &ClickEvent, _, cx| {
                this.cust_import(cat, cx);
                cx.notify();
            }))
            .into_any_element()
    }

    /// Uma fileira da visão geral: as primeiras peças que cabem.
    fn cust_row(
        &mut self,
        cat: Category,
        x: f32,
        y: f32,
        count: usize,
        s: f32,
        cx: &mut Context<Self>,
    ) -> Vec<AnyElement> {
        let parts = self
            .cust
            .store
            .as_ref()
            .map(|st| st.parts(cat))
            .unwrap_or_default();
        let mut out = Vec::new();
        for (n, part) in parts.into_iter().take(count).enumerate() {
            out.push(self.cust_tile(cat, Some(part.id), x + n as f32 * 139., y, s, cx));
        }
        out
    }

    /// O painel com a visão geral da referência: Camisas, Calças, Acessórios e Chapéus.
    fn cust_overview(&mut self, s: f32, cx: &mut Context<Self>) -> Vec<AnyElement> {
        let mut out: Vec<AnyElement> = Vec::new();
        let mut section = |this: &mut Self, cat: Category, lx: f32, ly: f32, tx: f32, ty: f32, n: usize, out: &mut Vec<AnyElement>, cx: &mut Context<Self>| {
            out.push(
                abs(s, lx, ly, 600., 60.)
                    .flex()
                    .items_center()
                    .child(label(cat.label(), s, 46., 0xffffff))
                    .into_any_element(),
            );
            out.extend(this.cust_row(cat, tx, ty, n, s, cx));
        };
        section(self, Category::Shirt, 752., 288., 752., 376., 7, &mut out, cx);
        section(self, Category::Pants, 1804., 288., 1746., 376., 3, &mut out, cx);
        section(self, Category::Accessory, 752., 531., 752., 619., 7, &mut out, cx);
        section(self, Category::Hat, 1804., 531., 1746., 619., 3, &mut out, cx);
        // As linhas que dividem o painel.
        out.push(abs(s, 1717., 290., 3., 475.).bg(alpha(0x8b5cf6, 0.5)).into_any_element());
        out.push(abs(s, 744., 520., 1442., 3.).bg(alpha(0x8b5cf6, 0.5)).into_any_element());
        out.push(
            abs(s, 1746., 700., 450., 60.)
                .flex()
                .items_center()
                .child(label("Veja todas nas abas e na lateral", s, 26., 0xa98ee0))
                .into_any_element(),
        );
        out
    }

    /// O painel de uma categoria inteira: remover, as peças e importar.
    fn cust_category(&mut self, cat: Category, s: f32, cx: &mut Context<Self>) -> Vec<AnyElement> {
        let parts = self
            .cust
            .store
            .as_ref()
            .map(|st| st.parts(cat))
            .unwrap_or_default();
        let mut out: Vec<AnyElement> = vec![abs(s, 752., 288., 1300., 60.)
            .flex()
            .items_center()
            .child(label(
                &format!("{} ({})", cat.label(), parts.len()),
                s,
                46.,
                0xffffff,
            ))
            .into_any_element()];
        if cat == Category::Cape {
            out.push(
                abs(s, 1500., 288., 680., 60.)
                    .flex()
                    .items_center()
                    .justify_end()
                    .child(label("Gire o personagem para ver a capa", s, 28., 0xa98ee0))
                    .into_any_element(),
            );
        }
        let columns = 10usize;
        let mut cells: Vec<Option<String>> = vec![None];
        cells.extend(parts.into_iter().map(|p| Some(p.id)));
        let mut grid = abs(s, 744., 366., 1442., 410.)
            .id(SharedString::from(format!("cust-grid-{}", cat.key())))
            .overflow_y_scroll();
        let total = cells.len() + 1;
        let rows = total.div_ceil(columns);
        let mut inner = div().relative().w(px(1442. * s)).h(px((rows as f32 * 139. + 20.) * s));
        for (n, id) in cells.into_iter().enumerate() {
            let (cx_, cy_) = ((n % columns) as f32 * 139. + 8., (n / columns) as f32 * 139. + 10.);
            inner = inner.child(self.cust_tile(cat, id, cx_, cy_, s, cx));
        }
        let n = total - 1;
        inner = inner.child(self.cust_add_tile(cat, (n % columns) as f32 * 139. + 8., (n / columns) as f32 * 139. + 10., s, cx));
        grid = grid.child(inner);
        out.push(grid.into_any_element());
        out
    }

    /// A aba Seleções: o que o personagem veste, com remover, e a exportação da skin completa.
    fn cust_selections(&mut self, s: f32, cx: &mut Context<Self>) -> Vec<AnyElement> {
        let mut out: Vec<AnyElement> = vec![abs(s, 752., 288., 1300., 60.)
            .flex()
            .items_center()
            .child(label("O que o personagem veste", s, 46., 0xffffff))
            .into_any_element()];
        let cats = [
            Category::Shirt,
            Category::Pants,
            Category::Shorts,
            Category::Shoes,
            Category::Accessory,
            Category::Hat,
            Category::Cape,
            Category::Skin,
        ];
        for (n, cat) in cats.into_iter().enumerate() {
            let (col, row) = (n % 2, n / 2);
            let (x, y) = (752. + col as f32 * 720., 372. + row as f32 * 84.);
            let id = self.cust.outfit.get(cat).cloned();
            let name = id
                .as_deref()
                .and_then(|i| {
                    self.cust.store.as_ref().and_then(|st| {
                        let c = if cat == Category::Skin { Category::Skin } else { cat };
                        st.parts(c)
                            .into_iter()
                            .find(|p| p.id == i)
                            .map(|p| p.name)
                            .or_else(|| st.library.iter().find(|l| l.id == i).map(|l| l.name.clone()))
                    })
                })
                .unwrap_or_else(|| "Nenhuma".to_string());
            let title = if cat == Category::Skin { "Skin base" } else { short(cat) };
            out.push(
                abs(s, x, y, 520., 70.)
                    .flex()
                    .items_center()
                    .gap(px(14. * s))
                    .child(label(&format!("{title}:"), s, 32., 0xcdb6ff))
                    .child(label(&name, s, 32., 0xffffff))
                    .into_any_element(),
            );
            if id.is_some() {
                out.push(
                    pill(abs(s, x + 520., y + 6., 160., 58.), s, 24., false)
                        .id(SharedString::from(format!("cust-clear-{}", cat.key())))
                        .cursor_pointer()
                        .flex()
                        .items_center()
                        .justify_center()
                        .child(label("Remover", s, 26., INK))
                        .on_click(cx.listener(move |this, _: &ClickEvent, _, cx| {
                            this.cust.outfit.set(cat, None);
                            this.cust.dirty = true;
                            cx.notify();
                        }))
                        .into_any_element(),
                );
            }
        }
        out.push(
            pill(abs(s, 752., 716., 560., 62.), s, 26., true)
                .id("cust-export")
                .cursor_pointer()
                .flex()
                .items_center()
                .justify_center()
                .child(label("Exportar skin completa (.png)", s, 30., 0xffffff))
                .on_click(cx.listener(|this, _: &ClickEvent, _, cx| {
                    this.cust_export();
                    cx.notify();
                }))
                .into_any_element(),
        );
        out.push(
            abs(s, 1330., 696., 850., 90.)
                .flex()
                .items_center()
                .child(label(
                    "Servidores oficiais mostram a skin da conta Microsoft: envie o PNG exportado à sua conta. Capas próprias valem só neste launcher.",
                    s,
                    22.,
                    0xa98ee0,
                ))
                .into_any_element(),
        );
        out
    }

    /// A aba Importar: um botão por categoria e os arquivos já importados, com remover.
    fn cust_import_tab(&mut self, s: f32, cx: &mut Context<Self>) -> Vec<AnyElement> {
        let mut out: Vec<AnyElement> = vec![abs(s, 752., 288., 1300., 60.)
            .flex()
            .items_center()
            .child(label("Importar arquivos .png", s, 46., 0xffffff))
            .into_any_element()];
        let cats = [
            Category::Skin,
            Category::Shirt,
            Category::Pants,
            Category::Shorts,
            Category::Shoes,
            Category::Accessory,
            Category::Hat,
            Category::Cape,
        ];
        for (n, cat) in cats.into_iter().enumerate() {
            let (x, y) = (752. + (n % 4) as f32 * 350., 366. + (n / 4) as f32 * 84.);
            let text = if cat == Category::Skin { "Skin completa".to_string() } else { cat.label().to_string() };
            out.push(
                pill(abs(s, x, y, 330., 68.), s, 26., false)
                    .id(SharedString::from(format!("cust-imp-{}", cat.key())))
                    .cursor_pointer()
                    .flex()
                    .items_center()
                    .justify_center()
                    .gap(px(12. * s))
                    .child(crate::glass_ui::icon("folder-01", 34. * s, color(0xcdb6ff)))
                    .child(label(&text, s, 30., INK))
                    .on_click(cx.listener(move |this, _: &ClickEvent, _, cx| {
                        this.cust_import(cat, cx);
                        cx.notify();
                    }))
                    .into_any_element(),
            );
        }
        let items: Vec<customize::Imported> = self
            .cust
            .store
            .as_ref()
            .map(|st| st.library.clone())
            .unwrap_or_default();
        if items.is_empty() {
            out.push(
                abs(s, 752., 560., 1400., 70.)
                    .flex()
                    .items_center()
                    .child(label("Nada importado ainda. Os arquivos importados ficam salvos no launcher.", s, 28., 0xa98ee0))
                    .into_any_element(),
            );
        }
        let mut list = abs(s, 744., 540., 1442., 235.)
            .id("cust-import-list")
            .overflow_y_scroll();
        let mut inner = div()
            .relative()
            .w(px(1442. * s))
            .h(px((items.len() as f32 * 64. + 10.) * s));
        for (n, item) in items.into_iter().enumerate() {
            let id = item.id.clone();
            inner = inner
                .child(
                    abs(s, 8., n as f32 * 64., 1000., 56.)
                        .flex()
                        .items_center()
                        .gap(px(16. * s))
                        .child(label(item.category.label(), s, 26., 0xcdb6ff))
                        .child(label(&item.name, s, 28., 0xffffff)),
                )
                .child(
                    pill(abs(s, 1180., n as f32 * 64. + 2., 220., 52.), s, 22., false)
                        .id(SharedString::from(format!("cust-del-{}", item.id)))
                        .cursor_pointer()
                        .flex()
                        .items_center()
                        .justify_center()
                        .child(label("Remover arquivo", s, 22., INK))
                        .on_click(cx.listener(move |this, _: &ClickEvent, _, cx| {
                            let removed = this.cust.store.as_mut().map(|st| st.remove(&id));
                            if let Some(Err(e)) = removed {
                                this.cust_notice(e, true);
                            }
                            // O que usava o arquivo sai do personagem.
                            for cat in Category::WEARABLE.into_iter().chain([Category::Skin]) {
                                if this.cust.outfit.get(cat) == Some(&id) {
                                    this.cust.outfit.set(cat, None);
                                    this.cust.dirty = true;
                                }
                            }
                            this.cust.thumbs.remove(&id);
                            cx.notify();
                        }))
                        .into_any_element(),
                );
        }
        list = list.child(inner);
        out.push(list.into_any_element());
        out
    }

    /// A tela inteira.
    pub(super) fn cat_customize(&mut self, cx: &mut Context<Self>) -> Div {
        self.cust_load();
        let width = self.window_width.max(640.);
        let s = width / REF_W;
        let tab = self.cust.tab;
        let focus = self.cust.focus;

        // ---- A barra roxa e o voltar ----
        let back_bar = abs(s, 8., 8., 90., 90.)
            .id("cust-back-bar")
            .flex()
            .items_center()
            .justify_center()
            .rounded(px(45. * s))
            .border(px(3. * s))
            .border_color(color(0xa879ff))
            .bg(color(0x6a2fe0))
            .cursor_pointer()
            .font_family(PIXEL)
            .text_size(px(56. * s))
            .text_color(rgb(0xffffff))
            .child("←")
            .on_click(cx.listener(|this, _: &ClickEvent, _, cx| {
                this.go(Page::Play);
                cx.notify();
            }));
        let bar = abs(s, 0., 0., REF_W, 108.)
            .rounded_b(px(28. * s))
            .bg(linear_gradient(
                90.,
                linear_color_stop(rgb(0x3a1085), 0.),
                linear_color_stop(rgb(0x4b18a8), 1.),
            ));

        // ---- A coluna da esquerda ----
        let back_small = pill(abs(s, 24., 135., 114., 112.), s, 30., true)
            .id("cust-back")
            .flex()
            .items_center()
            .justify_center()
            .cursor_pointer()
            .font_family(PIXEL)
            .text_size(px(60. * s))
            .text_color(rgb(0xffffff))
            .child("‹")
            .on_click(cx.listener(|this, _: &ClickEvent, _, cx| {
                this.go(Page::Play);
                cx.notify();
            }));
        let title = pill(abs(s, 163., 135., 530., 110.), s, 36., false)
            .flex()
            .items_center()
            .px(px(36. * s))
            .gap(px(22. * s))
            .child(crate::glass_ui::icon("user", 50. * s, color(0xc9b0ff)))
            .child(label("Personalização", s, 54., 0xffffff));
        let player = self
            .accounts
            .selected()
            .map(|a| a.name.clone())
            .unwrap_or_else(|| "Jogador".to_string());
        let name = pill(abs(s, 24., 270., 669., 88.), s, 30., false)
            .flex()
            .items_center()
            .px(px(36. * s))
            .gap(px(22. * s))
            .child(crate::glass_ui::icon("user", 42. * s, color(0xb08cff)))
            .child(label(&player, s, 46., 0xffffff));

        // A lateral de categorias, que rola.
        let rail_cats = [
            Category::Shirt,
            Category::Hat,
            Category::Pants,
            Category::Shoes,
            Category::Shorts,
            Category::Accessory,
            Category::Cape,
        ];
        let shown = focus.unwrap_or(Category::Shirt);
        let mut rail = abs(s, 24., 380., 118., 458.)
            .id("cust-rail")
            .overflow_y_scroll();
        let mut rail_in = div().relative().w(px(118. * s)).h(px((rail_cats.len() as f32 * 130.) * s));
        for (n, cat) in rail_cats.into_iter().enumerate() {
            let on = cat == shown && (focus.is_some() || cat == Category::Shirt);
            rail_in = rail_in.child(
                pill(abs(s, 0., n as f32 * 130., 108., 108.), s, 30., on)
                    .id(SharedString::from(format!("cust-rail-{}", cat.key())))
                    .flex()
                    .items_center()
                    .justify_center()
                    .cursor_pointer()
                    .child(label(short(cat), s, 22., 0xffffff))
                    .on_click(cx.listener(move |this, _: &ClickEvent, _, cx| {
                        this.cust.focus = Some(cat);
                        this.cust.tab = CustTab::Clothes;
                        cx.notify();
                    })),
            );
        }
        rail = rail.child(rail_in);

        // O personagem sobre a plataforma.
        let frame = abs(s, 155., 380., 538., 458.)
            .rounded(px(50. * s))
            .border(px(3. * s))
            .border_color(color(0x8b5cf6))
            .bg(color(0x07031a))
            .overflow_hidden();
        let platform_outer = abs(s, 205., 680., 440., 135.)
            .rounded(px(220. * s))
            .border(px(3. * s))
            .border_color(alpha(0x8b5cf6, 0.7))
            .bg(alpha(0x6d33e6, 0.18));
        let platform_inner = abs(s, 248., 707., 352., 83.)
            .rounded(px(176. * s))
            .border(px(4. * s))
            .border_color(color(0xa879ff))
            .bg(alpha(0x8b5cf6, 0.35));
        let figure: AnyElement = match self.cust_preview() {
            Some(image) => abs(s, 294., 392., 260., 380.)
                .child(img(image).w(px(260. * s)).h(px(380. * s)).object_fit(ObjectFit::Contain))
                .into_any_element(),
            None => div().into_any_element(),
        };

        // Os botões de girar.
        let turn = |id: &'static str, x: f32, w: f32, text: &'static str, delta: i32, strong: bool, cx: &mut Context<Self>| {
            pill(abs(s, x, 860., w, 112.), s, 32., strong)
                .id(id)
                .flex()
                .items_center()
                .justify_center()
                .gap(px(14. * s))
                .cursor_pointer()
                .font_family(PIXEL)
                .text_size(px(56. * s))
                .text_color(rgb(0xffffff))
                .child(text)
                .on_click(cx.listener(move |this, _: &ClickEvent, _, cx| {
                    this.cust_rotate(delta);
                    cx.notify();
                }))
        };
        let left = turn("cust-left", 118., 114., "←", -45, true, cx);
        let right = turn("cust-right", 486., 114., "→", 45, true, cx);
        let spin = pill(abs(s, 253., 860., 212., 112.), s, 32., false)
            .id("cust-spin")
            .flex()
            .items_center()
            .justify_center()
            .gap(px(14. * s))
            .cursor_pointer()
            .child(crate::glass_ui::icon("refresh", 44. * s, color(0xe9dcff)))
            .child(label("Girar", s, 44., 0xffffff))
            .on_click(cx.listener(|this, _: &ClickEvent, _, cx| {
                this.cust_rotate(90);
                cx.notify();
            }));

        // ---- As abas ----
        let mut tabs: Vec<AnyElement> = Vec::new();
        for (n, (t, text, icon)) in [
            (CustTab::Clothes, "Roupas", "user"),
            (CustTab::Hats, "Chapéus", "favourite"),
            (CustTab::Selections, "Seleções", "dashboard-square-01"),
            (CustTab::Import, "Importar", "folder-01"),
        ]
        .into_iter()
        .enumerate()
        {
            tabs.push(
                pill(abs(s, 720. + n as f32 * 378., 133., if n == 3 { 356. } else { 357. }, 110.), s, 40., t == tab)
                    .id(SharedString::from(format!("cust-tab-{n}")))
                    .flex()
                    .items_center()
                    .justify_center()
                    .gap(px(18. * s))
                    .cursor_pointer()
                    .child(crate::glass_ui::icon(icon, 44. * s, color(0xe9dcff)))
                    .child(label(text, s, 44., 0xffffff))
                    .on_click(cx.listener(move |this, _: &ClickEvent, _, cx| {
                        this.cust.tab = t;
                        this.cust.focus = match t {
                            CustTab::Clothes => None,
                            CustTab::Hats => Some(Category::Hat),
                            _ => this.cust.focus,
                        };
                        cx.notify();
                    }))
                    .into_any_element(),
            );
        }

        // ---- O painel ----
        let panel_children: Vec<AnyElement> = match (tab, focus) {
            (CustTab::Selections, _) => self.cust_selections(s, cx),
            (CustTab::Import, _) => self.cust_import_tab(s, cx),
            (CustTab::Hats, _) => self.cust_category(Category::Hat, s, cx),
            (CustTab::Clothes, Some(cat)) => self.cust_category(cat, s, cx),
            (CustTab::Clothes, None) => self.cust_overview(s, cx),
        };
        let panel = abs(s, 720., 265., 1490., 525.)
            .rounded(px(56. * s))
            .border(px(3. * s))
            .border_color(color(0x8b5cf6))
            .bg(color(PLATE))
            .children(panel_children);

        // ---- Os botões de baixo ----
        let import_skin = pill(abs(s, 720., 813., 467., 160.), s, 40., false)
            .id("cust-import-skin")
            .flex()
            .items_center()
            .gap(px(26. * s))
            .px(px(30. * s))
            .cursor_pointer()
            .child(crate::glass_ui::icon("folder-01", 64. * s, color(0xe9dcff)))
            .child(
                div()
                    .flex()
                    .flex_col()
                    .child(label("Importar Skin", s, 46., 0xffffff))
                    .child(label("Use seu arquivo .png", s, 30., 0xcdb6ff)),
            )
            .on_click(cx.listener(|this, _: &ClickEvent, _, cx| {
                this.cust_import(Category::Skin, cx);
                cx.notify();
            }));
        let restore = pill(abs(s, 1208., 813., 467., 160.), s, 40., false)
            .id("cust-restore")
            .flex()
            .items_center()
            .gap(px(26. * s))
            .px(px(30. * s))
            .cursor_pointer()
            .child(crate::glass_ui::icon("refresh", 64. * s, color(0xe9dcff)))
            .child(
                div()
                    .flex()
                    .flex_col()
                    .child(label("Restaurar Padrão", s, 46., 0xffffff))
                    .child(label("Voltar ao original", s, 30., 0xcdb6ff)),
            )
            .on_click(cx.listener(|this, _: &ClickEvent, _, cx| {
                this.cust_restore();
                cx.notify();
            }));
        let save = abs(s, 1697., 813., 513., 100.)
            .id("cust-save")
            .flex()
            .items_center()
            .justify_center()
            .gap(px(22. * s))
            .rounded(px(50. * s))
            .border(px(3. * s))
            .border_color(color(0x8dffb0))
            .bg(linear_gradient(
                180.,
                linear_color_stop(rgb(0x2ee66b), 0.),
                linear_color_stop(rgb(0x16a34a), 1.),
            ))
            .cursor_pointer()
            .child(crate::glass_ui::icon("tick-02", 56. * s, color(0xffffff)))
            .child(label("Salvar Alterações", s, 46., 0xffffff))
            .on_click(cx.listener(|this, _: &ClickEvent, _, cx| {
                this.cust_save();
                cx.notify();
            }));
        let notice: AnyElement = match &self.cust.notice {
            Some((text, error)) => abs(s, 1697., 920., 513., 70.)
                .child(label(text, s, 20., if *error { 0xff8a8a } else { 0x9dffbd }))
                .into_any_element(),
            None if self.cust.dirty => abs(s, 1697., 920., 513., 40.)
                .child(label("Há alterações sem salvar.", s, 22., 0xffd58a))
                .into_any_element(),
            None => div().into_any_element(),
        };

        div()
            .flex()
            .flex_col()
            .min_w_0()
            .mx(px(-crate::theme::PAGE_GUTTER))
            .mt(px(-crate::theme::PAGE_GUTTER))
            .child(
                div()
                    .relative()
                    .flex_none()
                    .w(px(width))
                    .h(px(REF_H * s))
                    .bg(linear_gradient(
                        180.,
                        linear_color_stop(rgb(0x2b1068), 0.),
                        linear_color_stop(rgb(0x140826), 1.),
                    ))
                    .child(bar)
                    .child(back_bar)
                    .child(back_small)
                    .child(title)
                    .child(name)
                    .child(rail)
                    .child(frame)
                    .child(platform_outer)
                    .child(platform_inner)
                    .child(figure)
                    .child(left)
                    .child(spin)
                    .child(right)
                    .children(tabs)
                    .child(panel)
                    .child(import_skin)
                    .child(restore)
                    .child(save)
                    .child(notice),
            )
    }
}
