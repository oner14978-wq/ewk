use super::*;

fn png(img: &RgbaImage) -> Vec<u8> {
    png_bytes(img)
}

#[test]
fn legacy_skin_becomes_64x64_with_mirrored_left_limbs() {
    let mut old = RgbaImage::new(64, 32);
    // Um pixel da frente da perna direita (0,16)+(4,4): x 4..8, y 20..32.
    old.put_pixel(4, 20, Rgba([10, 20, 30, 255]));
    let new = normalize_skin(&old).unwrap();
    assert_eq!((new.width(), new.height()), (64, 64));
    // A frente da perna esquerda (16,48)+(4,4): x 20..24, y 52..64, espelhada.
    assert_eq!(new.get_pixel(23, 52), &Rgba([10, 20, 30, 255]));
}

#[test]
fn skin_with_wrong_size_is_refused() {
    let img = RgbaImage::new(50, 50);
    assert!(normalize_skin(&img).unwrap_err().contains("64x64"));
}

#[test]
fn not_a_png_is_refused() {
    assert!(validate(Category::Shirt, b"GIF89a....").is_err());
}

#[test]
fn clothes_file_without_pixels_in_its_region_is_refused() {
    // Só a cabeça tem pixels: não é uma calça.
    let mut img = RgbaImage::new(64, 64);
    fill(&mut img, (8, 8, 8, 8), [255, 0, 0, 255]);
    assert!(validate(Category::Pants, &png(&img)).is_err());
    assert!(validate(Category::Hat, &png(&img)).is_err());
    let mut hat = RgbaImage::new(64, 64);
    fill(&mut hat, (40, 0, 8, 8), [255, 0, 0, 255]);
    assert!(validate(Category::Hat, &png(&hat)).is_ok());
}

#[test]
fn capes_of_every_accepted_size_become_64x32() {
    for (w, h) in [(64, 32), (22, 17), (128, 64), (44, 34)] {
        let mut img = RgbaImage::new(w, h);
        fill(&mut img, (0, 0, w, h), [200, 0, 0, 255]);
        let cape = validate(Category::Cape, &png(&img)).unwrap();
        assert_eq!((cape.width(), cape.height()), (64, 32), "{w}x{h}");
    }
    let bad = RgbaImage::new(30, 30);
    assert!(validate(Category::Cape, &png(&bad)).is_err());
    let empty = RgbaImage::new(64, 32);
    assert!(validate(Category::Cape, &png(&empty)).is_err());
}

#[test]
fn every_builtin_part_changes_the_skin_in_its_region() {
    let dir = tempfile::tempdir().unwrap();
    let store = Store::open(dir.path().to_path_buf());
    let base = store.compose(&Outfit::default());
    for cat in Category::WEARABLE.iter().copied().filter(|c| *c != Category::Cape) {
        let parts = store.parts(cat);
        assert!(!parts.is_empty(), "{cat:?}");
        for part in parts {
            let mut o = Outfit::default();
            o.set(cat, Some(part.id.clone()));
            let skin = store.compose(&o);
            assert_ne!(skin.as_raw(), base.as_raw(), "{} não muda a skin", part.id);
        }
    }
}

#[test]
fn every_builtin_cape_is_valid() {
    let dir = tempfile::tempdir().unwrap();
    let store = Store::open(dir.path().to_path_buf());
    let parts = store.parts(Category::Cape);
    assert!(parts.len() >= 5);
    for part in parts {
        let mut o = Outfit::default();
        o.cape = Some(part.id.clone());
        let cape = store.cape(&o).expect(&part.id);
        assert_eq!((cape.width(), cape.height()), (64, 32));
        assert!(validate(Category::Cape, &png(&cape)).is_ok());
    }
}

#[test]
fn import_survives_reopening_and_is_applied() {
    let dir = tempfile::tempdir().unwrap();
    let root = dir.path().join("customize");
    let mut shirt = RgbaImage::new(64, 64);
    for r in region(Category::Shirt, false, false).base {
        fill(&mut shirt, r, [1, 2, 3, 255]);
    }
    let file = dir.path().join("minha camisa.png");
    std::fs::write(&file, png(&shirt)).unwrap();
    let item = import_file(&root, Category::Shirt, &file).unwrap();
    assert_eq!(item.name, "minha camisa");
    let mut store = Store::open(root.clone());
    store.add(item.clone()).unwrap();
    store.add(item.clone()).unwrap();
    assert_eq!(store.library.len(), 1);
    let mut outfit = Outfit::default();
    outfit.shirt = Some(item.id.clone());
    store.save(&outfit).unwrap();

    // Fechar e abrir o launcher.
    let again = Store::open(root.clone());
    assert_eq!(again.library, store.library);
    assert_eq!(again.saved, outfit);
    assert!(again.parts(Category::Shirt).iter().any(|p| p.id == item.id && p.imported));
    let skin = again.compose(&again.saved);
    assert_eq!(skin.get_pixel(20, 20), &Rgba([1, 2, 3, 255]));
    // O arquivo que o jogo lê tem a mesma skin.
    let on_disk = image::open(root.join("skin.png")).unwrap().to_rgba8();
    assert_eq!(on_disk.as_raw(), skin.as_raw());
}

#[test]
fn saving_with_a_cape_writes_it_and_removing_it_deletes_it() {
    let dir = tempfile::tempdir().unwrap();
    let mut store = Store::open(dir.path().join("c"));
    let mut o = Outfit::default();
    o.cape = Some("b:cape:red".into());
    store.save(&o).unwrap();
    let cape = image::open(store.root().join("cape.png")).unwrap();
    assert_eq!((cape.width(), cape.height()), (64, 32));
    assert!(!store.root().join("skin.png").exists());
    o.cape = None;
    store.save(&o).unwrap();
    assert!(!store.root().join("cape.png").exists());
}

#[test]
fn restoring_the_default_removes_the_files_the_game_reads() {
    let dir = tempfile::tempdir().unwrap();
    let mut store = Store::open(dir.path().join("c"));
    let mut o = Outfit::default();
    o.shirt = Some("b:shirt:red".into());
    o.cape = Some("b:cape:blue".into());
    store.save(&o).unwrap();
    assert!(store.root().join("skin.png").exists());
    store.save(&Outfit::default()).unwrap();
    assert!(!store.root().join("skin.png").exists());
    assert!(!store.root().join("cape.png").exists());
    assert!(Store::open(store.root().to_path_buf()).saved.is_default());
}

#[test]
fn removing_an_import_deletes_its_file() {
    let dir = tempfile::tempdir().unwrap();
    let root = dir.path().join("c");
    let mut hat = RgbaImage::new(64, 64);
    fill(&mut hat, (40, 0, 8, 8), [9, 9, 9, 255]);
    let file = dir.path().join("h.png");
    std::fs::write(&file, png(&hat)).unwrap();
    let item = import_file(&root, Category::Hat, &file).unwrap();
    let mut store = Store::open(root.clone());
    store.add(item.clone()).unwrap();
    store.remove(&item.id).unwrap();
    assert!(store.library.is_empty());
    assert!(!root.join("imports").join(format!("{}.png", item.id)).exists());
}

#[test]
fn slim_skin_is_detected() {
    let mut s = RgbaImage::new(64, 64);
    fill(&mut s, (40, 16, 16, 16), [5, 5, 5, 255]);
    assert!(!is_slim(&s));
    s.put_pixel(54, 20, Rgba([0, 0, 0, 0]));
    s.put_pixel(55, 20, Rgba([0, 0, 0, 0]));
    assert!(is_slim(&s));
}

#[test]
fn render_shows_front_side_and_back() {
    let skin = default_skin();
    let cape = builtin_cape("red");
    let front = render(&skin, None, false, &View::full(0));
    let side = render(&skin, None, false, &View::full(90));
    let back = render(&skin, None, false, &View::full(180));
    let opaque = |i: &RgbaImage| i.pixels().filter(|p| p[3] > 0).count();
    assert!(opaque(&front) > 5000);
    // De lado o personagem é mais estreito; de costas tem a largura da frente.
    assert!(opaque(&side) < opaque(&front));
    assert!(opaque(&back).abs_diff(opaque(&front)) < opaque(&front) / 10);
    // O rosto aparece na frente e o cabelo atrás: o pixel do meio da cabeça difere.
    let mid = |i: &RgbaImage| *i.get_pixel(i.width() / 2, ((33.5 - 28.) * 9.) as u32);
    assert_ne!(mid(&front), mid(&back));
    // A capa só aparece de costas.
    let with_cape_back = render(&skin, cape.as_ref(), false, &View::full(180));
    let with_cape_front = render(&skin, cape.as_ref(), false, &View::full(0));
    // Os pixels que a capa muda: muitos de costas, quase nenhum de frente (só a ponta que
    // passa ao lado das pernas).
    let changed = |a: &RgbaImage, b: &RgbaImage| a.pixels().zip(b.pixels()).filter(|(x, y)| x != y).count();
    assert!(changed(&with_cape_back, &back) > 8000);
    assert!(changed(&with_cape_front, &front) < 1000);
    let center = with_cape_back.get_pixel(with_cape_back.width() / 2, ((33.5 - 16.) * 9.) as u32);
    assert_eq!(center[3], 255);
    assert!(center[0] > center[2], "a capa vermelha aparece nas costas");
}

#[test]
fn thumbnails_have_content_for_every_part() {
    let dir = tempfile::tempdir().unwrap();
    let store = Store::open(dir.path().to_path_buf());
    for cat in Category::WEARABLE {
        for part in store.parts(cat) {
            let t = store.thumbnail(cat, &part.id);
            assert!(t.pixels().any(|p| p[3] > 0), "{}", part.id);
        }
    }
}

#[test]
fn path_tricks_in_ids_are_not_followed() {
    let dir = tempfile::tempdir().unwrap();
    let store = Store::open(dir.path().to_path_buf());
    assert!(store.image("i-../../etc/passwd").is_none());
    assert!(store.image("../x").is_none());
}
