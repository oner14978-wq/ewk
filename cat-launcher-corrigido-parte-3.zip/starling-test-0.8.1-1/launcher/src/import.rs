//! A file dropped on the window (or given to `instance import`): what it is, and an instance
//! made from a shared one.
//!
//! - A `.mrpack` that needs no mod loader (only `minecraft` in its dependencies), such as
//!   [`crate::export`] writes, or a `.zip` laid out as a game folder: a new instance. Its
//!   `overrides/` (and `client-overrides/`) go into the instance's folder; each of its `files`
//!   is downloaded from Modrinth and checked against its SHA-512 (`browser::download`).
//! - A `.mrpack` for a mod loader, or a CurseForge modpack zip (`manifest.json`): a Java
//!   modpack, for the Modpacks import (`modpacks::import`).
//! - A zip with `pack.mcmeta`: a data pack (`data/`) or a resource pack; with `shaders/`, or a
//!   `.hshader`: a shader pack.
//!
//! Only what an instance holds is taken from a shared zip ([`crate::export::FILES`],
//! [`crate::export::FOLDERS`], `saves/`), and every path is checked to stay inside its folder.
use crate::browser::{download, installed, FileRef};
use crate::export::{FILES, FOLDERS};
use crate::instances::{self, Instance};
use crate::packs;
use std::fs;
use std::io::Read;
use std::path::{Component, Path, PathBuf};

const INDEX: &str = "modrinth.index.json";
/// The `.mrpack` folders copied into the game folder; `server-overrides/` is a server's.
const OVERRIDES: [&str; 2] = ["overrides/", "client-overrides/"];

/// What a dropped file is.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Dropped {
    /// A shared instance: a new instance is made from it.
    Instance,
    /// A Java modpack, for the Modpacks import.
    Modpack,
    /// A resource or shader pack, for the selected instance.
    Pack(packs::Kind),
    /// A data pack: it goes into a world.
    DataPack,
    /// A game build: a `horizon-client` program, or a release archive or an
    /// Actions artifact around one. `build_import` installs it as its own
    /// version beside the releases, so a build can be played without waiting
    /// for a Nightly.
    Build,
}

/// Whether `file` holds a game build (`build_import::holds_game`). Asked only
/// where the cheap checks have not matched: it reads the whole program.
fn is_build(file: &Path) -> bool {
    crate::build_import::holds_game(file)
}

fn open(file: &Path) -> Result<zip::ZipArchive<fs::File>, String> {
    fs::File::open(file)
        .ok()
        .and_then(|f| zip::ZipArchive::new(f).ok())
        .ok_or_else(|| format!("{} is not a zip file that can be read.", name_of(file)))
}

fn name_of(file: &Path) -> String {
    file.file_name()
        .map(|n| n.to_string_lossy().into_owned())
        .unwrap_or_default()
}

fn read_index(zip: &mut zip::ZipArchive<fs::File>) -> Result<serde_json::Value, String> {
    let mut text = Vec::new();
    zip.by_name(INDEX)
        .map_err(|_| format!("It has no {INDEX}: not a .mrpack."))?
        .take(16 << 20)
        .read_to_end(&mut text)
        .map_err(|e| e.to_string())?;
    serde_json::from_slice(&text).map_err(|e| format!("{INDEX}: {e}"))
}

/// What `file` is, from its name and what is inside.
pub fn what(file: &Path) -> Result<Dropped, String> {
    let name = name_of(file);
    let ext = file
        .extension()
        .map(|e| e.to_string_lossy().to_ascii_lowercase());
    match ext.as_deref() {
        Some("hshader") => return Ok(Dropped::Pack(packs::Kind::Shader)),
        // A game build: the program itself, or a release archive around it.
        // Taken on the extension alone, unread, so that `build_import` is the
        // one to say why a file with this name is not a game -- a better answer
        // than this function's "nothing in it that Horizon reads".
        Some("exe" | "gz" | "tgz") => return Ok(Dropped::Build),
        Some("mrpack") => {
            let index = read_index(&mut open(file)?)?;
            let loaders = index["dependencies"]
                .as_object()
                .is_some_and(|d| d.keys().any(|k| k != "minecraft"));
            return Ok(match loaders {
                true => Dropped::Modpack,
                false => Dropped::Instance,
            });
        }
        Some("zip") => {}
        // A build for Linux or macOS is named `horizon-client` with no
        // extension, so a file nothing else claims is read before giving up.
        _ if is_build(file) => return Ok(Dropped::Build),
        _ => {
            let kinds = "a .mrpack, a .zip, a .hshader or a Horizon game build";
            return Err(format!("{name} can't be imported: drop {kinds}."));
        }
    }
    let zip = open(file)?;
    let has = |n: &str| zip.index_for_name(n).is_some();
    let names: Vec<_> = zip
        .file_names()
        .collect::<Result<_, _>>()
        .map_err(|e| e.to_string())?;
    let under = |p: &str| names.iter().any(|n| n.starts_with(p));
    if has("manifest.json") && !has("pack.mcmeta") {
        return Ok(Dropped::Modpack);
    }
    if has("pack.mcmeta") {
        return Ok(match under("data/") {
            true => Dropped::DataPack,
            false => Dropped::Pack(packs::Kind::Resource),
        });
    }
    if under("shaders/") {
        return Ok(Dropped::Pack(packs::Kind::Shader));
    }
    if FILES.iter().any(|f| has(f))
        || under("saves/")
        || FOLDERS.iter().any(|f| under(&format!("{f}/")))
    {
        return Ok(Dropped::Instance);
    }
    // An Actions artifact is a zip holding the release archive: the last thing
    // a zip can be, once nothing a pack or an instance holds has matched.
    if is_build(file) {
        return Ok(Dropped::Build);
    }
    Err(format!(
        "{name} is neither a pack, a shared instance nor a game build: nothing in it that Horizon reads."
    ))
}

/// Where an archive entry goes in the instance's folder, when it is one an instance holds and
/// stays inside it. A Java instance (`java`) holds whatever its pack carries (`mods/`,
/// `kubejs/`...), as long as it stays inside.
fn target(home: &Path, relative: &str, java: bool) -> Option<PathBuf> {
    let path = Path::new(relative);
    if relative.ends_with('/') || !path.components().all(|c| matches!(c, Component::Normal(_))) {
        return None;
    }
    // The browser's list of what it installed is the launcher's, never a pack's: it names the
    // files Update and Remove delete.
    if relative.eq_ignore_ascii_case(installed::MANIFEST) {
        return None;
    }
    if java {
        return Some(home.join(path));
    }
    let top = relative.split('/').next()?;
    let kept = FILES.contains(&relative)
        || (relative.contains('/') && (FOLDERS.contains(&top) || top == "saves"));
    kept.then(|| home.join(path))
}

/// Makes a new instance from a shared one: `file` is a `.mrpack` without mod loaders or a game
/// folder `.zip`. Named after the pack (or the file), with "(2)" when the name is taken.
pub fn import_instance(file: &Path, progress: &dyn Fn(&str, f32)) -> Result<Instance, String> {
    import_into(file, progress, &|name| instances::create(name, None))
}

/// The most a shared instance or a `.mrpack` may unpack to, all files together. A zip's sizes are its
/// own claim, so [`fill`] counts the bytes actually inflated: a few kilobytes of zip bomb can't fill the
/// disk.
pub const MAX_IMPORT: u64 = 8 << 30;

/// [`import_instance`] with the instance made by `create`.
pub fn import_into(
    file: &Path,
    progress: &dyn Fn(&str, f32),
    create: &dyn Fn(&str) -> Result<Instance, String>,
) -> Result<Instance, String> {
    if what(file)? != Dropped::Instance {
        return Err(format!("{} is not a shared instance.", name_of(file)));
    }
    import_any(file, progress, create, false, MAX_IMPORT)
}

/// A `.mrpack`'s index.
pub fn mrpack_index(file: &Path) -> Result<serde_json::Value, String> {
    read_index(&mut open(file)?)
}

/// A `.mrpack`, with or without mod loaders, into the Java instance `create` makes
/// (`crate::instances_mrpack`): every override and file it carries.
pub fn import_mrpack_into(
    file: &Path,
    progress: &dyn Fn(&str, f32),
    create: &dyn Fn(&str) -> Result<Instance, String>,
) -> Result<Instance, String> {
    mrpack_index(file)?;
    import_any(file, progress, create, true, MAX_IMPORT)
}

/// [`import_into`] without asking what the file is, into a Java instance when `java`, with at most
/// `limit` bytes unpacked from the archive.
fn import_any(
    file: &Path,
    progress: &dyn Fn(&str, f32),
    create: &dyn Fn(&str) -> Result<Instance, String>,
    java: bool,
    limit: u64,
) -> Result<Instance, String> {
    let mut zip = open(file)?;
    let mrpack = zip.index_for_name(INDEX).is_some();
    let index = match mrpack {
        true => Some(read_index(&mut zip)?),
        false => None,
    };
    let stem = file
        .file_stem()
        .map(|s| s.to_string_lossy().into_owned())
        .unwrap_or_else(|| "Imported".into());
    let base = index
        .as_ref()
        .and_then(|i| i["name"].as_str())
        .map(str::trim)
        .filter(|n| !n.is_empty())
        .map(str::to_string)
        .unwrap_or(stem);
    let instance = (1..20)
        .map(|n| match n {
            1 => base.clone(),
            n => format!("{base} ({n})"),
        })
        .find_map(|name| create(&name).ok())
        .ok_or_else(|| format!("Could not make an instance called {base}."))?;
    let home = instance.home.clone();
    let filled = fill(&mut zip, index.as_ref(), &home, java, progress, limit);
    if let Err(e) = filled {
        let _ = fs::remove_dir_all(&home);
        return Err(e);
    }
    Ok(instance)
}

/// `limit` as people read it: GiB from 1 GiB up, else KiB.
fn size_text(limit: u64) -> String {
    if limit >= 1 << 30 {
        format!("{} GiB", limit >> 30)
    } else {
        format!("{} KiB", limit.div_ceil(1024))
    }
}

fn fill(
    zip: &mut zip::ZipArchive<fs::File>,
    index: Option<&serde_json::Value>,
    home: &Path,
    java: bool,
    progress: &dyn Fn(&str, f32),
    limit: u64,
) -> Result<(), String> {
    let count = zip.len();
    let mut total = 0u64;
    for i in 0..count {
        let mut entry = zip.by_index(i).map_err(|e| e.to_string())?;
        let name = entry.name().map_err(|e| e.to_string())?.into_owned();
        let relative = match index {
            Some(_) => match OVERRIDES.iter().find_map(|o| name.strip_prefix(o)) {
                Some(r) => r.to_string(),
                None => continue,
            },
            None => name.clone(),
        };
        let Some(to) = target(home, &relative, java) else {
            continue;
        };
        fs::create_dir_all(to.parent().expect("inside home")).map_err(|e| e.to_string())?;
        let mut out = fs::File::create(&to).map_err(|e| format!("{}: {e}", to.display()))?;
        // At most one byte past what is left: reading it means the archive holds more than `limit`.
        let room = limit.saturating_sub(total);
        let written = std::io::copy(&mut (&mut entry).take(room.saturating_add(1)), &mut out)
            .map_err(|e| format!("{}: {e}", to.display()))?;
        total = total.saturating_add(written);
        if written > room {
            return Err(crate::i18n::trf(
                "{file} unpacks to more than {limit}: it isn't imported.",
                &[("file", &name_of(&to)), ("limit", &size_text(limit))],
            ));
        }
        progress(
            &format!("Copying {relative}"),
            (i + 1) as f32 / count as f32,
        );
    }
    let files = index
        .and_then(|i| i["files"].as_array())
        .cloned()
        .unwrap_or_default();
    for f in files {
        if f["env"]["client"] == "unsupported" {
            continue;
        }
        let relative = f["path"].as_str().unwrap_or_default();
        let to = target(home, relative, java)
            .ok_or_else(|| format!("{relative} isn't a place an instance keeps files."))?;
        let file = FileRef {
            url: f["downloads"][0].as_str().unwrap_or_default().to_string(),
            name: to.file_name().unwrap().to_string_lossy().into_owned(),
            size: f["fileSize"].as_u64().unwrap_or(0),
            sha512: f["hashes"]["sha512"].as_str().map(str::to_ascii_lowercase),
            sha256: None,
            sha1: f["hashes"]["sha1"].as_str().map(str::to_ascii_lowercase),
            primary: true,
        };
        let folder = to.parent().expect("inside home");
        download::fetch(&file, folder, &|p| progress(&file.name, p))
            .map_err(|e| format!("{relative}: {e}"))?;
    }
    Ok(())
}

#[cfg(test)]
#[path = "import/tests.rs"]
mod tests;
