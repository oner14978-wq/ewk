//! The Windows setup window: `horizon-launcher-setup.exe` installs, `horizon-launcher.exe
//! uninstall` removes. The launcher's own sky and plates (docs/design-system.md, "Night"); the
//! work is `horizon_launcher::installer`, on a thread, reported over a channel.
use crate::glass_ui;
use crate::scene;
use crate::shell::{c, text};
use crate::sky::Sky;
use crate::theme::{self, night, Theme};
use crate::titlebar;
use crate::Kind;
use gpui::{
    div, prelude::*, px, size, App, Bounds, ClickEvent, Context, Div, PathPromptOptions, Render,
    Task, Window, WindowBounds, WindowOptions,
};
use horizon_launcher::backend::Settings;
use horizon_launcher::i18n::{self, tr};
use horizon_launcher::installer::{self, Mode, Options, Step};
use std::sync::mpsc::{channel, Receiver};
use std::time::{Duration, Instant};

enum Stage {
    Welcome,
    Working { step: Step, fraction: f32 },
    Done { left: Vec<String> },
    Failed(String),
}

enum Event {
    Step(Step, f32),
    Done(Result<Vec<String>, String>),
}

pub struct Setup {
    mode: Mode,
    theme: Theme,
    /// The redesign's scene behind the dark window (as the launcher draws it); the light
    /// appearance keeps the dawn sky until the design has a light scene.
    scene: gpui::Entity<scene::Scene>,
    sky: Sky,
    sky_wake: Option<(Instant, Task<()>)>,
    /// The settings file's write time and size as last read: a change (the launcher's Settings
    /// page) rebuilds the theme on the next frame, as the launcher applies it on its own next
    /// frame.
    settings_stamp: Option<(std::time::SystemTime, u64)>,
    options: Options,
    /// An install is already there: the button says Update.
    update: bool,
    stage: Stage,
    rx: Option<Receiver<Event>>,
}

/// Opens the setup window in place of the launcher's.
pub fn open(mode: Mode, cx: &mut App) {
    let bounds = Bounds::centered(None, size(px(760.), px(520.)), cx);
    cx.open_window(
        WindowOptions {
            window_bounds: Some(WindowBounds::Windowed(bounds)),
            window_min_size: Some(size(px(760.), px(520.))),
            titlebar: Some(titlebar::options()),
            app_id: Some(horizon_launcher::identity::APP_ID.into()),
            ..Default::default()
        },
        |window, cx| cx.new(|cx| Setup::new(mode, window, cx)),
    )
    .expect("window");
    cx.on_window_closed(|cx, _| cx.quit()).detach();
    cx.activate(true);
}

fn step_text(step: Step) -> String {
    match step {
        // A launcher still open is being asked to quit (an existing, translated word).
        Step::Closing => tr("Stopping").to_string(),
        Step::Files => tr("Copying files").to_string(),
        Step::Shortcuts => tr("Making shortcuts").to_string(),
        Step::Registry => tr("Registering with Windows").to_string(),
        Step::Removing => tr("Removing files").to_string(),
        Step::Data => tr("Removing the launcher's data").to_string(),
    }
}

impl Setup {
    fn new(mode: Mode, window: &mut Window, cx: &mut Context<Self>) -> Self {
        let settings = Settings::load();
        i18n::set(settings.language());
        titlebar::apply_appearance(window, settings.appearance);
        Self {
            mode,
            theme: Theme::for_appearance(settings.appearance, settings.accent, window.appearance())
                .with_glass(settings.glass_tint(), settings.glass_blur()),
            scene: cx.new(|_| scene::Scene::new()),
            sky: Sky::default(),
            sky_wake: None,
            settings_stamp: Self::settings_stamp(),
            options: Options::new(),
            update: installer::installed().is_some(),
            stage: Stage::Welcome,
            rx: None,
        }
    }

    /// The settings file's write time and size, to notice a change made in the launcher.
    fn settings_stamp() -> Option<(std::time::SystemTime, u64)> {
        let meta =
            std::fs::metadata(horizon_launcher::backend::data_dir().join("settings.json")).ok()?;
        Some((meta.modified().ok()?, meta.len()))
    }

    /// Draws the window again when the sky next changes (as `Launcher::wake_sky`).
    fn wake_sky(&mut self, after: Duration, cx: &mut Context<Self>) {
        let at = Instant::now() + after;
        if self.sky_wake.as_ref().is_some_and(|(when, _)| *when <= at) {
            return;
        }
        let timer = cx.spawn(async move |this, cx| {
            cx.background_executor().timer(after).await;
            let _ = this.update(cx, |this, cx| {
                this.sky_wake = None;
                cx.notify();
            });
        });
        self.sky_wake = Some((at, timer));
    }

    fn start(&mut self, cx: &mut Context<Self>) {
        let (tx, rx) = channel();
        self.rx = Some(rx);
        self.stage = Stage::Working {
            step: if self.mode == Mode::Install {
                Step::Files
            } else {
                Step::Shortcuts
            },
            fraction: 0.02,
        };
        let (mode, options) = (self.mode, self.options.clone());
        std::thread::spawn(move || {
            let report = |step: Step, fraction: f32| {
                let _ = tx.send(Event::Step(step, fraction));
            };
            let result = match mode {
                Mode::Install => installer::install(&options, report).map(|_| Vec::new()),
                // Asks a launcher that is still open to quit first (`installer::uninstall`).
                Mode::Uninstall => installer::uninstall(options.remove_data, report),
            };
            let _ = tx.send(Event::Done(result));
        });
        cx.spawn(async move |this, cx| loop {
            cx.background_executor()
                .timer(Duration::from_millis(80))
                .await;
            match this.update(cx, |this, cx| this.drain(cx)) {
                Ok(true) => {}
                _ => break,
            }
        })
        .detach();
        cx.notify();
    }

    /// Takes what the worker said; false once it has finished.
    fn drain(&mut self, cx: &mut Context<Self>) -> bool {
        let Some(rx) = &self.rx else {
            return false;
        };
        let (mut changed, mut finished) = (false, false);
        while let Ok(event) = rx.try_recv() {
            changed = true;
            match event {
                Event::Step(step, fraction) => self.stage = Stage::Working { step, fraction },
                Event::Done(Ok(left)) => {
                    self.stage = Stage::Done { left };
                    finished = true;
                }
                Event::Done(Err(e)) => {
                    self.stage = Stage::Failed(e);
                    finished = true;
                }
            }
        }
        if finished {
            self.rx = None;
        }
        if changed {
            cx.notify();
        }
        !finished
    }

    fn choose_folder(&mut self, cx: &mut Context<Self>) {
        let paths = cx.prompt_for_paths(PathPromptOptions {
            files: false,
            directories: true,
            multiple: false,
            prompt: Some(tr("Choose").into()),
        });
        cx.spawn(async move |this, cx| {
            if let Ok(Ok(Some(mut paths))) = paths.await {
                if let Some(path) = paths.pop() {
                    let _ = this.update(cx, |this, cx| {
                        this.options.dir = installer::folder_for(&path);
                        cx.notify();
                    });
                }
            }
        })
        .detach();
    }

    fn launch(&mut self, cx: &mut Context<Self>) {
        if let Some(exe) = installer::installed_exe() {
            let _ = std::process::Command::new(exe).spawn();
        }
        cx.quit();
    }

    /// A switch with its words (and a quiet line under them).
    fn toggle(
        &self,
        id: &'static str,
        on: bool,
        words: String,
        hint: Option<String>,
        flip: fn(&mut Options),
        cx: &mut Context<Self>,
    ) -> Div {
        let (t, n) = (self.theme, self.theme.night);
        div()
            .flex()
            .items_center()
            .gap(px(14.))
            .child(crate::switch(id, on, &t).on_click(cx.listener(
                move |this, _: &ClickEvent, _, cx| {
                    flip(&mut this.options);
                    cx.notify();
                },
            )))
            .child(
                div()
                    .flex()
                    .flex_col()
                    .min_w_0()
                    .child(text(night::UI, c(n.ink)).child(words))
                    .children(hint.map(|h| text(night::CAPTION, c(n.muted)).child(h))),
            )
    }

    fn folder_row(&self, cx: &mut Context<Self>) -> Div {
        let (t, n) = (self.theme, self.theme.night);
        div()
            .flex()
            .items_center()
            .gap(px(12.))
            .child(
                div()
                    .flex()
                    .flex_col()
                    .flex_1()
                    .min_w_0()
                    .child(text(night::CAPTION, c(n.muted)).child(tr("Install to").to_string()))
                    .child(
                        text(theme::MICRO, c(n.ink_soft))
                            .font_family(theme::MONO)
                            .truncate()
                            .child(self.options.dir.display().to_string()),
                    ),
            )
            .child(
                crate::button("change", tr("Change…"), Kind::Secondary, &t)
                    .on_click(cx.listener(|this, _: &ClickEvent, _, cx| this.choose_folder(cx))),
            )
    }

    fn card(&self, cx: &mut Context<Self>) -> Div {
        let (t, n) = (self.theme, self.theme.night);
        let mut body = div().flex().flex_col().gap(px(16.));
        match &self.stage {
            Stage::Welcome if self.mode == Mode::Install => {
                body = body
                    .child(text(night::UI, c(n.ink_soft)).child(
                        tr(if cfg!(horizon_fork_launcher) { "Installs Horizon Fork Launcher (arismoko) for this account. No administrator needed." } else { "Installs Horizon Launcher for this account. No administrator needed." })
                            .to_string(),
                    ))
                    .child(self.folder_row(cx))
                    .child(self.toggle(
                        "desktop",
                        self.options.desktop,
                        tr("Desktop shortcut").to_string(),
                        None,
                        |o| o.desktop = !o.desktop,
                        cx,
                    ))
                    .child(div().flex().justify_end().child(
                        crate::button(
                            "go",
                            if self.update {
                                tr("Update").to_string()
                            } else {
                                tr("Install").to_string()
                            },
                            Kind::Primary,
                            &t,
                        )
                        .on_click(cx.listener(|this, _: &ClickEvent, _, cx| this.start(cx))),
                    ));
            }
            Stage::Welcome => {
                body = body
                    .child(text(night::UI, c(n.ink_soft)).child(
                        tr(if cfg!(horizon_fork_launcher) { "Removes Horizon Fork Launcher (arismoko) from this computer. Your worlds and the game's folder stay." } else { "Removes Horizon Launcher from this computer. Your worlds and the game's folder stay." })
                            .to_string(),
                    ))
                    .child(self.toggle(
                        "data",
                        self.options.remove_data,
                        tr("Also delete the launcher's data").to_string(),
                        Some(
                            tr("Game builds, servers made in the launcher, settings, skins.")
                                .to_string(),
                        ),
                        |o| o.remove_data = !o.remove_data,
                        cx,
                    ))
                    .child(
                        div()
                            .flex()
                            .items_center()
                            .justify_end()
                            .gap(px(12.))
                            .child(
                                crate::button("cancel", tr("Cancel"), Kind::Secondary, &t)
                                    .on_click(cx.listener(|_, _: &ClickEvent, _, cx| cx.quit())),
                            )
                            .child(
                                crate::button("go", tr("Uninstall"), Kind::Primary, &t)
                                    .on_click(
                                        cx.listener(|this, _: &ClickEvent, _, cx| this.start(cx)),
                                    ),
                            ),
                    );
            }
            Stage::Working { step, fraction } => {
                body = body
                    .child(text(night::UI, c(n.ink)).child(step_text(*step)))
                    .child(crate::progress_bar(Some((0., *fraction)), &t));
            }
            Stage::Done { left } => {
                let said = match self.mode {
                    Mode::Install => tr(if cfg!(horizon_fork_launcher) {
                        "Horizon Fork Launcher (arismoko) is installed."
                    } else {
                        "Horizon Launcher is installed."
                    })
                    .to_string(),
                    Mode::Uninstall => tr(if cfg!(horizon_fork_launcher) {
                        "Horizon Fork Launcher (arismoko) was removed."
                    } else {
                        "Horizon Launcher was removed."
                    })
                    .to_string(),
                };
                body = body.child(text(night::TITLE, c(n.ink)).child(said));
                if !left.is_empty() {
                    body = body.child(
                        text(night::CAPTION, c(n.warn))
                            .child(tr("These could not be removed:").to_string()),
                    );
                    for item in left {
                        body = body.child(
                            text(theme::MICRO, c(n.muted))
                                .font_family(theme::MONO)
                                .child(item.clone()),
                        );
                    }
                }
                // The window's own close control is in the title bar, so the last screen has only
                // the action worth taking; an uninstall just says so and is closed there.
                if self.mode == Mode::Install {
                    body = body.child(
                        div().flex().items_center().justify_end().child(
                            crate::button(
                                "launch",
                                tr(if cfg!(horizon_fork_launcher) {
                                    "Launch Horizon Fork Launcher (arismoko)"
                                } else {
                                    "Launch Horizon"
                                }),
                                Kind::Primary,
                                &t,
                            )
                            .on_click(cx.listener(|this, _: &ClickEvent, _, cx| this.launch(cx))),
                        ),
                    );
                }
            }
            Stage::Failed(error) => {
                body = body
                    .child(
                        text(night::TITLE, c(n.ink)).child(tr("Something went wrong.").to_string()),
                    )
                    .child(text(night::CAPTION, c(n.danger)).child(error.clone()))
                    .child(
                        div().flex().justify_end().child(
                            crate::button("close", tr("Close"), Kind::Secondary, &t)
                                .on_click(cx.listener(|_, _: &ClickEvent, _, cx| cx.quit())),
                        ),
                    );
            }
        }
        glass_ui::dialog_plate(horizon_theme::glass::radius::MODAL)
            .w(px(560.))
            .p(px(32.))
            .flex()
            .flex_col()
            .gap(px(18.))
            .child(
                text(night::DISPLAY, c(n.ink)).child(tr(horizon_launcher::identity::WINDOW_TITLE)),
            )
            .child(body)
    }
}

impl Render for Setup {
    fn render(&mut self, window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
        // The launcher's Settings page writes Glass, Blur, Accent and Appearance into
        // settings.json. Reading its write time each frame applies a change on the next frame:
        // the same cadence at which the launcher's own window picks them up.
        let stamp = Self::settings_stamp();
        if stamp != self.settings_stamp {
            self.settings_stamp = stamp;
            let settings = Settings::load();
            i18n::set(settings.language());
            titlebar::apply_appearance(window, settings.appearance);
            self.theme =
                Theme::for_appearance(settings.appearance, settings.accent, window.appearance())
                    .with_glass(settings.glass_tint(), settings.glass_blur());
        }
        // Look again twice a second, through the same wake the sky uses, so a settings change
        // shows even while the scene has stopped animating, without drawing the window at
        // 60 fps and reading the file's metadata every frame for it.
        self.wake_sky(Duration::from_millis(500), cx);
        let t = self.theme;
        let viewport = window.viewport_size();
        // The card's controls use the launcher's glass look and the player's accent, as the
        // launcher draws them (`crate::button` and `crate::switch` pick it from these).
        glass_ui::set_on(t.glass);
        glass_ui::set_light(!t.dark);
        glass_ui::set_look(t.look);
        crate::glass::begin_build(window);
        crate::glass::set_look(t.look);
        crate::glass::set_light(!t.dark);
        self.sky.free_replaced(window);
        // The launcher's own backdrop: the redesign's scene in the dark look, tinted by the
        // player's accent as the launcher tints it, and the dawn sky in the light one (the
        // redesign has no light scene yet). The setup therefore looks like the client it
        // installs: a player with a blue accent gets the blue scene, not the night sunset.
        let tint = (t.dark && t.look.accent != horizon_theme::glass::ACCENT)
            .then(|| horizon_theme::glass::mix_oklab(t.look.accent, 0x767676, 0.58));
        self.scene
            .update(cx, |scene, cx| scene.set_look(tint, t.look.blur, cx));
        let sky = if t.dark {
            self.scene.clone().into_any_element()
        } else {
            let (sky, next) = self.sky.render(
                &t.night,
                (viewport.width.into(), viewport.height.into()),
                window.scale_factor(),
                window.is_window_active(),
                Instant::now(),
            );
            if let Some(next) = next {
                self.wake_sky(next, cx);
            }
            sky.into_any_element()
        };
        let card = self.card(cx);
        div()
            .flex()
            .flex_col()
            .relative()
            .size_full()
            .bg(t.side)
            .child(sky)
            .children(titlebar::render(&t, window))
            .child(
                div()
                    .flex()
                    .flex_1()
                    .min_h_0()
                    .items_center()
                    .justify_center()
                    .child(card),
            )
            .children(titlebar::resize_handles(window))
    }
}
