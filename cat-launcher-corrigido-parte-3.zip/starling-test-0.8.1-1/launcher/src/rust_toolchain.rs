//! A portable Rust toolchain of the launcher's own, for native mods (docs/modding/src/how-to/native-mods.md), which
//! compile the game. levzzz5154 (2026-10-27): players combine many native mods per build, so they
//! build on their own computer, and the launcher brings the compiler.
//!
//! It downloads only the official Rust components a build needs (`rustc`, `cargo`, `rust-std`, and
//! on Windows `rust-mingw`) from static.rust-lang.org, each pinned by its SHA-256 below, and
//! unpacks them into the launcher's data folder. No rustup or player-installed compiler is used.
//! Windows also gets a pinned C/link toolchain: WinLibs for x64 and LLVM-MinGW for ARM64.
use crate::backend;
use std::fs;
use std::io::Read;
use std::path::{Path, PathBuf};
use std::process::Command;

/// The Rust release native mods build with: the stable release when it was pinned (CI builds the
/// game on stable; horizon-mixins needs 1.95 or newer).
pub const VERSION: &str = "1.99.1";
const DIST: &str = "https://static.rust-lang.org/dist/2026-10-15";

/// One platform's components: (name, SHA-256, compressed bytes) of `<name>-<VERSION>-<target>.tar.gz`.
#[derive(Debug, PartialEq)]
pub struct Host {
    pub target: &'static str,
    components: &'static [(&'static str, &'static str, u64)],
    /// The C and link toolchain it brings besides Rust's components.
    c_toolchain: Option<&'static CToolchain>,
}

/// A Windows C/link toolchain archive, pinned by its SHA-256 and byte length.
#[derive(Debug, PartialEq)]
pub struct CToolchain {
    pub version: &'static str,
    url: &'static str,
    sha256: &'static str,
    bytes: u64,
    directory: &'static str,
    kind: CToolchainKind,
}

#[derive(Clone, Copy, Debug, PartialEq)]
enum CToolchainKind {
    WinLibs,
    LlvmMingw,
}

/// WinLibs' build of GCC and binutils on MinGW-w64 (MSVCRT, the C runtime `rust-mingw` links
/// against; POSIX threads; SEH), the release's `mingw64/` folder without its documentation.
pub const MINGW: CToolchain = CToolchain {
    version: "GCC 16.2.0, MinGW-w64 14.0.0 (WinLibs r3)",
    url: "https://github.com/brechtsanders/winlibs_mingw/releases/download/16.2.0posix-23.1.3-14.0.0-msvcrt-r3/winlibs-x86_64-posix-seh-gcc-16.2.0-mingw-w64msvcrt-14.0.0-r3.zip",
    sha256: "62af32ea58acdea1318ea5dd8eb7017eaee694dd40b269d52a59c769dcfefb82",
    bytes: 277203392,
    directory: MINGW_DIR,
    kind: CToolchainKind::WinLibs,
};

/// LLVM-MinGW 20261104, with UCRT and native ARM64 host tools. It targets ARM64 Windows using
/// LLVM's GNU-compatible ABI; it is not an MSVC object/library toolchain.
pub const LLVM_MINGW: CToolchain = CToolchain {
    version: "LLVM-MinGW 23.1.5 (20261104, UCRT)",
    url: "https://github.com/mstorsjo/llvm-mingw/releases/download/20261104/llvm-mingw-20261104-ucrt-aarch64.zip",
    sha256: "7d7f8387a8706639b0b47a629d6e23f8b3ef9acce67e9832b8cd4c5bb2816eab",
    bytes: 186164073,
    directory: LLVM_MINGW_DIR,
    kind: CToolchainKind::LlvmMingw,
};
/// Where MinGW-w64 goes in the toolchain, as the zip names it.
const MINGW_DIR: &str = "mingw64";
const LLVM_MINGW_DIR: &str = "llvm-mingw";

pub const WINDOWS_X64_TARGET: &str = "x86_64-pc-windows-gnu";
pub const WINDOWS_ARM64_TARGET: &str = "aarch64-pc-windows-gnullvm";
pub const WINDOWS_X64_MACHINE: u16 = 0x8664;
pub const WINDOWS_ARM64_MACHINE: u16 = 0xaa64;

const HOSTS: &[Host] = &[
    Host {
        target: "aarch64-apple-darwin",
        components: &[
            (
                "rustc",
                "cc998c1dc8df006106472357aa87838b2da3f7b25446b98a94cfd58796cb0610",
                85305190,
            ),
            (
                "cargo",
                "b5cc7634f919949c3e5e131123f813416dc47f6b809a5371d12f1f593595ae13",
                13082476,
            ),
            (
                "rust-std",
                "c124006d63885ba1029aca49efd59e93be6b2b171c379318ff94a00ef5eba664",
                48506029,
            ),
        ],
        c_toolchain: None,
    },
    // Intel Macs (#1161): the same system linker (Command Line Tools) as Apple Silicon.
    Host {
        target: "x86_64-apple-darwin",
        components: &[
            (
                "rustc",
                "dad7c1300549bc846e1f02652fa11d131b86cdbb8288d64da5f62b4504d62a8f",
                104855037,
            ),
            (
                "cargo",
                "ed05dab7a703d1b4c6fa5cec8e99272cb1c3902a323986c80e0bc57915c85ddd",
                13439668,
            ),
            (
                "rust-std",
                "5cc4606fdd6c9226be51f59a333942cc8a203e74f7da38d47aaaf44b986bfe3c",
                48891033,
            ),
        ],
        c_toolchain: None,
    },
    Host {
        target: "x86_64-unknown-linux-gnu",
        components: &[
            (
                "rustc",
                "85e7c0e6f21636f714e2a42966011364a6cc56b6548126d32144d6ba90904966",
                141445153,
            ),
            (
                "cargo",
                "47babc028247e26577f8a1bf390b11f447ad9b7ab93f5c9a0dda078935fc149b",
                14520879,
            ),
            (
                "rust-std",
                "d1290c05994a59c029e562cb75be1bddc6fb11a4c501e1b7b0f61d119c6cbb12",
                50361623,
            ),
        ],
        c_toolchain: None,
    },
    Host {
        target: WINDOWS_X64_TARGET,
        components: &[
            (
                "rustc",
                "43b17e9a9134ea72562bfbb23728a830f671ea9be1db6a72597a8d240e986b35",
                161274138,
            ),
            (
                "cargo",
                "57e54617be4420dbb967ca8293f5ace7168104ac12efa9dc7c5c3bda112f8b36",
                18659998,
            ),
            (
                "rust-std",
                "6546651238a3ac092b763511be524ca6eda6103e5d47342416923be1b3ce837c",
                44957351,
            ),
            (
                "rust-mingw",
                "30263d7bb4fd0bf63a153afe36d7fc102f929a7d42781651c6b3a03a414ba428",
                9594887,
            ),
        ],
        c_toolchain: Some(&MINGW),
    },
    Host {
        target: WINDOWS_ARM64_TARGET,
        components: &[
            (
                "rustc",
                "261a6bff00129905f97e07db33aaecb994d22ab40efef2b6b1e27b8cc37231a8",
                140086017,
            ),
            (
                "cargo",
                "a678122654b6ca4240997cec6ab6e3c91fa0e79466939c06b079c8a717efc6aa",
                14008619,
            ),
            (
                "rust-std",
                "a492480db6ba615c70a10c8c146012d04276122cd57d00aef225764e0791968f",
                45343615,
            ),
            (
                "rust-mingw",
                "69fe700a14751b7b5a191bab92a9620e4deb4095f232873476033d1a6a5d8cd7",
                870178,
            ),
        ],
        c_toolchain: Some(&LLVM_MINGW),
    },
];

impl Host {
    /// Exact compressed bytes downloaded for this pinned compiler and its linker.
    pub fn download_bytes(&self) -> u64 {
        self.components
            .iter()
            .map(|(_, _, bytes)| bytes)
            .sum::<u64>()
            + self.c_toolchain.map_or(0, |compiler| compiler.bytes)
    }
}

/// This computer's host, if the launcher ships a toolchain for it.
fn host_for(os: &str, arch: &str) -> Option<&'static Host> {
    let target = match (os, arch) {
        ("macos", "aarch64") => "aarch64-apple-darwin",
        ("macos", "x86_64") => "x86_64-apple-darwin",
        ("linux", "x86_64") => "x86_64-unknown-linux-gnu",
        ("windows", "x86_64") => WINDOWS_X64_TARGET,
        ("windows", "aarch64") => WINDOWS_ARM64_TARGET,
        _ => return None,
    };
    HOSTS.iter().find(|h| h.target == target)
}

/// Every supported host, shared by cache-name parsing and cross-platform command tests.
pub(crate) fn hosts() -> &'static [Host] {
    HOSTS
}

pub fn host() -> Option<&'static Host> {
    host_for(std::env::consts::OS, std::env::consts::ARCH)
}

/// The Rust target for an installed Windows game's PE machine type.
pub fn windows_target_for_machine(machine: u16) -> Option<&'static str> {
    match machine {
        WINDOWS_X64_MACHINE => Some(WINDOWS_X64_TARGET),
        WINDOWS_ARM64_MACHINE => Some(WINDOWS_ARM64_TARGET),
        _ => None,
    }
}

/// Native-mod builds are supported when the selected game's architecture matches the launcher.
pub fn windows_target_for_host(host_target: &str, machine: u16) -> Option<&'static str> {
    let target = windows_target_for_machine(machine)?;
    (target == host_target).then_some(target)
}

fn exe(name: &str) -> String {
    format!("{name}{}", std::env::consts::EXE_SUFFIX)
}

/// An unpacked toolchain.
#[derive(Clone, Debug, PartialEq)]
pub struct Toolchain {
    pub dir: PathBuf,
    pub(crate) host: &'static Host,
}

impl Toolchain {
    pub fn cargo(&self) -> PathBuf {
        self.dir.join("bin").join(exe("cargo"))
    }

    pub fn rustc(&self) -> PathBuf {
        self.dir.join("bin").join(exe("rustc"))
    }

    /// Where Rust's own libraries for this computer are: the standard library a dynamically
    /// linked program loads (the prebuilt game's).
    pub fn target_libdir(&self) -> Option<PathBuf> {
        Some(
            self.dir
                .join("lib")
                .join("rustlib")
                .join(self.host.target)
                .join("lib"),
        )
    }

    /// MinGW-w64's programs (gcc, as, dlltool), when the toolchain brings it (Windows).
    pub fn mingw_bin(&self) -> PathBuf {
        self.host
            .c_toolchain
            .map_or_else(|| self.dir.join(MINGW_DIR), |c| self.dir.join(c.directory))
            .join("bin")
    }

    fn compiler_available(&self) -> bool {
        let Some(compiler) = self.host.c_toolchain else {
            return true;
        };
        match compiler.kind {
            CToolchainKind::WinLibs => self.mingw_bin().join(exe("gcc")).is_file(),
            CToolchainKind::LlvmMingw => [
                exe("aarch64-w64-mingw32-clang"),
                exe("aarch64-w64-mingw32-clang++"),
                exe("llvm-ar"),
                exe("llvm-ranlib"),
                exe("llvm-dlltool"),
                // winresource defaults to an unprefixed x64 `windres` on a native ARM64 host.
                // Give it the target-specific resource compiler and archive tool too.
                exe("aarch64-w64-mingw32-ar"),
                exe("aarch64-w64-mingw32-windres"),
            ]
            .iter()
            .all(|program| self.mingw_bin().join(program).is_file()),
        }
    }

    /// `program` (this toolchain's cargo, or a tool built with it) set up to use only this
    /// toolchain: its rustc, its C/link tools where it has them, the launcher's Cargo home, and none of
    /// the player's rustup, compiler-wrapper or compiler-flag settings ([`scrubbed`]). On Windows it
    /// opens no console window: cargo is a console program, and the launcher has none to share, so
    /// each build showed an empty one for as long as it ran (#4770).
    pub fn command(&self, program: &Path) -> Command {
        let mut cmd = crate::process::command(program);
        let path = std::env::var_os("PATH").unwrap_or_default();
        let mingw = self.host.c_toolchain.map(|_| self.mingw_bin());
        let paths = std::iter::once(self.dir.join("bin"))
            .chain(mingw)
            .chain(std::env::split_paths(&path));
        if let Some(root) = outside_configs() {
            cmd.current_dir(root);
        }
        cmd.env("PATH", std::env::join_paths(paths).unwrap_or(path))
            .env("RUSTC", self.rustc())
            .env("CARGO_HOME", cargo_home());
        // gcc, as, ld — and `cargo install`'s build — put scratch files in the temp dir,
        // which has to be a path they can open too: the build's own, never the player's
        // (#5189: a Cyrillic user name makes the player's unreadable by MinGW-w64).
        let tmp = backend::build_dir().join("tmp");
        if fs::create_dir_all(&tmp).is_ok() {
            cmd.env("TMPDIR", &tmp).env("TMP", &tmp).env("TEMP", &tmp);
        }
        for name in SCRUBBED {
            cmd.env_remove(name);
        }
        for (name, _) in std::env::vars_os() {
            if name.to_str().is_some_and(scrubbed) {
                cmd.env_remove(name);
            }
        }
        // These are the launcher's own settings, so add them after removing the player's Cargo
        // target overrides. The ARM64 target's linker is LLVM-MinGW's Clang driver; Rust and cc
        // must both see tools from this managed toolchain.
        if self.host.target == WINDOWS_ARM64_TARGET {
            let bin = self.mingw_bin();
            let cc = bin.join(exe("aarch64-w64-mingw32-clang"));
            let cxx = bin.join(exe("aarch64-w64-mingw32-clang++"));
            let ar = bin.join(exe("llvm-ar"));
            let ranlib = bin.join(exe("llvm-ranlib"));
            let resource_ar = bin.join(exe("aarch64-w64-mingw32-ar"));
            let windres = bin.join(exe("aarch64-w64-mingw32-windres"));
            cmd.env("CC_aarch64_pc_windows_gnullvm", &cc)
                .env("CXX_aarch64_pc_windows_gnullvm", &cxx)
                .env("AR_aarch64_pc_windows_gnullvm", &ar)
                .env("RANLIB_aarch64_pc_windows_gnullvm", &ranlib)
                .env("AR", resource_ar)
                .env("WINDRES", windres)
                .env("CARGO_TARGET_AARCH64_PC_WINDOWS_GNULLVM_LINKER", cc);
        }
        cmd
    }

    /// Adds the ARM64-specific Rust flags Cargo needs for Windows imports and a self-contained
    /// unwind runtime. A Cargo config value keeps paths with spaces intact.
    pub fn configure_cargo(&self, cmd: &mut Command) {
        if self.host.target != WINDOWS_ARM64_TARGET {
            return;
        }
        let dlltool = self.mingw_bin().join(exe("llvm-dlltool"));
        let rustflags = toml::Value::Array(vec![
            toml::Value::String("-C".into()),
            // Windows doesn't ship LLVM-MinGW's libunwind.dll. On this target, crt-static also
            // makes Rust use the static unwinder so the built game has no extra runtime DLL.
            toml::Value::String("target-feature=+crt-static".into()),
            toml::Value::String("-C".into()),
            toml::Value::String(format!("dlltool={}", dlltool.display())),
        ]);
        cmd.arg("--config").arg(format!(
            "target.{WINDOWS_ARM64_TARGET}.rustflags={rustflags}"
        ));
    }

    /// `rustc --version`, once the toolchain answers.
    pub fn version(&self) -> Result<String, String> {
        let out = self
            .command(&self.rustc())
            .arg("--version")
            .output()
            .map_err(|e| format!("Rust {VERSION} doesn't start: {e}"))?;
        if !out.status.success() {
            return Err(format!(
                "Rust {VERSION} doesn't start: {}",
                String::from_utf8_lossy(&out.stderr).trim()
            ));
        }
        Ok(String::from_utf8_lossy(&out.stdout).trim().to_owned())
    }
}

/// Whether the player's environment variable `name` stays out of a build: it would pick another
/// Rust or wrap it (rustup, `RUSTC_WRAPPER`), or change the compiler's flags (`RUSTFLAGS`, a
/// profile, incremental, the build's target or linker: `CARGO_BUILD_*` but the jobs,
/// `CARGO_TARGET_*`),
/// so the build would differ from the release's and recompile everything after any change.
pub fn scrubbed(name: &str) -> bool {
    const PREFIXES: [&str; 3] = ["CARGO_PROFILE_", "CARGO_BUILD_", "CARGO_TARGET_"];
    // Windows' variable names ignore case.
    let name = name.to_ascii_uppercase();
    // The number of jobs changes no flag: a player may still limit it.
    if name == "CARGO_BUILD_JOBS" {
        return false;
    }
    SCRUBBED.contains(&name.as_str()) || PREFIXES.iter().any(|p| name.starts_with(p))
}

/// `ioprio_set`'s "which" for one process.
#[cfg(target_os = "linux")]
const IOPRIO_WHO_PROCESS: libc::c_long = 1;
/// The best-effort I/O class (2) at its lowest level (7), as `ioprio_set` takes it.
#[cfg(target_os = "linux")]
const LOW_IO: libc::c_long = (2 << 13) | 7;

/// Runs `cmd` (a build) below the player's own programs, so the desktop and a game in play stay
/// smooth while it compiles; with the computer otherwise idle it still gets every core. Unix: nice
/// 19, and on Linux the lowest best-effort I/O level (not the idle class, which gets the disk only
/// when nothing else uses it, so a game streaming chunks could stall a build);
/// Windows: below-normal priority, keeping [`crate::process::hide_console`]'s no-console flag
/// (`creation_flags` sets the whole value, so this sets both).
pub fn low_priority(cmd: &mut Command) -> &mut Command {
    #[cfg(unix)]
    {
        use std::os::unix::process::CommandExt;
        // SAFETY: between fork and exec the closure only makes two system calls, which are
        // async-signal-safe, on the child itself; a failure (not allowed) leaves the priority.
        unsafe {
            cmd.pre_exec(|| {
                libc::setpriority(libc::PRIO_PROCESS, 0, 19);
                #[cfg(target_os = "linux")]
                {
                    libc::syscall(
                        libc::SYS_ioprio_set,
                        IOPRIO_WHO_PROCESS,
                        0 as libc::c_long,
                        LOW_IO,
                    );
                }
                Ok(())
            });
        }
    }
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        const BELOW_NORMAL_PRIORITY_CLASS: u32 = 0x0000_4000;
        cmd.creation_flags(crate::process::CREATE_NO_WINDOW | BELOW_NORMAL_PRIORITY_CLASS);
    }
    cmd
}

const SCRUBBED: [&str; 8] = [
    "RUSTUP_TOOLCHAIN",
    "RUSTC_WRAPPER",
    "RUSTC_WORKSPACE_WRAPPER",
    "RUSTFLAGS",
    "CARGO_ENCODED_RUSTFLAGS",
    "RUSTDOCFLAGS",
    "CARGO_ENCODED_RUSTDOCFLAGS",
    "CARGO_INCREMENTAL",
];

/// Where commands run so that no player's Cargo configuration reaches them: the filesystem root
/// above the launcher's data (`/` on Unix, whatever mount the data is on; the drive's root on
/// Windows). Cargo reads `.cargo/config.toml` in the folder it starts in and in
/// every folder above it, so from a folder under the player's home it would read
/// `~/.cargo/config.toml` even with another `CARGO_HOME`: its `[profile]`, `[build]` and
/// `[target]` settings (rustflags, linker, incremental) beat both the workspace's profile and
/// the environment, and no command-line switch turns that search off. A build names its workspace
/// with `--manifest-path` instead.
pub fn outside_configs() -> Option<PathBuf> {
    let data = backend::build_dir();
    data.ancestors()
        .last()
        .filter(|root| root.has_root())
        .map(Path::to_path_buf)
}

/// Where toolchains live: `<build dir>/rust/` ([`backend::build_dir`] — a path the tools can
/// read, which the data folder's isn't on Windows with a non-ASCII user name, #5189).
pub fn root() -> PathBuf {
    backend::build_dir().join("rust")
}

/// The Cargo home of native builds (downloaded crates, horizon-mixins), never the player's own.
pub fn cargo_home() -> PathBuf {
    backend::build_dir().join("cargo")
}

fn dir_for(host: &Host) -> PathBuf {
    root().join(format!("{VERSION}-{}", host.target))
}

const COMPLETE: &str = ".installed";

/// The toolchain, when it is installed. An incomplete Windows C/link toolchain is reinstalled.
pub fn installed() -> Option<Toolchain> {
    let host = host()?;
    let toolchain = Toolchain {
        dir: dir_for(host),
        host,
    };
    (toolchain.dir.join(COMPLETE).is_file() && toolchain.compiler_available()).then_some(toolchain)
}

// Check the byte after the pinned prefix before the shared writer can commit it.
struct PinnedArchive<R>(std::io::Take<R>);
impl<R: Read> Read for PinnedArchive<R> {
    fn read(&mut self, buffer: &mut [u8]) -> std::io::Result<usize> {
        if buffer.is_empty() {
            return Ok(0);
        }
        let n = self.0.read(buffer)?;
        if n == 0 && self.0.limit() == 0 && self.0.get_mut().read(&mut [0])? != 0 {
            return Err(std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                crate::i18n::tr("Rust toolchain archive exceeds its pinned size."),
            ));
        }
        Ok(n)
    }
}

fn download_archive(
    url: &str,
    bytes: u64,
    sha256: &str,
    to: &Path,
    progress: &impl Fn(f32),
) -> Result<(), String> {
    save_archive(
        backend::get(url)?.into_reader(),
        url,
        bytes,
        sha256,
        to,
        progress,
    )
}

fn save_archive(
    reader: impl Read,
    name: &str,
    bytes: u64,
    sha256: &str,
    to: &Path,
    progress: &impl Fn(f32),
) -> Result<(), String> {
    backend::save_checked(
        PinnedArchive(reader.take(bytes)),
        bytes,
        name,
        sha256,
        to,
        progress,
    )?;
    let actual = fs::metadata(to).map_err(|error| error.to_string())?.len();
    if actual != bytes {
        let _ = fs::remove_file(to);
        return Err(crate::i18n::trf(
            "Rust toolchain archive has {actual} bytes; expected {expected}.",
            &[
                ("actual", &actual.to_string()),
                ("expected", &bytes.to_string()),
            ],
        ));
    }
    Ok(())
}

/// Downloads, checks and unpacks the pinned toolchain (once); `progress` gets the fraction done.
pub fn install(progress: impl Fn(f32)) -> Result<Toolchain, String> {
    if let Some(done) = installed() {
        return Ok(done);
    }
    let host = host().ok_or_else(|| {
        if cfg!(all(target_os = "windows", target_arch = "aarch64")) {
            crate::i18n::tr("Native mods are not supported by the Windows ARM64 launcher yet; its managed compiler is not available.")
                .to_string()
        } else {
            format!(
                "Native mods need Rust, and the launcher has none for {} {}.",
                std::env::consts::OS,
                std::env::consts::ARCH
            )
        }
    })?;
    let dir = dir_for(host);
    let partial = root().join(format!(".{VERSION}-{}.partial", host.target));
    let _ = fs::remove_dir_all(&partial);
    fs::create_dir_all(&partial).map_err(|e| e.to_string())?;
    let count = (host.components.len() + usize::from(host.c_toolchain.is_some())) as f32;
    for (i, &(name, sha256, bytes)) in host.components.iter().enumerate() {
        let file = format!("{name}-{VERSION}-{}.tar.gz", host.target);
        let archive = root().join(format!(".{file}"));
        let step = |f: f32| progress((i as f32 + f) / count);
        download_archive(&format!("{DIST}/{file}"), bytes, sha256, &archive, &step)
            .map_err(|e| format!("Rust {VERSION} ({name}): {e}"))?;
        let unpacked = unpack(&archive, &partial);
        let _ = fs::remove_file(&archive);
        unpacked.map_err(|e| format!("Rust {VERSION} ({name}): {e}"))?;
    }
    if let Some(compiler) = host.c_toolchain {
        let archive = root().join(format!(".{}.zip", compiler.directory));
        let done = host.components.len() as f32;
        let step = |f: f32| progress((done + f) / count);
        download_archive(
            compiler.url,
            compiler.bytes,
            compiler.sha256,
            &archive,
            &step,
        )
        .map_err(|e| format!("{}: {e}", compiler.version))?;
        let unpacked = match compiler.kind {
            CToolchainKind::WinLibs => unpack_mingw(&archive, &partial),
            CToolchainKind::LlvmMingw => unpack_llvm_mingw(&archive, &partial),
        };
        let _ = fs::remove_file(&archive);
        unpacked.map_err(|e| format!("{}: {e}", compiler.version))?;
        let toolchain = Toolchain {
            dir: partial.clone(),
            host,
        };
        if !toolchain.compiler_available() {
            return Err(format!(
                "{} did not contain the compiler and linker files the launcher needs.",
                compiler.version
            ));
        }
    }
    fs::write(partial.join(COMPLETE), VERSION).map_err(|e| e.to_string())?;
    let _ = fs::remove_dir_all(&dir);
    fs::rename(&partial, &dir).map_err(|e| e.to_string())?;
    progress(1.0);
    Ok(Toolchain { dir, host })
}

/// Unpacks one component archive into `prefix`, as its installer would: an archive holds
/// `<top>/<component>/<files>` per component, and each component's files go under `prefix`. Its
/// installer script, lists and `manifest.in` stay out.
fn unpack(archive: &Path, prefix: &Path) -> Result<(), String> {
    let file = fs::File::open(archive).map_err(|e| e.to_string())?;
    let mut tar = tar::Archive::new(flate2::read::GzDecoder::new(file));
    for entry in tar.entries().map_err(|e| e.to_string())? {
        let mut entry = entry.map_err(|e| e.to_string())?;
        let path = entry.path().map_err(|e| e.to_string())?.into_owned();
        let Some(relative) = component_path(&path) else {
            continue;
        };
        let to = prefix.join(&relative);
        if let Some(parent) = to.parent() {
            fs::create_dir_all(parent).map_err(|e| e.to_string())?;
        }
        entry
            .unpack(&to)
            .map_err(|e| format!("{}: {e}", relative.display()))?;
    }
    Ok(())
}

/// Where a file of a component archive goes, relative to the prefix: `rustc-1.99.1-x/rustc/bin/rustc`
/// → `bin/rustc`. None for the archive's own files and anything that would leave the prefix.
fn component_path(path: &Path) -> Option<PathBuf> {
    use std::path::Component;
    let parts: Vec<&std::ffi::OsStr> = path
        .components()
        .map(|c| match c {
            Component::Normal(name) => Some(name),
            _ => None,
        })
        .collect::<Option<_>>()?;
    match parts.as_slice() {
        [_, _, rest @ ..] if !rest.is_empty() && rest != ["manifest.in"] => {
            Some(rest.iter().collect())
        }
        _ => None,
    }
}

/// Unpacks MinGW-w64's zip into `prefix`: its `mingw64/` folder, documentation left out.
fn unpack_mingw(archive: &Path, prefix: &Path) -> Result<(), String> {
    let file = fs::File::open(archive).map_err(|e| e.to_string())?;
    let mut zip = zip::ZipArchive::new(file).map_err(|e| e.to_string())?;
    for i in 0..zip.len() {
        let mut entry = zip.by_index(i).map_err(|e| e.to_string())?;
        let Some(relative) = entry.enclosed_name().and_then(|p| mingw_path(&p)) else {
            continue;
        };
        let to = prefix.join(&relative);
        if entry.is_dir() {
            fs::create_dir_all(&to).map_err(|e| e.to_string())?;
            continue;
        }
        if let Some(parent) = to.parent() {
            fs::create_dir_all(parent).map_err(|e| e.to_string())?;
        }
        let mut out = fs::File::create(&to).map_err(|e| format!("{}: {e}", relative.display()))?;
        std::io::copy(&mut entry, &mut out).map_err(|e| format!("{}: {e}", relative.display()))?;
    }
    Ok(())
}

/// Unpacks LLVM-MinGW under `llvm-mingw/`. Release archives have either a versioned top folder or
/// the toolchain folders at their root; both layouts are accepted, but paths may never escape it.
fn unpack_llvm_mingw(archive: &Path, prefix: &Path) -> Result<(), String> {
    let file = fs::File::open(archive).map_err(|e| e.to_string())?;
    let mut zip = zip::ZipArchive::new(file).map_err(|e| e.to_string())?;
    for i in 0..zip.len() {
        let mut entry = zip.by_index(i).map_err(|e| e.to_string())?;
        let Some(relative) = entry.enclosed_name().and_then(|p| llvm_mingw_path(&p)) else {
            continue;
        };
        let to = prefix.join(LLVM_MINGW_DIR).join(&relative);
        if entry.is_dir() {
            fs::create_dir_all(&to).map_err(|e| e.to_string())?;
            continue;
        }
        if let Some(parent) = to.parent() {
            fs::create_dir_all(parent).map_err(|e| e.to_string())?;
        }
        let mut out = fs::File::create(&to).map_err(|e| format!("{}: {e}", relative.display()))?;
        std::io::copy(&mut entry, &mut out).map_err(|e| format!("{}: {e}", relative.display()))?;
    }
    Ok(())
}

fn llvm_mingw_path(path: &Path) -> Option<PathBuf> {
    use std::path::Component;
    let parts: Vec<&std::ffi::OsStr> = path
        .components()
        .map(|c| match c {
            Component::Normal(name) => Some(name),
            _ => None,
        })
        .collect::<Option<_>>()?;
    if parts.is_empty() {
        return None;
    }
    let contents = if parts[0].to_string_lossy().starts_with("llvm-mingw") {
        if parts.len() == 1 {
            return None;
        }
        &parts[1..]
    } else {
        &parts[..]
    };
    (!contents.is_empty()).then(|| contents.iter().collect())
}

/// Where a file of MinGW-w64's zip goes, relative to the prefix: `mingw64/bin/gcc.exe` as it is.
/// None for its documentation (`mingw64/share/`, 50 MB of the 925), the folder itself and anything
/// outside `mingw64/`.
fn mingw_path(path: &Path) -> Option<PathBuf> {
    use std::path::Component;
    let parts: Vec<&std::ffi::OsStr> = path
        .components()
        .map(|c| match c {
            Component::Normal(name) => Some(name),
            _ => None,
        })
        .collect::<Option<_>>()?;
    match parts.as_slice() {
        [top, first, ..] if *top == MINGW_DIR && *first != "share" => Some(parts.iter().collect()),
        _ => None,
    }
}

/// Whether this computer has what a build needs besides the toolchain. Rust brings its compiler,
/// but uses the system's linker on macOS (the Command Line Tools) and Linux (`cc`). On Linux the
/// game also builds against the system's sound and controller libraries ([`linux_needs`]).
/// Windows' `windows-gnu` toolchain brings its own linker, and MinGW-w64 for C and import
/// libraries ([`MINGW`]).
pub fn linker() -> Result<(), String> {
    link(true)
}

/// The headless build's ([`crate::native_mods::build_server`]): the same check, minus what only
/// the game links. A server build compiles without the default features, so it links none of
/// the system's sound or controller libraries and needs no pkg-config to find them: only a C
/// compiler and the C library's headers.
pub fn linker_server() -> Result<(), String> {
    link(false)
}

fn link(full: bool) -> Result<(), String> {
    let ok = |program: &str, args: &[&str]| {
        Command::new(program)
            .args(args)
            .output()
            .is_ok_and(|o| o.status.success())
    };
    match std::env::consts::OS {
        // `xcode-select -p` only says where they are; running `cc` without them would open
        // Apple's install dialog by surprise.
        "macos" if !ok("xcode-select", &["-p"]) => Err(
            "Native mods need Apple's Command Line Tools to link the game. Run `xcode-select --install` in Terminal, then build again."
                .into(),
        ),
        "linux" => linux_needs(
            ok,
            &fs::read_to_string("/etc/os-release").unwrap_or_default(),
            full,
        ),
        _ => Ok(()),
    }
}

/// What to do when Windows' Smart App Control refused one of the build's programs (#5911). It
/// lets only signed programs or ones Microsoft knows run, and a build runs programs it has just
/// compiled (every crate's build script, horizon-mixins, the game) and the toolchain's own
/// (`dlltool.exe`). Windows refuses them with os error 4551 ("An Application Control policy has
/// blocked this file"). Nothing is checked before the build: with Smart App Control on, a build
/// whose programs already ran before it was turned on still succeeds.
pub fn smart_app_control() -> String {
    crate::i18n::tr("Windows' Smart App Control is blocking the build (os error 4551). \
It only lets signed programs run, and a native build runs programs no one has signed: the ones it \
compiles on this computer and some of the compiler's own. To build native mods, turn it off in \
Windows Security > App & browser control > Smart App Control settings, then build again. On some \
Windows versions it can't be turned back on without reinstalling Windows. Content mods (.hmod) need \
no build and work with it on.")
    .to_string()
}

/// Whether `text` (a build's output, or the error starting one of its programs) is Windows
/// refusing a program under an Application Control policy, Smart App Control's.
pub fn blocked_by_app_control(text: &str) -> bool {
    text.contains("os error 4551")
}

/// What a Linux build needs from the system, checked before anything is downloaded: a C compiler
/// (the linker; `ring` and `hidapi` compile C) with the C library's headers and, for the game
/// only (`full`), `pkg-config` and the development files of ALSA (`alsa-sys`, sound) and
/// libudev (`libudev-sys` and `hidapi`, controllers), which those crates look up with it. The
/// headless server build links none of those (`--no-default-features`, docs/server.md).
/// Desktop distributions ship the libraries but not these files, and SteamOS has GCC without
/// the C library's headers (`stdint.h` not found in `ring`, #4770), so a build without them
/// failed after starting. `ok` runs a check; `os` is `/etc/os-release`, which picks the install
/// command.
fn linux_needs(ok: impl Fn(&str, &[&str]) -> bool, os: &str, full: bool) -> Result<(), String> {
    let cc = ok("cc", &["--version"]);
    // GCC's and Clang's own `stdint.h` include the C library's.
    let headers = [
        "-fsyntax-only",
        "-x",
        "c",
        "-include",
        "stdint.h",
        "/dev/null",
    ];
    let mut missing: Vec<&str> = [
        (cc, "a C compiler (cc)"),
        (!cc || ok("cc", &headers), "the C library's headers"),
    ]
    .into_iter()
    .filter(|(found, _)| !found)
    .map(|(_, what)| what)
    .collect();
    if full {
        let pkg_config = ok("pkg-config", &["--version"]);
        let has = |name: &str| pkg_config && ok("pkg-config", &["--exists", name]);
        missing.extend(
            [
                (pkg_config, "pkg-config"),
                (has("alsa"), "ALSA's development files"),
                (has("libudev"), "libudev's development files"),
            ]
            .into_iter()
            .filter(|(found, _)| !found)
            .map(|(_, what)| what),
        );
    }
    if missing.is_empty() {
        return Ok(());
    }
    let field = |name: &str| {
        os.lines()
            .find_map(|l| l.strip_prefix(name)?.strip_prefix('='))
            .map(|v| v.trim_matches('"').to_owned())
            .unwrap_or_default()
    };
    let (id, like) = (field("ID"), field("ID_LIKE"));
    let family = |names: &[&str]| {
        std::iter::once(id.as_str())
            .chain(like.split_whitespace())
            .any(|n| names.contains(&n))
    };
    let apt = if full {
        "sudo apt install build-essential pkg-config libasound2-dev libudev-dev"
    } else {
        "sudo apt install build-essential"
    };
    let command = if family(&["debian", "ubuntu"]) {
        Some(apt)
    } else if family(&["fedora", "rhel"]) {
        Some(if full {
            "sudo dnf install gcc pkgconf-pkg-config alsa-lib-devel systemd-devel"
        } else {
            "sudo dnf install gcc glibc-devel"
        })
    } else if family(&["arch"]) && id != "steamos" {
        Some(if full {
            "sudo pacman -S --needed base-devel alsa-lib systemd-libs"
        } else {
            "sudo pacman -S --needed base-devel"
        })
    } else if family(&["suse", "opensuse"]) {
        Some(if full {
            "sudo zypper install gcc pkg-config alsa-devel libudev-devel"
        } else {
            "sudo zypper install gcc glibc-devel"
        })
    } else {
        None
    };
    // NixOS keeps every package in the store, where pkg-config finds them only inside a shell that
    // lists them (`nix-shell`, or `nix develop`); installing them in `environment.systemPackages`
    // changes nothing for a build started from the desktop (#5248). Its shell is the launcher's
    // `shell.nix`, so point at that rather than at a package manager that would not help.
    let how = match command {
        _ if id == "nixos" => {
            "On NixOS they are only visible inside a shell that provides them: run `nix-shell` in the launcher's folder (its shell.nix has these packages), then build again."
                .to_owned()
        }
        _ if id == "steamos" => "SteamOS ships without them and its system is read-only, so native mods can't be built on it yet.".to_owned(),
        Some(command) => format!("Install them in a terminal, then build again:\n{command}"),
        None => format!("Install them with your distribution's package manager, then build again (on Debian, Ubuntu or Mint: {apt})."),
    };
    Err(format!(
        "Native mods need these to build the game on Linux, and this computer lacks them: {}. {how}",
        missing.join(", ")
    ))
}

/// Removes every toolchain, the native builds' Cargo home and their scratch folder.
pub fn remove() -> Result<(), String> {
    for dir in [root(), cargo_home(), backend::build_dir().join("tmp")] {
        if dir.exists() {
            fs::remove_dir_all(&dir).map_err(|e| format!("{}: {e}", dir.display()))?;
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    #[test]
    fn archive_download_checks_pinned_length_as_well_as_hash() {
        let directory = tempfile::tempdir().unwrap();
        let archive = directory.path().join("archive");
        let mut oversized = vec![b'x'; 1 << 20];
        oversized[..4].copy_from_slice(b"rust");
        for (body, bytes, accepted) in [
            (b"rust".to_vec(), 4, true),
            (b"rust".to_vec(), 5, false),
            (oversized, 4, false),
            (b"oops".to_vec(), 4, false),
        ] {
            let mut reader = std::io::Cursor::new(body);
            let result = save_archive(
                &mut reader,
                "fixture",
                bytes,
                "521fe5c9ece1aa1f8b66228171598263574aefc6fa4ba06a61747ec81ee9f5a3",
                &archive,
                &|_| {},
            );
            assert_eq!(result.is_ok(), accepted, "{result:?}");
            assert_eq!(archive.exists(), accepted);
            if reader.get_ref().len() > 5 {
                assert_eq!(reader.position(), 5);
            }
            if accepted {
                fs::remove_file(&archive).unwrap();
            }
            assert_eq!(fs::read_dir(directory.path()).unwrap().count(), 0);
        }
    }

    #[test]
    fn every_host_pins_each_component_once_with_a_sha256() {
        for host in HOSTS {
            let names: Vec<&str> = host.components.iter().map(|(name, ..)| *name).collect();
            assert_eq!(
                &names[..3],
                ["rustc", "cargo", "rust-std"],
                "{}",
                host.target
            );
            for &(name, sha, _) in host.components {
                assert!(
                    sha.len() == 64 && sha.bytes().all(|b| b.is_ascii_hexdigit()),
                    "{name} {}",
                    host.target
                );
            }
        }
        let x64 = HOSTS
            .iter()
            .find(|h| h.target == WINDOWS_X64_TARGET)
            .unwrap();
        let arm64 = HOSTS
            .iter()
            .find(|h| h.target == WINDOWS_ARM64_TARGET)
            .unwrap();
        assert!(x64.target.ends_with("-gnu"), "preserve the x64 toolchain");
        assert!(x64
            .components
            .iter()
            .any(|(name, ..)| *name == "rust-mingw"));
        assert!(arm64
            .components
            .iter()
            .any(|(name, ..)| *name == "rust-mingw"));
        // Only Windows brings a C toolchain; macOS and Linux use the system's.
        for host in HOSTS {
            assert_eq!(
                host.c_toolchain.is_some(),
                host.target.contains("windows"),
                "{}",
                host.target
            );
        }
        assert_eq!(x64.c_toolchain.unwrap().kind, CToolchainKind::WinLibs);
        assert_eq!(arm64.c_toolchain.unwrap().kind, CToolchainKind::LlvmMingw);
        for compiler in [x64.c_toolchain.unwrap(), arm64.c_toolchain.unwrap()] {
            assert!(
                compiler.sha256.len() == 64
                    && compiler.sha256.bytes().all(|b| b.is_ascii_hexdigit()),
                "{}",
                compiler.version
            );
            assert!(compiler.url.starts_with("https://") && compiler.url.ends_with(".zip"));
        }
        assert!(x64.c_toolchain.unwrap().url.contains("msvcrt"));
        assert!(arm64.c_toolchain.unwrap().url.contains("ucrt"));
        if cfg!(all(target_os = "macos", target_arch = "aarch64")) {
            assert_eq!(host().unwrap().target, "aarch64-apple-darwin");
        }
        if cfg!(all(target_os = "macos", target_arch = "x86_64")) {
            assert_eq!(host().unwrap().target, "x86_64-apple-darwin");
        }
    }

    #[test]
    fn every_system_horizon_ships_for_can_build_native_mods() {
        // An Intel Mac had a game and a launcher but no compiler (#1161): native builds stopped
        // with "the launcher has none for macos x86_64".
        for (os, arch, game, _) in backend::PLATFORMS {
            let host = host_for(os, arch).unwrap_or_else(|| panic!("no Rust for {game}"));
            let expected_arch = if arch == "aarch64" {
                "aarch64-"
            } else {
                "x86_64-"
            };
            assert!(
                host.target.starts_with(expected_arch),
                "{game}: {}",
                host.target
            );
        }
        assert_eq!(
            host_for("macos", "x86_64").unwrap().target,
            "x86_64-apple-darwin"
        );
    }

    #[test]
    fn game_pe_architecture_selects_only_a_matching_managed_host() {
        assert_eq!(
            host_for("windows", "x86_64").unwrap().target,
            WINDOWS_X64_TARGET,
            "an x64 process under ARM64 emulation stays on the x64 compiler"
        );
        assert_eq!(
            host_for("windows", "aarch64").unwrap().target,
            WINDOWS_ARM64_TARGET
        );
        assert_eq!(windows_target_for_machine(0x8664), Some(WINDOWS_X64_TARGET));
        assert_eq!(
            windows_target_for_machine(0xaa64),
            Some(WINDOWS_ARM64_TARGET)
        );
        assert_eq!(
            windows_target_for_machine(0xa641),
            None,
            "ARM64EC is unsupported"
        );
        assert_eq!(
            windows_target_for_host(WINDOWS_X64_TARGET, WINDOWS_X64_MACHINE),
            Some(WINDOWS_X64_TARGET)
        );
        assert_eq!(
            windows_target_for_host(WINDOWS_ARM64_TARGET, WINDOWS_ARM64_MACHINE),
            Some(WINDOWS_ARM64_TARGET)
        );
        assert_eq!(
            windows_target_for_host(WINDOWS_X64_TARGET, WINDOWS_ARM64_MACHINE),
            None
        );
        assert_eq!(
            windows_target_for_host(WINDOWS_ARM64_TARGET, WINDOWS_X64_MACHINE),
            None
        );
    }

    #[test]
    fn the_players_compiler_settings_stay_out_of_builds() {
        for name in [
            "RUSTFLAGS",
            "CARGO_ENCODED_RUSTFLAGS",
            "RUSTDOCFLAGS",
            "CARGO_INCREMENTAL",
            "CARGO_PROFILE_RELEASE_LTO",
            "CARGO_PROFILE_RELEASE_CODEGEN_UNITS",
            "CARGO_BUILD_TARGET",
            "CARGO_BUILD_RUSTFLAGS",
            "CARGO_BUILD_RUSTC_WRAPPER",
            "CARGO_TARGET_DIR",
            "CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_LINKER",
            "CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_RUSTFLAGS",
            "RUSTC_WRAPPER",
            "RUSTUP_TOOLCHAIN",
            "cargo_profile_release_debug",
        ] {
            assert!(scrubbed(name), "{name}");
        }
        for name in [
            "CARGO_BUILD_JOBS",
            "PATH",
            "HOME",
            "CARGO_HOME",
            "CARGO_NET_OFFLINE",
            "CARGO_HTTP_PROXY",
            "HTTPS_PROXY",
            "SSL_CERT_FILE",
        ] {
            assert!(!scrubbed(name), "{name}");
        }
    }

    #[cfg(target_os = "linux")]
    #[test]
    fn builds_run_at_the_lowest_priority() {
        // Read back from the running child itself: its niceness and its I/O priority.
        let mut cmd = Command::new("sleep");
        cmd.arg("5");
        let mut child = low_priority(&mut cmd).spawn().unwrap();
        let pid = child.id();
        // The priority is set between fork and exec; wait for the exec.
        std::thread::sleep(std::time::Duration::from_millis(200));
        // SAFETY: plain system calls on a child process of this test.
        let (nice, io) = unsafe {
            let nice = libc::getpriority(libc::PRIO_PROCESS, pid as libc::id_t);
            let io = libc::syscall(
                libc::SYS_ioprio_get,
                IOPRIO_WHO_PROCESS,
                pid as libc::c_long,
            );
            (nice, io)
        };
        let _ = child.kill();
        let _ = child.wait();
        assert_eq!(nice, 19);
        assert_eq!(io, LOW_IO);
    }

    #[test]
    fn component_files_land_under_the_prefix_and_nothing_else_does() {
        let at = |p: &str| component_path(Path::new(p));
        assert_eq!(
            at("rustc-1.99.1-x/rustc/bin/rustc"),
            Some(PathBuf::from("bin/rustc"))
        );
        assert_eq!(
            at("rust-std-1.99.1-x/rust-std-x/lib/rustlib/x/lib/libstd.rlib"),
            Some(PathBuf::from("lib/rustlib/x/lib/libstd.rlib"))
        );
        for skipped in [
            "rustc-1.99.1-x/install.sh",
            "rustc-1.99.1-x/components",
            "rustc-1.99.1-x/rustc/manifest.in",
            "rustc-1.99.1-x/rustc",
            "rustc-1.99.1-x/../../etc/passwd",
            "/rustc-1.99.1-x/rustc/bin/rustc",
        ] {
            assert_eq!(at(skipped), None, "{skipped}");
        }
    }

    #[test]
    fn a_component_archive_unpacks_as_its_installer_would() {
        let dir = std::env::temp_dir().join(format!("horizon-rust-unpack-{}", std::process::id()));
        let _ = fs::remove_dir_all(&dir);
        fs::create_dir_all(&dir).unwrap();
        let archive = dir.join("cargo.tar.gz");
        let mut tar = tar::Builder::new(flate2::write::GzEncoder::new(
            fs::File::create(&archive).unwrap(),
            flate2::Compression::fast(),
        ));
        for (path, body, mode) in [
            ("cargo-1.99.1-x/install.sh", "#!/bin/sh", 0o755),
            ("cargo-1.99.1-x/cargo/manifest.in", "file:bin/cargo", 0o644),
            ("cargo-1.99.1-x/cargo/bin/cargo", "binary", 0o755),
        ] {
            let mut header = tar::Header::new_gnu();
            header.set_size(body.len() as u64);
            header.set_mode(mode);
            header.set_cksum();
            tar.append_data(&mut header, path, body.as_bytes()).unwrap();
        }
        tar.into_inner().unwrap().finish().unwrap().flush().unwrap();
        let prefix = dir.join("prefix");
        unpack(&archive, &prefix).unwrap();
        assert_eq!(
            fs::read_to_string(prefix.join("bin/cargo")).unwrap(),
            "binary"
        );
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let mode = fs::metadata(prefix.join("bin/cargo"))
                .unwrap()
                .permissions()
                .mode();
            assert_eq!(mode & 0o111, 0o111, "cargo stays executable");
        }
        assert!(!prefix.join("install.sh").exists() && !prefix.join("manifest.in").exists());
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn the_command_uses_only_the_launchers_toolchain() {
        for host in HOSTS {
            let toolchain = Toolchain {
                dir: PathBuf::from("/rust/1.99.1-x"),
                host,
            };
            the_command_uses_only(&toolchain);
        }
    }

    fn the_command_uses_only(toolchain: &Toolchain) {
        let cmd = toolchain.command(&toolchain.cargo());
        let env: Vec<(String, Option<String>)> = cmd
            .get_envs()
            .map(|(k, v)| {
                (
                    k.to_string_lossy().into_owned(),
                    v.map(|v| v.to_string_lossy().into_owned()),
                )
            })
            .collect();
        let get = |name: &str| env.iter().find(|(k, _)| k == name).map(|(_, v)| v.clone());
        assert_eq!(get("RUSTUP_TOOLCHAIN"), Some(None));
        assert_eq!(get("RUSTC_WRAPPER"), Some(None));
        assert_eq!(
            PathBuf::from(get("RUSTC").flatten().unwrap()),
            toolchain.dir.join("bin").join(exe("rustc"))
        );
        assert_eq!(
            std::env::split_paths(&get("PATH").flatten().unwrap()).next(),
            Some(toolchain.dir.join("bin"))
        );
        assert!(get("CARGO_HOME").flatten().unwrap().ends_with("cargo"));
    }

    /// The tools' scratch dir is the build's own (#5189): MinGW-w64's gcc, as and ld can't
    /// open a non-ASCII %TEMP%, like the one under a Cyrillic user name.
    #[test]
    fn the_command_uses_the_builds_own_temp_dir() {
        let tmp = backend::build_dir().join("tmp");
        for host in HOSTS {
            let toolchain = Toolchain {
                dir: PathBuf::from("/rust/1.99.1-x"),
                host,
            };
            let cmd = toolchain.command(&toolchain.cargo());
            for name in ["TMPDIR", "TMP", "TEMP"] {
                let value = cmd
                    .get_envs()
                    .find(|(k, _)| *k == name)
                    .and_then(|(_, v)| v)
                    .map(PathBuf::from);
                assert_eq!(
                    value.as_deref(),
                    Some(tmp.as_path()),
                    "{}: {name}",
                    host.target
                );
            }
        }
    }

    #[test]
    fn mingw_files_land_under_mingw64_without_the_documentation() {
        let at = |p: &str| mingw_path(Path::new(p));
        assert_eq!(
            at("mingw64/bin/gcc.exe"),
            Some(PathBuf::from("mingw64/bin/gcc.exe"))
        );
        assert_eq!(
            at("mingw64/libexec/gcc/x86_64-w64-mingw32/16.2.0/cc1.exe"),
            Some(PathBuf::from(
                "mingw64/libexec/gcc/x86_64-w64-mingw32/16.2.0/cc1.exe"
            ))
        );
        for skipped in [
            "mingw64",
            "mingw64/share/doc/gcc.html",
            "other/bin/gcc.exe",
            "mingw64/../evil.exe",
            "/mingw64/bin/gcc.exe",
        ] {
            assert_eq!(at(skipped), None, "{skipped}");
        }
    }

    #[test]
    fn a_mingw_zip_unpacks_its_programs_and_not_its_documentation() {
        let dir = std::env::temp_dir().join(format!("horizon-mingw-unpack-{}", std::process::id()));
        let _ = fs::remove_dir_all(&dir);
        fs::create_dir_all(&dir).unwrap();
        let archive = dir.join("mingw.zip");
        let mut zip = zip::ZipWriter::new(fs::File::create(&archive).unwrap());
        let options = zip::write::SimpleFileOptions::default();
        zip.add_directory("mingw64/bin/", options).unwrap();
        for (path, body) in [
            ("mingw64/bin/gcc.exe", "gcc"),
            ("mingw64/share/doc/readme.txt", "docs"),
            ("licenses/readme.txt", "outside"),
        ] {
            zip.start_file(path, options).unwrap();
            zip.write_all(body.as_bytes()).unwrap();
        }
        zip.finish().unwrap();
        let prefix = dir.join("prefix");
        unpack_mingw(&archive, &prefix).unwrap();
        assert_eq!(
            fs::read_to_string(prefix.join("mingw64/bin/gcc.exe")).unwrap(),
            "gcc"
        );
        assert!(!prefix.join("mingw64/share").exists() && !prefix.join("licenses").exists());
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn llvm_mingw_paths_are_safe_with_or_without_a_versioned_root() {
        let at = |p: &str| llvm_mingw_path(Path::new(p));
        assert_eq!(at("bin/clang.exe"), Some(PathBuf::from("bin/clang.exe")));
        assert_eq!(
            at("llvm-mingw-20261104-ucrt-aarch64/bin/clang.exe"),
            Some(PathBuf::from("bin/clang.exe"))
        );
        assert_eq!(at("llvm-mingw-20261104-ucrt-aarch64"), None);
        assert_eq!(at("../outside.exe"), None);
        assert_eq!(at("/bin/clang.exe"), None);
    }

    #[test]
    fn an_llvm_mingw_zip_unpacks_to_its_managed_folder() {
        let dir =
            std::env::temp_dir().join(format!("horizon-llvm-mingw-unpack-{}", std::process::id()));
        let _ = fs::remove_dir_all(&dir);
        fs::create_dir_all(&dir).unwrap();
        let archive = dir.join("llvm-mingw.zip");
        let mut zip = zip::ZipWriter::new(fs::File::create(&archive).unwrap());
        let options = zip::write::SimpleFileOptions::default();
        for (path, body) in [
            ("llvm-mingw-20261104-ucrt-aarch64/bin/clang.exe", "clang"),
            ("llvm-mingw-20261104-ucrt-aarch64/LICENSE.txt", "license"),
            ("../outside.exe", "unsafe"),
        ] {
            zip.start_file(path, options).unwrap();
            zip.write_all(body.as_bytes()).unwrap();
        }
        zip.finish().unwrap();
        let prefix = dir.join("prefix");
        unpack_llvm_mingw(&archive, &prefix).unwrap();
        assert_eq!(
            fs::read_to_string(prefix.join("llvm-mingw/bin/clang.exe")).unwrap(),
            "clang"
        );
        assert_eq!(
            fs::read_to_string(prefix.join("llvm-mingw/LICENSE.txt")).unwrap(),
            "license"
        );
        assert!(!prefix.join("outside.exe").exists());
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn arm64_toolchain_is_incomplete_without_each_required_c_and_link_tool() {
        let dir = std::env::temp_dir().join(format!("horizon-arm64-tools-{}", std::process::id()));
        let _ = fs::remove_dir_all(&dir);
        let host = HOSTS
            .iter()
            .find(|h| h.target == WINDOWS_ARM64_TARGET)
            .unwrap();
        let toolchain = Toolchain {
            dir: dir.clone(),
            host,
        };
        let bin = toolchain.mingw_bin();
        fs::create_dir_all(&bin).unwrap();
        for name in [
            "aarch64-w64-mingw32-clang",
            "aarch64-w64-mingw32-clang++",
            "llvm-ar",
            "llvm-ranlib",
            "llvm-dlltool",
            "aarch64-w64-mingw32-ar",
            "aarch64-w64-mingw32-windres",
        ] {
            assert!(!toolchain.compiler_available(), "missing {name}");
            fs::write(bin.join(exe(name)), "tool").unwrap();
        }
        assert!(toolchain.compiler_available());
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn the_command_puts_mingw_after_rust_when_the_toolchain_has_it() {
        let dir = std::env::temp_dir().join(format!("horizon-mingw-path-{}", std::process::id()));
        let _ = fs::remove_dir_all(&dir);
        let host = HOSTS
            .iter()
            .find(|h| h.target == WINDOWS_X64_TARGET)
            .unwrap();
        let toolchain = Toolchain {
            dir: dir.clone(),
            host,
        };
        fs::create_dir_all(toolchain.mingw_bin()).unwrap();
        let mut cmd = toolchain.command(&toolchain.cargo());
        toolchain.configure_cargo(&mut cmd);
        let path = cmd
            .get_envs()
            .find(|(k, _)| *k == "PATH")
            .and_then(|(_, v)| v)
            .unwrap();
        let first: Vec<PathBuf> = std::env::split_paths(path).take(2).collect();
        assert_eq!(first, [dir.join("bin"), toolchain.mingw_bin()]);
        assert!(!cmd
            .get_envs()
            .any(|(key, _)| matches!(key.to_string_lossy().as_ref(), "AR" | "WINDRES")));
        assert!(cmd.get_args().next().is_none());
        assert!(!cmd
            .get_envs()
            .any(|(key, _)| key == "CARGO_TARGET_AARCH64_PC_WINDOWS_GNULLVM_LINKER"));
        fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn the_arm64_command_selects_managed_llvm_c_and_link_tools() {
        let dir = std::env::temp_dir().join(format!(
            "horizon-arm64-toolchain-{} with spaces",
            std::process::id()
        ));
        let host = HOSTS
            .iter()
            .find(|h| h.target == WINDOWS_ARM64_TARGET)
            .unwrap();
        let toolchain = Toolchain { dir, host };
        let cmd = toolchain.command(&toolchain.cargo());
        let env: Vec<(String, Option<String>)> = cmd
            .get_envs()
            .map(|(k, v)| {
                (
                    k.to_string_lossy().into_owned(),
                    v.map(|v| v.to_string_lossy().into_owned()),
                )
            })
            .collect();
        let value = |name: &str| {
            env.iter()
                .find(|(key, _)| key == name)
                .and_then(|(_, value)| value.as_deref())
        };
        let compiler = toolchain.mingw_bin().join(exe("aarch64-w64-mingw32-clang"));
        assert_eq!(
            value("CC_aarch64_pc_windows_gnullvm"),
            Some(compiler.to_str().unwrap())
        );
        assert_eq!(
            value("AR_aarch64_pc_windows_gnullvm"),
            Some(toolchain.mingw_bin().join(exe("llvm-ar")).to_str().unwrap())
        );
        let mut cargo = toolchain.command(&toolchain.cargo());
        toolchain.configure_cargo(&mut cargo);
        let args: Vec<String> = cargo
            .get_args()
            .map(|arg| arg.to_string_lossy().into_owned())
            .collect();
        let dlltool = toolchain.mingw_bin().join(exe("llvm-dlltool"));
        let rustflags = toml::Value::Array(vec![
            toml::Value::String("-C".into()),
            toml::Value::String("target-feature=+crt-static".into()),
            toml::Value::String("-C".into()),
            toml::Value::String(format!("dlltool={}", dlltool.display())),
        ]);
        assert_eq!(
            args[1],
            format!("target.{WINDOWS_ARM64_TARGET}.rustflags={rustflags}")
        );
        assert_eq!(
            value("CARGO_TARGET_AARCH64_PC_WINDOWS_GNULLVM_LINKER"),
            Some(
                toolchain
                    .mingw_bin()
                    .join(exe("aarch64-w64-mingw32-clang"))
                    .to_str()
                    .unwrap()
            )
        );
        assert_eq!(
            value("AR"),
            Some(
                toolchain
                    .mingw_bin()
                    .join(exe("aarch64-w64-mingw32-ar"))
                    .to_str()
                    .unwrap()
            )
        );
        assert_eq!(
            value("WINDRES"),
            Some(
                toolchain
                    .mingw_bin()
                    .join(exe("aarch64-w64-mingw32-windres"))
                    .to_str()
                    .unwrap()
            )
        );
    }

    #[test]
    fn a_linux_build_names_what_is_missing_and_the_distributions_command() {
        // A system with `cc` and `pkg-config` but no development files, as Linux Mint ships.
        let no_dev =
            |program: &str, args: &[&str]| program != "pkg-config" || args[0] != "--exists";
        let mint = "NAME=\"Linux Mint\"\nID=linuxmint\nID_LIKE=\"ubuntu debian\"\n";
        let e = linux_needs(no_dev, mint, true).unwrap_err();
        assert!(
            e.contains("lacks them: ALSA's development files, libudev's development files."),
            "{e}"
        );
        assert!(
            e.ends_with("\nsudo apt install build-essential pkg-config libasound2-dev libudev-dev")
        );
        // The headless server build needs none of those: only a C compiler and its headers.
        assert_eq!(
            linux_needs(no_dev, mint, false),
            Ok(()),
            "headless links none"
        );
        // Nothing to check through without pkg-config, and nothing at all on SteamOS.
        let nothing = |_: &str, _: &[&str]| false;
        let deck = "ID=steamos\nID_LIKE=arch\n";
        let e = linux_needs(nothing, deck, true).unwrap_err();
        assert!(e.contains("a C compiler (cc), pkg-config, ALSA's"), "{e}");
        assert!(e.contains("SteamOS") && !e.contains("pacman"), "{e}");
        // Headless, the same system names only what it lacks: cc and the C library's headers.
        let e = linux_needs(nothing, deck, false).unwrap_err();
        assert!(e.contains("lacks them: a C compiler (cc)."), "{e}");
        assert!(!e.contains("pkg-config") && !e.contains("ALSA"), "{e}");
        // A C compiler alone is enough for the headless build.
        let cc_only = |program: &str, _: &[&str]| program == "cc";
        assert_eq!(linux_needs(cc_only, mint, false), Ok(()));
        // SteamOS 3's GCC runs but finds no `stdint.h` (#4770).
        let headless = |program: &str, args: &[&str]| program != "cc" || args == ["--version"];
        let e = linux_needs(headless, deck, false).unwrap_err();
        assert!(
            e.contains("lacks them: the C library's headers. SteamOS"),
            "{e}"
        );
        let arch = linux_needs(nothing, "ID=endeavouros\nID_LIKE=arch\n", true).unwrap_err();
        assert!(arch.contains("pacman -S --needed base-devel"), "{arch}");
        let fedora = linux_needs(nothing, "ID=fedora\n", true).unwrap_err();
        assert!(fedora.contains("dnf install"), "{fedora}");
        let other = linux_needs(nothing, "ID=gentoo\n", true).unwrap_err();
        assert!(
            other.contains("package manager") && other.contains("apt install"),
            "{other}"
        );
        // NixOS's packages are in the store: a shell that lists them is the only way in (#5248).
        let nixos = linux_needs(nothing, "NAME=NixOS\nID=nixos\n", true).unwrap_err();
        assert!(nixos.contains("nix-shell"), "{nixos}");
        assert!(
            nixos.contains("lacks them: a C compiler (cc), pkg-config"),
            "{nixos}"
        );
        assert!(!nixos.contains("apt install"), "{nixos}");
        assert_eq!(linux_needs(|_: &str, _: &[&str]| true, mint, true), Ok(()));
    }

    /// The Windows ARM64 CI invokes this ignored integration test on its real ARM64 runner. It
    /// exercises the downloaded host compiler, C dependencies, Windows imports and final linker.
    #[cfg(all(target_os = "windows", target_arch = "aarch64"))]
    #[test]
    #[ignore = "downloads the managed Windows ARM64 toolchain and builds Horizon"]
    fn managed_arm64_toolchain_builds_the_game() {
        let home = std::env::var_os("HORIZON_LAUNCHER_HOME").map_or_else(
            || {
                std::env::temp_dir().join(format!(
                    "horizon-managed-native-arm64-{}",
                    std::process::id()
                ))
            },
            PathBuf::from,
        );
        let _ = fs::create_dir_all(&home);
        std::env::set_var("HORIZON_LAUNCHER_HOME", &home);
        let target_dir = std::env::var_os("HORIZON_NATIVE_TARGET_DIR").map_or_else(
            || backend::build_dir().join("managed-native-target"),
            PathBuf::from,
        );

        let rust = install(|_| {}).expect("managed ARM64 Rust and LLVM-MinGW install");
        assert_eq!(rust.host.target, WINDOWS_ARM64_TARGET);
        assert!(rust.compiler_available(), "managed LLVM-MinGW is complete");

        let workspace = Path::new(env!("CARGO_MANIFEST_DIR")).parent().unwrap();
        let mut cargo = rust.command(&rust.cargo());
        low_priority(&mut cargo);
        rust.configure_cargo(&mut cargo);
        cargo
            .current_dir(workspace)
            .args([
                "build",
                "--locked",
                "--profile",
                "fast",
                "-p",
                "horizon-client",
                "--bin",
                "horizon-client",
            ])
            .env("CARGO_TARGET_DIR", &target_dir)
            .env(
                "CARGO_BUILD_JOBS",
                std::thread::available_parallelism()
                    .map(|n| n.get())
                    .unwrap_or(1)
                    .to_string(),
            );
        let output = cargo.output().expect("managed cargo starts on ARM64");
        assert!(
            output.status.success(),
            "managed ARM64 native-mod build failed\n{}\n{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
        let executable = target_dir.join("fast").join(crate::backend::CLIENT);
        assert_eq!(
            crate::native_mods::pe_machine(&executable).unwrap(),
            WINDOWS_ARM64_MACHINE,
            "managed native-mod game must be ARM64"
        );
    }
}
