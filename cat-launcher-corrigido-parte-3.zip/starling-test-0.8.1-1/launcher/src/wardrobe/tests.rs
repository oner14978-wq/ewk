//! The Wardrobe client against a local mock of the cosmetics service (its answers' shapes).
use super::*;
use std::io::{BufRead, BufReader, Read, Write};
use std::net::TcpListener;
use std::sync::{Arc, Mutex};

const UUID: &str = "069a79f444e94726a5befca90e38aaf5";

#[derive(Default)]
struct Mock {
    /// The claim window's state, as the service would say it.
    claim: &'static str,
    /// How long a session lasts, in seconds.
    expires_in: u64,
    /// The server ids Mojang's session server was told this account joined.
    joined: Vec<String>,
    /// Every request: method, path, Authorization header, body.
    log: Vec<(String, String, String, String)>,
    /// The service fails on its side (503) for the account's changes.
    down: bool,
    /// The service refuses every sign-in (401), as when it is misconfigured.
    sign_in_fails: bool,
    /// "Show my cosmetics", as the service keeps it.
    visible: bool,
    /// The file every `?hash=` request answers, whatever its path says.
    item: Option<Value>,
    /// Paddle doesn't sell where the player is: the service grants the set from the Wardrobe.
    no_paddle: bool,
    /// The account claimed the founder set.
    claimed: bool,
}

fn me(claim: &str, owned: Value, equipped: Value) -> Value {
    json!({
        "uuid": UUID, "name": "Notch", "owned": owned, "equipped": equipped, "visible": true,
        "claim": {"state": claim, "items": ["hat", "owl"], "starts_at": 100, "ends_at": 200, "claimed": owned != json!([])},
    })
}

/// `/v1/me`'s answer as the founder claim stands: the set owned once claimed, `one_click` where
/// Paddle doesn't sell.
fn founder(m: &Mock) -> Value {
    let owned = if m.claimed {
        json!(["hat", "owl"])
    } else {
        json!([])
    };
    let mut me = me(m.claim, owned, json!({}));
    me["claim"]["open"] = json!(m.claim == "open");
    me["claim"]["one_click"] = json!(m.no_paddle);
    me
}

fn route(m: &mut Mock, method: &str, path: &str, auth: &str, body: &str) -> (u16, Value) {
    let signed_in = auth == "Bearer svc-session";
    match (method, path) {
        ("GET", "/v1/catalogue") => (
            200,
            json!({
                "items": [
                    {"id": "hat", "hash": "ab12", "slot": "head", "names": {"en_us": "Hat", "fr_fr": "Chapeau"}},
                    {"id": "dawn", "hash": "cd34", "slot": "theme", "names": {"en_us": "Dawn"},
                     "theme": {"sky": ["#0b1030", "#1d2a63", "#3d4c94", "#7f78c0", "#e2a0b0", "#ffd6a0"], "accent_hue": 344}},
                ],
                "claim": {"state": m.claim, "items": ["hat"], "starts_at": null, "ends_at": null},
            }),
        ),
        ("POST", "/v1/auth/start") if m.sign_in_fails => (401, json!({"error": "no_session"})),
        ("POST", "/v1/auth/start") => (200, json!({"server_id": "issued-1", "expires_in": 120})),
        ("POST", "/v1/auth/finish") => {
            let v: Value = serde_json::from_str(body).unwrap();
            let id = v["server_id"].as_str().unwrap_or("");
            if id != "issued-1" || !m.joined.iter().any(|j| j == id) {
                return (401, json!({"error": "not_joined"}));
            }
            (
                200,
                json!({"session": "svc-session", "uuid": UUID, "name": v["name"], "expires_in": m.expires_in}),
            )
        }
        (_, "/v1/me" | "/v1/equipped" | "/v1/visible" | "/v1/claim") if !signed_in => {
            (401, json!({"error": "no_session"}))
        }
        ("PUT", "/v1/equipped" | "/v1/visible") if m.down => (503, json!({"error": "down"})),
        ("PUT", "/v1/visible") => {
            let v: Value = serde_json::from_str(body).unwrap();
            m.visible = v["visible"].as_bool().unwrap();
            let mut me = me(m.claim, json!(["hat"]), json!({}));
            me["visible"] = json!(m.visible);
            (200, me)
        }
        ("GET", "/v1/me") => (200, founder(m)),
        ("POST", "/v1/claim") if !m.no_paddle => (403, json!({"error": "use_checkout"})),
        ("POST", "/v1/claim") if m.claimed => (409, json!({"error": "claimed"})),
        ("POST", "/v1/claim") => {
            m.claimed = true;
            (200, founder(m))
        }
        ("PUT", "/v1/equipped") => {
            let v: Value = serde_json::from_str(body).unwrap();
            match v["item"].as_str() {
                Some("hat") => (200, me(m.claim, json!(["hat"]), json!({"head": "hat"}))),
                _ => (403, json!({"error": "not_owned"})),
            }
        }
        ("GET", "/v1/shop") => (
            200,
            json!({"open": m.claim == "open", "state": m.claim, "preview": false,
                   "starts_at": 100, "ends_at": 200, "now": 150, "items": ["hat"]}),
        ),
        ("GET", p) if p.contains("?hash=") && m.item.is_some() => (200, m.item.clone().unwrap()),
        _ => (404, json!({"error": "not_found"})),
    }
}

/// A one-thread HTTP/1.1 server, one request per connection.
fn serve(f: impl FnOnce(&mut Mock)) -> (Arc<Mutex<Mock>>, Service) {
    let mut mock = Mock {
        claim: "open",
        expires_in: 3600,
        ..Default::default()
    };
    f(&mut mock);
    let mock = Arc::new(Mutex::new(mock));
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let base = format!("http://{}", listener.local_addr().unwrap());
    let shared = mock.clone();
    std::thread::spawn(move || {
        for stream in listener.incoming() {
            let Ok(mut stream) = stream else { continue };
            let mut reader = BufReader::new(stream.try_clone().unwrap());
            let mut line = String::new();
            if reader.read_line(&mut line).is_err() {
                continue;
            }
            let mut parts = line.split_whitespace();
            let (method, path) = (
                parts.next().unwrap_or("").to_owned(),
                parts.next().unwrap_or("").to_owned(),
            );
            let (mut length, mut auth) = (0, String::new());
            loop {
                let mut header = String::new();
                reader.read_line(&mut header).unwrap();
                let header = header.trim_end();
                if header.is_empty() {
                    break;
                }
                let (k, v) = header.split_once(':').unwrap();
                match k.to_ascii_lowercase().as_str() {
                    "content-length" => length = v.trim().parse().unwrap(),
                    "authorization" => auth = v.trim().to_owned(),
                    _ => {}
                }
            }
            let mut body = vec![0; length];
            reader.read_exact(&mut body).unwrap();
            let body = String::from_utf8(body).unwrap();
            if (method.as_str(), path.as_str()) == ("GET", "/") {
                continue;
            }
            let (status, reply) = {
                let mut m = shared.lock().unwrap();
                m.log
                    .push((method.clone(), path.clone(), auth.clone(), body.clone()));
                route(&mut m, &method, &path, &auth, &body)
            };
            let text = reply.to_string();
            let _ = write!(
                stream,
                "HTTP/1.1 {status} X\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{text}",
                text.len()
            );
        }
    });
    (mock, Service::at(&format!("{base}/")))
}

/// Sign in with a `join` that Mojang accepts: it records the id as joined.
fn sign_in(m: &Arc<Mutex<Mock>>, service: &Service) -> Session {
    service
        .sign_in("Notch", |id| {
            m.lock().unwrap().joined.push(id.to_owned());
            Ok(())
        })
        .unwrap()
}

#[test]
fn signing_in_goes_through_mojang_and_sends_the_service_no_token() {
    let (m, service) = serve(|_| {});
    // `join` fails (Mojang refused): the service is never asked to finish.
    let refused = service.sign_in("Notch", |_| Err("refused".into()));
    assert_eq!(refused.unwrap_err(), Error::Account("refused".into()));
    // `join` claims success but Mojang never saw it: the service refuses the id.
    let unconfirmed = service.sign_in("Notch", |_| Ok(())).unwrap_err();
    assert!(matches!(unconfirmed, Error::Account(ref e) if e.contains("Sign in again")));

    let session = sign_in(&m, &service);
    assert_eq!(
        (session.uuid.as_str(), session.name.as_str()),
        (UUID, "Notch")
    );
    assert!(!format!("{session:?}").contains("svc-session"));
    let me = service.me(&session).unwrap();
    assert_eq!(me.claim.state, ClaimState::Open);

    let log = &m.lock().unwrap().log;
    let paths: Vec<&str> = log.iter().map(|(_, p, ..)| p.as_str()).collect();
    assert_eq!(
        paths,
        [
            "/v1/auth/start",
            "/v1/auth/start",
            "/v1/auth/finish",
            "/v1/auth/start",
            "/v1/auth/finish",
            "/v1/me"
        ]
    );
    // Only the service's own session is ever sent as a credential.
    for (_, path, auth, body) in log {
        assert!(!body.contains("accessToken"));
        assert_eq!(auth == "Bearer svc-session", path == "/v1/me");
    }
}

#[test]
fn equipping_follows_ownership() {
    let (m, service) = serve(|m| m.claim = "not_yet");
    let catalogue = service.catalogue().unwrap();
    assert_eq!(catalogue.claim.state, ClaimState::NotYet);
    assert_eq!(catalogue.items[0].name("fr_fr"), "Chapeau");
    assert_eq!(catalogue.items[0].name("ja_jp"), "Hat");
    let session = sign_in(&m, &service);
    let me = service.equip(&session, "head", Some("hat")).unwrap();
    assert_eq!(me.equipped.get("head").map(String::as_str), Some("hat"));
    assert_eq!(
        service.equip(&session, "head", Some("crown")).unwrap_err(),
        Error::NotYours
    );
}

#[test]
fn an_ended_session_is_not_sent_and_offline_says_so() {
    let (m, service) = serve(|m| m.expires_in = 30);
    // Less than the minute's margin: the session counts as ended at once.
    let session = sign_in(&m, &service);
    let before = m.lock().unwrap().log.len();
    assert_eq!(service.me(&session).unwrap_err(), Error::SignedOut);
    assert_eq!(m.lock().unwrap().log.len(), before);
    // Nothing listens on port 9.
    let offline = Service::at("http://127.0.0.1:9");
    assert_eq!(offline.catalogue().unwrap_err(), Error::Offline);
}

#[test]
fn a_launcher_theme_carries_its_sky() {
    let (_, service) = serve(|_| {});
    let catalogue = service.catalogue().unwrap();
    let dawn = catalogue.items.iter().find(|e| e.slot == "theme").unwrap();
    let sky = dawn.theme.as_ref().unwrap().sky().unwrap();
    assert_eq!((sky[0], sky[5]), (0x0b1030, 0xffd6a0));
    assert!(catalogue.items[0].theme.is_none());
}

#[test]
fn changes_made_offline_wait_on_disk_and_go_out_in_order() {
    let dir = scratch("queue");
    let (m, service) = serve(|m| m.down = true);
    let session = sign_in(&m, &service);
    let mut saved = Saved {
        me: Some(service.me(&session).unwrap()),
        ..Default::default()
    };
    // Two changes of the head and one of visibility: the newer head replaces the older.
    let hat = |item: Option<&str>| Change::Equip {
        slot: "head".into(),
        item: item.map(Into::into),
    };
    saved.change(hat(Some("crown")));
    saved.change(Change::Visible(false));
    saved.change(hat(Some("hat")));
    assert_eq!(saved.pending, [Change::Visible(false), hat(Some("hat"))]);
    let me = saved.me.as_ref().unwrap();
    assert_eq!((me.equipped["head"].as_str(), me.visible), ("hat", false));
    // The service fails: nothing leaves the queue, and it survives a restart.
    assert_eq!(service.sync(&session, &mut saved), Err(Error::Service(503)));
    assert_eq!(saved.pending.len(), 2);
    saved.save(&dir, UUID).unwrap();
    let mut saved = Saved::load(&dir, UUID);
    assert_eq!(saved.pending.len(), 2);
    // Back: both go out, oldest first, and the service's answer replaces the guess.
    m.lock().unwrap().down = false;
    service.sync(&session, &mut saved).unwrap();
    assert!(saved.pending.is_empty());
    assert!(!m.lock().unwrap().visible);
    let me = saved.me.as_ref().unwrap();
    assert_eq!(me.equipped["head"], "hat");
    let sent: Vec<String> = m
        .lock()
        .unwrap()
        .log
        .iter()
        .filter(|(k, ..)| k == "PUT")
        .map(|(_, p, ..)| p.clone())
        .collect();
    // The failed sync stopped at the first change; the second sent both.
    assert_eq!(sent, ["/v1/visible", "/v1/visible", "/v1/equipped"]);
    // An item no longer owned is refused for good: dropped, not retried.
    saved.change(hat(Some("crown")));
    service.sync(&session, &mut saved).unwrap();
    assert!(saved.pending.is_empty());
}

#[test]
fn an_item_file_is_kept_by_its_hash() {
    let dir = scratch("items");
    let entry = entry("hat", "ab12");
    std::fs::write(dir.join("hat-ab12.json"), item_file("hat")).unwrap();
    // Offline, the kept file is read; another hash would need the service.
    let offline = Service::at("http://127.0.0.1:9");
    assert_eq!(offline.item_cached(&entry, &dir).unwrap().id, "hat");
    let newer = Entry {
        hash: "ef56".into(),
        ..entry
    };
    assert_eq!(
        offline.item_cached(&newer, &dir).unwrap_err(),
        Error::Offline
    );
}

#[test]
fn a_real_catalogue_entry_is_fetched_kept_and_read_back() {
    let dir = scratch("real");
    let (_, service) = serve(|m| m.item = serde_json::from_str(&item_file("founder_visor")).ok());
    // An id and hash as the live catalogue has them.
    let entry = entry("founder_visor", "66e9e963f1958c22");
    let item = service.item_cached(&entry, &dir).unwrap();
    assert_eq!(item.id, "founder_visor");
    assert!(dir.join("founder_visor-66e9e963f1958c22.json").is_file());
    let offline = Service::at("http://127.0.0.1:9");
    let item = offline.item_cached(&entry, &dir).unwrap();
    assert_eq!(item.id, "founder_visor");
}

#[test]
fn an_entry_that_could_leave_the_cache_is_refused() {
    let root = scratch("traversal");
    let cache = root.join("items");
    // A file a traversal could read, and a service that would send one to write.
    std::fs::write(root.join("kept-ab12.json"), item_file("hat")).unwrap();
    let (m, service) = serve(|m| m.item = serde_json::from_str(&item_file("hat")).ok());
    let absolute = root.join("absolute").display().to_string();
    for (id, hash) in [
        ("../kept", "ab12"),
        ("../escape", "ab12"),
        ("..\\escape", "ab12"),
        ("hat", "x/../../escape"),
        ("hat", "x\\..\\..\\escape"),
        (absolute.as_str(), "ab12"),
        ("..", "ab12"),
        ("hat", ".."),
        ("hat:x", "ab12"),
        ("hat", "c:"),
        ("hat\0", "ab12"),
        ("hat", "ab12\0"),
        ("", "ab12"),
        ("hat", ""),
    ] {
        assert_eq!(
            service.item_cached(&entry(id, hash), &cache).unwrap_err(),
            Error::Service(200),
            "{id:?} {hash:?}"
        );
    }
    assert!(m.lock().unwrap().log.is_empty());
    let beside_the_cache: Vec<String> = std::fs::read_dir(&root)
        .unwrap()
        .map(|e| e.unwrap().file_name().into_string().unwrap())
        .filter(|name| name != "items")
        .collect();
    assert_eq!(beside_the_cache, ["kept-ab12.json"]);
}

fn entry(id: &str, hash: &str) -> Entry {
    Entry {
        id: id.into(),
        hash: hash.into(),
        slot: "head".into(),
        names: BTreeMap::new(),
        ..Default::default()
    }
}

/// A valid item file, as the service sends it.
fn item_file(id: &str) -> String {
    format!(
        r#"{{"format": 1, "id": "{id}", "slot": "head", "bone": "head", "texture": {{"png": "{}"}}, "parts": []}}"#,
        png_8x8()
    )
}

/// An 8×8 transparent PNG, base64.
fn png_8x8() -> String {
    use base64::Engine;
    let mut bytes = std::io::Cursor::new(Vec::new());
    image::RgbaImage::new(8, 8)
        .write_to(&mut bytes, image::ImageFormat::Png)
        .unwrap();
    base64::engine::general_purpose::STANDARD.encode(bytes.into_inner())
}

fn scratch(name: &str) -> PathBuf {
    let root = std::env::temp_dir().join(format!(
        "horizon-launcher-wardrobe-{name}-{}",
        std::process::id()
    ));
    let _ = std::fs::remove_dir_all(&root);
    std::fs::create_dir_all(&root).unwrap();
    root
}

#[test]
fn the_shop_status_is_asked_without_a_session() {
    let (mock, service) = serve(|m| m.claim = "not_yet");
    let status = service.shop().unwrap();
    assert!(!status.open);
    assert_eq!(status.state, ClaimState::NotYet);
    assert_eq!((status.starts_at, status.ends_at), (Some(100), Some(200)));
    let log = &mock.lock().unwrap().log;
    assert_eq!(log.len(), 1);
    let (method, path, auth, _) = &log[0];
    assert_eq!(
        (method.as_str(), path.as_str(), auth.as_str()),
        ("GET", "/v1/shop", "")
    );
}

#[test]
fn a_state_this_launcher_does_not_know_still_reads() {
    let (m, service) = serve(|m| m.claim = "paused");
    assert_eq!(service.shop().unwrap().state, ClaimState::Unknown);
    assert_eq!(
        service.catalogue().unwrap().claim.state,
        ClaimState::Unknown
    );
    let me = service.me(&sign_in(&m, &service)).unwrap();
    assert_eq!(me.claim.state, ClaimState::Unknown);
    // Kept on disk, it reads back the same.
    let kept = serde_json::to_vec(&me).unwrap();
    assert_eq!(serde_json::from_slice::<Me>(&kept).unwrap(), me);
}

#[test]
fn the_history_keeps_its_orders_and_an_old_answer_still_reads() {
    let answer = json!({
        "uuid": "u", "name": "Notch", "owned": [], "equipped": {}, "visible": true,
        "claim": {"state": "open", "items": ["hat"], "starts_at": 1, "ends_at": 2, "claimed": false, "open": true},
        "purchases": [
            {"transaction_id": "txn_b", "item": "top_hat", "amount": 330, "currency": "EUR", "status": "refunded", "at": 9},
            {"transaction_id": "txn_a", "item": "founder_set", "amount": 0, "currency": "CHF", "status": "paid", "at": 5}
        ]
    });
    let me: Me = serde_json::from_value(answer).unwrap();
    assert_eq!(me.purchases[0].price().as_deref(), Some("3.30 EUR"));
    assert_eq!(me.purchases[1].price(), None);
    // What is kept on disk reads back the same.
    let kept: Me = serde_json::from_str(&serde_json::to_string(&me).unwrap()).unwrap();
    assert_eq!(kept.purchases, me.purchases);
    // An answer from before sales still reads.
    let old: Me = serde_json::from_value(json!({
        "uuid": "u", "name": "Notch", "owned": [], "equipped": {},
        "claim": {"state": "not_yet", "items": [], "starts_at": null, "ends_at": null}
    }))
    .unwrap();
    assert!(old.purchases.is_empty());
}

/// `join` for `sync_with_session`: tells Mojang the account joined `id`, as a server would.
fn joined(m: &Arc<Mutex<Mock>>) -> impl Fn(&str) -> Result<(), String> {
    let m = m.clone();
    move |id: &str| {
        m.lock().unwrap().joined.push(id.to_owned());
        Ok(())
    }
}

/// How often the service was asked to finish a sign-in.
fn finishes(m: &Arc<Mutex<Mock>>) -> usize {
    m.lock()
        .unwrap()
        .log
        .iter()
        .filter(|(_, path, ..)| path == "/v1/auth/finish")
        .count()
}

/// A live session is reused: the account is proved with Mojang once per service session, not
/// once per refresh (the Wardrobe used to sign in again every few minutes).
#[test]
fn a_live_session_is_reused_between_refreshes() {
    let (m, service) = serve(|_| {});
    let mut saved = Saved::default();
    let mut session = None;
    service
        .sync_with_session("Notch", UUID, &mut session, &mut saved, joined(&m))
        .unwrap();
    assert_eq!(finishes(&m), 1);
    assert_eq!(m.lock().unwrap().joined.len(), 1);
    service
        .sync_with_session("Notch", UUID, &mut session, &mut saved, joined(&m))
        .unwrap();
    assert_eq!(
        finishes(&m),
        1,
        "a live session was proved with Mojang again"
    );
    assert_eq!(m.lock().unwrap().joined.len(), 1);
}

/// A session that ran out, or one for another account, signs in again.
#[test]
fn an_ended_session_signs_in_again() {
    let (m, service) = serve(|_| {});
    let mut saved = Saved::default();
    let ended = Arc::new(Session {
        token: "svc-session".into(),
        until: Instant::now() - Duration::from_secs(1),
        uuid: UUID.into(),
        name: "Notch".into(),
    });
    let mut session = Some(ended);
    service
        .sync_with_session("Notch", UUID, &mut session, &mut saved, joined(&m))
        .unwrap();
    assert_eq!(finishes(&m), 1);
    assert!(session.as_ref().is_some_and(|s| s.live()));
    // Another account's live session is not this account's.
    let other = Arc::new(Session {
        token: "svc-session".into(),
        until: Instant::now() + Duration::from_secs(600),
        uuid: "00000000000000000000000000000000".into(),
        name: "Other".into(),
    });
    let mut session = Some(other);
    service
        .sync_with_session("Notch", UUID, &mut session, &mut saved, joined(&m))
        .unwrap();
    assert_eq!(finishes(&m), 2);
    assert_eq!(session.as_ref().unwrap().uuid, UUID);
}

/// The service answering 401 ends the session: the launcher signs in once more and retries the
/// call.
#[test]
fn a_401_signs_in_again_and_retries_once() {
    let (m, service) = serve(|_| {});
    let mut saved = Saved::default();
    let stale = Arc::new(Session {
        token: "ended".into(),
        until: Instant::now() + Duration::from_secs(600),
        uuid: UUID.into(),
        name: "Notch".into(),
    });
    let mut session = Some(stale);
    service
        .sync_with_session("Notch", UUID, &mut session, &mut saved, joined(&m))
        .unwrap();
    assert_eq!(finishes(&m), 1);
    assert_eq!(session.as_ref().unwrap().token, "svc-session");
    assert!(saved.me.is_some());
}

/// A service that refuses every sign-in is not retried in a loop: the 401 stands.
#[test]
fn a_refused_sign_in_is_not_retried_forever() {
    let (m, service) = serve(|m| m.sign_in_fails = true);
    let stale = Arc::new(Session {
        token: "ended".into(),
        until: Instant::now() + Duration::from_secs(600),
        uuid: UUID.into(),
        name: "Notch".into(),
    });
    let mut session = Some(stale);
    let err = service
        .sync_with_session(
            "Notch",
            UUID,
            &mut session,
            &mut Saved::default(),
            joined(&m),
        )
        .unwrap_err();
    assert_eq!(err, Error::SignedOut);
    // One refused 401, one refused sign-in: no second round.
    let requested: Vec<String> = m
        .lock()
        .unwrap()
        .log
        .iter()
        .map(|(_, path, ..)| path.clone())
        .collect();
    assert_eq!(requested, ["/v1/me", "/v1/auth/start"]);
}

#[test]
fn the_free_claim_is_offered_only_where_the_service_says_and_grants_once() {
    // Where Paddle sells: nothing offered, and the service refuses a claim anyway.
    let (m, service) = serve(|_| {});
    let session = sign_in(&m, &service);
    assert!(!service.me(&session).unwrap().claim.here());
    let refused = service.claim(&session).unwrap_err();
    assert!(refused.use_checkout(), "{refused:?}");
    assert!(!refused.retry_later());
    // Where it doesn't: offered, then the set is the account's and the offer is gone.
    let (m, service) = serve(|m| m.no_paddle = true);
    let session = sign_in(&m, &service);
    assert!(service.me(&session).unwrap().claim.here());
    let me = service.claim(&session).unwrap();
    assert_eq!(me.owned, ["hat", "owl"]);
    assert!(!me.claim.here());
    // Claimed already (another launcher, a double click): the account's answer, no failure.
    assert_eq!(service.claim(&session).unwrap().owned, ["hat", "owl"]);
    // A closed window offers nothing, whatever the country.
    let (m, service) = serve(|m| {
        m.no_paddle = true;
        m.claim = "closed";
    });
    let session = sign_in(&m, &service);
    assert!(!service.me(&session).unwrap().claim.here());
}

#[test]
fn each_claim_refusal_says_what_to_do_instead_of_a_bare_failure() {
    // The service's answers to `POST /v1/claim` (horizon-cosmetics' README): each one gets its
    // own words, never the "had a problem" line a 403 used to show (Discord, 2026-11-05).
    let generic = Error::Service(403).message();
    let paddle = Error::Shop("paddle".into()).message();
    let mut said = std::collections::BTreeSet::new();
    for code in [
        "use_checkout",
        "not_offered_here",
        "claim_not_open",
        "claimed",
    ] {
        let e = Error::Shop(code.into());
        assert_ne!(e.message(), generic, "{code}");
        assert_ne!(e.message(), paddle, "{code}");
        said.insert(e.message());
    }
    assert_eq!(said.len(), 4, "{said:#?}");
    assert!(!Error::Shop("not_offered_here".into()).use_checkout());
}
