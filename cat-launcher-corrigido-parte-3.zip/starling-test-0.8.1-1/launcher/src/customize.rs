//! A personalização do personagem do Cat Launcher: o catálogo de peças (camisas, calças, shorts,
//! calçados, acessórios, chapéus e capas), a importação de arquivos do jogador, a skin completa
//! montada a partir das peças escolhidas, o salvamento e o desenho do personagem (de frente, de
//! lado e de costas) que a tela mostra.
//!
//! O Minecraft só conhece uma skin inteira (PNG 64x64) e uma capa (PNG 64x32). Por isso as peças
//! separadas existem só aqui: `Store::compose` as junta numa skin completa, que é o que o jogo
//! recebe (`apply_to_command`, as variáveis `HORIZON_OFFLINE_SKIN`, `HORIZON_OFFLINE_SKIN_MODEL`
//! e `HORIZON_OFFLINE_CAPE`, lidas por `horizon-client-render/src/skins.rs`) e o que se exporta
//! (`Store::export_skin`) para enviar à conta Microsoft. Skin e capa da conta Microsoft são
//! decididas pela Mojang: um servidor oficial só mostra o que a conta tem; uma capa própria não
//! pode ser enviada à conta.
//!
//! Tudo fica em `<pasta de dados>/customize/`: `outfit.json` (a escolha salva), `library.json` (os
//! arquivos importados), `imports/*.png` (os arquivos já validados), `skin.png` e `cape.png` (o
//! que o jogo lê).
use image::{imageops, Rgba, RgbaImage};
use serde::{Deserialize, Serialize};
use sha1::{Digest, Sha1};
use std::ops::Range;
use std::path::{Path, PathBuf};

/// O maior arquivo aceito na importação.
pub const MAX_FILE: u64 = 2 << 20;
/// A maior largura ou altura aceita numa imagem importada.
pub const MAX_SIDE: u32 = 2048;

/// Um retângulo da textura: x, y, largura, altura.
pub type Rect = (u32, u32, u32, u32);

/// Onde cada peça se veste.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Category {
    Shirt,
    Pants,
    Shorts,
    Accessory,
    Hat,
    Shoes,
    Cape,
    /// Uma skin completa importada, usada como base das peças.
    Skin,
}

impl Category {
    /// As categorias que têm peças para escolher.
    pub const WEARABLE: [Category; 7] = [
        Category::Shirt,
        Category::Pants,
        Category::Shorts,
        Category::Shoes,
        Category::Accessory,
        Category::Hat,
        Category::Cape,
    ];

    pub fn key(self) -> &'static str {
        match self {
            Self::Shirt => "shirt",
            Self::Pants => "pants",
            Self::Shorts => "shorts",
            Self::Accessory => "accessory",
            Self::Hat => "hat",
            Self::Shoes => "shoes",
            Self::Cape => "cape",
            Self::Skin => "skin",
        }
    }

    pub fn label(self) -> &'static str {
        match self {
            Self::Shirt => "Camisas",
            Self::Pants => "Calças",
            Self::Shorts => "Shorts",
            Self::Accessory => "Acessórios",
            Self::Hat => "Chapéus",
            Self::Shoes => "Calçados",
            Self::Cape => "Capas",
            Self::Skin => "Skin",
        }
    }
}

/// O que o jogador veste: o id de cada peça (`b:<categoria>:<chave>` para as do launcher,
/// `i-<categoria>-<hash>` para as importadas).
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default)]
pub struct Outfit {
    pub skin: Option<String>,
    pub shirt: Option<String>,
    pub pants: Option<String>,
    pub shorts: Option<String>,
    pub shoes: Option<String>,
    pub accessory: Option<String>,
    pub hat: Option<String>,
    pub cape: Option<String>,
}

impl Outfit {
    pub fn get(&self, cat: Category) -> Option<&String> {
        match cat {
            Category::Shirt => self.shirt.as_ref(),
            Category::Pants => self.pants.as_ref(),
            Category::Shorts => self.shorts.as_ref(),
            Category::Shoes => self.shoes.as_ref(),
            Category::Accessory => self.accessory.as_ref(),
            Category::Hat => self.hat.as_ref(),
            Category::Cape => self.cape.as_ref(),
            Category::Skin => self.skin.as_ref(),
        }
    }

    pub fn set(&mut self, cat: Category, id: Option<String>) {
        match cat {
            Category::Shirt => self.shirt = id,
            Category::Pants => self.pants = id,
            Category::Shorts => self.shorts = id,
            Category::Shoes => self.shoes = id,
            Category::Accessory => self.accessory = id,
            Category::Hat => self.hat = id,
            Category::Cape => self.cape = id,
            Category::Skin => self.skin = id,
        }
    }

    pub fn is_default(&self) -> bool {
        *self == Outfit::default()
    }
}

/// Um arquivo importado e já validado.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Imported {
    pub id: String,
    pub category: Category,
    pub name: String,
    /// Só para skins completas: os braços finos (Alex).
    #[serde(default)]
    pub slim: bool,
}

/// Uma peça da lista de uma categoria.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PartInfo {
    pub id: String,
    pub name: String,
    pub imported: bool,
}

// ---------------------------------------------------------------------------------------------
// A textura: onde cada parte do corpo fica na skin 64x64.
// ---------------------------------------------------------------------------------------------

/// Uma caixa da skin: onde começa na textura (`u`, `v`) e o tamanho (`w` x `h` x `d`).
#[derive(Clone, Copy, Debug)]
pub struct Bx {
    pub u: u32,
    pub v: u32,
    pub w: u32,
    pub h: u32,
    pub d: u32,
}

const fn bx(u: u32, v: u32, w: u32, h: u32, d: u32) -> Bx {
    Bx { u, v, w, h, d }
}

const HEAD: Bx = bx(0, 0, 8, 8, 8);
const HEAD_OUT: Bx = bx(32, 0, 8, 8, 8);
const BODY: Bx = bx(16, 16, 8, 12, 4);
const BODY_OUT: Bx = bx(16, 32, 8, 12, 4);
const R_LEG: Bx = bx(0, 16, 4, 12, 4);
const R_LEG_OUT: Bx = bx(0, 32, 4, 12, 4);
const L_LEG: Bx = bx(16, 48, 4, 12, 4);
const L_LEG_OUT: Bx = bx(0, 48, 4, 12, 4);

fn r_arm(slim: bool) -> Bx {
    bx(40, 16, if slim { 3 } else { 4 }, 12, 4)
}
fn r_arm_out(slim: bool) -> Bx {
    bx(40, 32, if slim { 3 } else { 4 }, 12, 4)
}
fn l_arm(slim: bool) -> Bx {
    bx(32, 48, if slim { 3 } else { 4 }, 12, 4)
}
fn l_arm_out(slim: bool) -> Bx {
    bx(48, 48, if slim { 3 } else { 4 }, 12, 4)
}

/// Os retângulos das faces de uma caixa, só nas linhas `rows` da altura (a tampa de cima entra
/// se as linhas começam em 0, a de baixo se vão até o fim).
pub fn faces(b: Bx, rows: Range<u32>) -> Vec<Rect> {
    let (r0, r1) = (rows.start.min(b.h), rows.end.min(b.h));
    let mut out = Vec::new();
    if r0 >= r1 {
        return out;
    }
    for (x, fw) in [
        (b.u, b.d),
        (b.u + b.d, b.w),
        (b.u + b.d + b.w, b.d),
        (b.u + 2 * b.d + b.w, b.w),
    ] {
        out.push((x, b.v + b.d + r0, fw, r1 - r0));
    }
    if r0 == 0 {
        out.push((b.u + b.d, b.v, b.w, b.d));
    }
    if r1 == b.h {
        out.push((b.u + b.d + b.w, b.v, b.w, b.d));
    }
    out
}

/// Onde uma categoria mexe na skin: a camada de baixo e a de cima (casaco, mangas, calça, chapéu).
#[derive(Default, Debug)]
pub struct Region {
    pub base: Vec<Rect>,
    pub outer: Vec<Rect>,
}

/// A região de uma categoria. `short_sleeve`: a camisa do launcher cobre só o alto dos braços.
pub fn region(cat: Category, slim: bool, short_sleeve: bool) -> Region {
    let mut r = Region::default();
    let arm_rows = if short_sleeve { 0..4 } else { 0..12 };
    let both = |r: &mut Region, base: Bx, outer: Bx, rows: Range<u32>| {
        r.base.extend(faces(base, rows.clone()));
        r.outer.extend(faces(outer, rows));
    };
    match cat {
        Category::Shirt => {
            both(&mut r, BODY, BODY_OUT, 0..12);
            both(&mut r, r_arm(slim), r_arm_out(slim), arm_rows.clone());
            both(&mut r, l_arm(slim), l_arm_out(slim), arm_rows);
        }
        Category::Pants | Category::Shorts | Category::Shoes => {
            let rows = match cat {
                Category::Pants => 0..12,
                Category::Shorts => 0..5,
                _ => 9..12,
            };
            both(&mut r, R_LEG, R_LEG_OUT, rows.clone());
            both(&mut r, L_LEG, L_LEG_OUT, rows);
        }
        Category::Hat => r.outer.extend(faces(HEAD_OUT, 0..8)),
        Category::Accessory => r.outer.push((40, 8, 8, 8)),
        Category::Skin => {
            r.base.push((0, 0, 64, 64));
        }
        Category::Cape => {}
    }
    r
}

fn alpha_over(dst: &mut Rgba<u8>, src: Rgba<u8>) {
    let sa = src[3] as u32;
    if sa == 0 {
        return;
    }
    if sa == 255 || dst[3] == 0 {
        *dst = src;
        return;
    }
    let da = dst[3] as u32;
    let out_a = sa + da * (255 - sa) / 255;
    for i in 0..3 {
        let c = (src[i] as u32 * sa + dst[i] as u32 * da * (255 - sa) / 255) / out_a.max(1);
        dst[i] = c.min(255) as u8;
    }
    dst[3] = out_a.min(255) as u8;
}

fn fill(img: &mut RgbaImage, r: Rect, c: [u8; 4]) {
    for y in r.1..(r.1 + r.3).min(img.height()) {
        for x in r.0..(r.0 + r.2).min(img.width()) {
            img.put_pixel(x, y, Rgba(c));
        }
    }
}

fn set(img: &mut RgbaImage, x: u32, y: u32, c: [u8; 4]) {
    if x < img.width() && y < img.height() {
        img.put_pixel(x, y, Rgba(c));
    }
}

fn rgba(c: u32) -> [u8; 4] {
    [(c >> 16) as u8, (c >> 8) as u8, c as u8, 255]
}

fn shade(c: [u8; 4], f: f32) -> [u8; 4] {
    [
        (c[0] as f32 * f).min(255.) as u8,
        (c[1] as f32 * f).min(255.) as u8,
        (c[2] as f32 * f).min(255.) as u8,
        c[3],
    ]
}

// ---------------------------------------------------------------------------------------------
// As peças do launcher.
// ---------------------------------------------------------------------------------------------

#[derive(Clone, Copy, PartialEq)]
enum Pattern {
    Solid,
    Stripes,
    Checker,
}

struct Palette {
    key: &'static str,
    name: &'static str,
    main: u32,
    alt: u32,
}

const COLORS: [Palette; 9] = [
    Palette { key: "red", name: "Vermelha", main: 0xd63030, alt: 0x8e1b1b },
    Palette { key: "blue", name: "Azul", main: 0x2f6fdc, alt: 0x1b3f8e },
    Palette { key: "yellow", name: "Amarela", main: 0xf5c518, alt: 0xb58f0c },
    Palette { key: "black", name: "Preta", main: 0x25252b, alt: 0x111114 },
    Palette { key: "white", name: "Branca", main: 0xf2f2f5, alt: 0xc4c4cc },
    Palette { key: "pink", name: "Rosa", main: 0xff7ac0, alt: 0xc2478f },
    Palette { key: "orange", name: "Laranja", main: 0xff8a1e, alt: 0xb55a08 },
    Palette { key: "green", name: "Verde", main: 0x38b94a, alt: 0x1f7a2d },
    Palette { key: "purple", name: "Roxa", main: 0x8b4be8, alt: 0x5a27a8 },
];

const BOTTOMS: [Palette; 6] = [
    Palette { key: "jeans", name: "Jeans", main: 0x3a56c8, alt: 0x28399a },
    Palette { key: "black", name: "Preta", main: 0x25252b, alt: 0x111114 },
    Palette { key: "gray", name: "Cinza", main: 0x8a8a92, alt: 0x5d5d66 },
    Palette { key: "brown", name: "Marrom", main: 0x7a5230, alt: 0x4f3219 },
    Palette { key: "olive", name: "Verde-militar", main: 0x5d7a3a, alt: 0x3d5224 },
    Palette { key: "beige", name: "Bege", main: 0xd8c39a, alt: 0xa8946a },
];

const SHOES: [Palette; 6] = [
    Palette { key: "black", name: "Tênis preto", main: 0x25252b, alt: 0xffffff },
    Palette { key: "white", name: "Tênis branco", main: 0xf2f2f5, alt: 0x9a9aa6 },
    Palette { key: "red", name: "Tênis vermelho", main: 0xd63030, alt: 0xffffff },
    Palette { key: "blue", name: "Tênis azul", main: 0x2f6fdc, alt: 0xffffff },
    Palette { key: "brown", name: "Bota marrom", main: 0x6a4426, alt: 0x3e2812 },
    Palette { key: "purple", name: "Tênis roxo", main: 0x8b4be8, alt: 0xffffff },
];

const CAPES: [Palette; 7] = [
    Palette { key: "red", name: "Capa vermelha", main: 0xc42b2b, alt: 0xf5c518 },
    Palette { key: "blue", name: "Capa azul", main: 0x2a5fd0, alt: 0xffffff },
    Palette { key: "purple", name: "Capa roxa", main: 0x7c3aed, alt: 0xff4fe0 },
    Palette { key: "black", name: "Capa preta", main: 0x1b1b22, alt: 0x7c3aed },
    Palette { key: "green", name: "Capa verde", main: 0x2e9c45, alt: 0xf2f2f5 },
    Palette { key: "gold", name: "Capa dourada", main: 0xe0a812, alt: 0x7a4a08 },
    Palette { key: "white", name: "Capa branca", main: 0xeeeef2, alt: 0x8b4be8 },
];

/// Todas as peças do launcher de uma categoria: (chave, nome).
fn builtin_keys(cat: Category) -> Vec<(String, String)> {
    let mut v = Vec::new();
    match cat {
        Category::Shirt => {
            for p in &COLORS {
                v.push((p.key.to_string(), format!("Camisa {}", p.name.to_lowercase())));
            }
            for k in ["blue", "red", "green"] {
                let p = COLORS.iter().find(|p| p.key == k).unwrap();
                v.push((format!("stripes-{k}"), format!("Camisa listrada {}", p.name.to_lowercase())));
            }
            v.push(("checker-red".into(), "Camisa xadrez".into()));
        }
        Category::Pants | Category::Shorts => {
            let what = if cat == Category::Pants { "Calça" } else { "Short" };
            for p in &BOTTOMS {
                v.push((p.key.to_string(), format!("{what} {}", p.name.to_lowercase())));
            }
            v.push(("checker-gray".into(), format!("{what} xadrez")));
        }
        Category::Shoes => {
            for p in &SHOES {
                v.push((p.key.to_string(), p.name.to_string()));
            }
        }
        Category::Hat => {
            for (k, n) in [
                ("cap-red", "Boné vermelho"),
                ("cap-blue", "Boné azul"),
                ("straw", "Chapéu de palha"),
                ("top", "Cartola"),
                ("beanie-green", "Gorro verde"),
                ("beanie-purple", "Gorro roxo"),
                ("cap-black", "Boné preto"),
            ] {
                v.push((k.into(), n.into()));
            }
        }
        Category::Accessory => {
            for (k, n) in [
                ("shades", "Óculos escuros"),
                ("glasses", "Óculos de grau"),
                ("shades-blue", "Óculos azuis"),
                ("visor", "Viseira roxa"),
                ("mask-med", "Máscara cirúrgica"),
                ("mask-black", "Máscara preta"),
                ("bandana", "Bandana vermelha"),
            ] {
                v.push((k.into(), n.into()));
            }
        }
        Category::Cape => {
            for p in &CAPES {
                v.push((p.key.to_string(), p.name.to_string()));
            }
        }
        Category::Skin => {}
    }
    v
}

fn pattern_color(p: Pattern, main: [u8; 4], alt: [u8; 4], x: u32, y: u32) -> [u8; 4] {
    match p {
        Pattern::Solid => main,
        Pattern::Stripes => {
            if (y / 2) % 2 == 0 {
                main
            } else {
                alt
            }
        }
        Pattern::Checker => {
            if (x / 2 + y / 2) % 2 == 0 {
                main
            } else {
                alt
            }
        }
    }
}

fn paint_clothes(skin: &mut RgbaImage, cat: Category, slim: bool, key: &str) {
    let pal: &[Palette] = match cat {
        Category::Shirt => &COLORS,
        Category::Shoes => &SHOES,
        _ => &BOTTOMS,
    };
    let (pattern, color_key) = if let Some(k) = key.strip_prefix("stripes-") {
        (Pattern::Stripes, k)
    } else if let Some(k) = key.strip_prefix("checker-") {
        (Pattern::Checker, k)
    } else {
        (Pattern::Solid, key)
    };
    let pal_item = pal
        .iter()
        .find(|p| p.key == color_key)
        .or_else(|| COLORS.iter().find(|p| p.key == color_key))
        .or_else(|| BOTTOMS.iter().find(|p| p.key == color_key));
    let Some(p) = pal_item else { return };
    let (main, alt) = (rgba(p.main), rgba(p.alt));
    let reg = region(cat, slim, true);
    // A peça do launcher vai na camada de baixo; a de cima, nesta região, sai para não cobri-la.
    for r in &reg.outer {
        fill(skin, *r, [0, 0, 0, 0]);
    }
    for r in &reg.base {
        for y in r.1..r.1 + r.3 {
            for x in r.0..r.0 + r.2 {
                let mut c = pattern_color(pattern, main, alt, x, y);
                // Calçados: a sola mais escura.
                if cat == Category::Shoes && y % 16 >= 14 {
                    c = shade(c, 0.6);
                }
                set(skin, x, y, c);
            }
        }
    }
}

fn paint_hat(skin: &mut RgbaImage, key: &str) {
    let (main, accent, rows, brim, band): (u32, u32, u32, bool, Option<u32>) = match key {
        "cap-red" => (0xd63030, 0x8e1b1b, 2, true, None),
        "cap-blue" => (0x2f6fdc, 0x1b3f8e, 2, true, None),
        "cap-black" => (0x25252b, 0x111114, 2, true, None),
        "straw" => (0xe8c860, 0xb58f0c, 2, true, None),
        "top" => (0x1b1b22, 0x0a0a0d, 3, false, Some(0xc42b2b)),
        "beanie-green" => (0x2e9c45, 0x1f7a2d, 3, false, None),
        "beanie-purple" => (0x7c3aed, 0x5a27a8, 3, false, None),
        _ => return,
    };
    for r in faces(HEAD_OUT, 0..8) {
        fill(skin, r, [0, 0, 0, 0]);
    }
    let (m, a) = (rgba(main), rgba(accent));
    fill(skin, (40, 0, 8, 8), m);
    for x0 in [32u32, 40, 48, 56] {
        fill(skin, (x0, 8, 8, rows), m);
        if let Some(b) = band {
            fill(skin, (x0, 8 + rows - 1, 8, 1), rgba(b));
        }
    }
    if brim {
        fill(skin, (40, 8 + rows, 8, 1), a);
    }
    if key == "straw" {
        for y in 0..8u32 {
            for x in 0..8u32 {
                if (x + y) % 2 == 0 {
                    set(skin, 40 + x, y, a);
                }
            }
        }
    }
}

fn paint_accessory(skin: &mut RgbaImage, key: &str) {
    let front = |x: u32, y: u32| (40 + x, 8 + y);
    let mut put = |x: u32, y: u32, c: [u8; 4]| {
        let (px, py) = front(x, y);
        set(skin, px, py, c);
    };
    match key {
        "shades" | "shades-blue" => {
            let c = if key == "shades" { 0x111114 } else { 0x1b3f8e };
            for x in 0..8 {
                for y in 4..6 {
                    put(x, y, rgba(c));
                }
            }
            put(0, 4, rgba(0x000000));
            put(7, 4, rgba(0x000000));
        }
        "glasses" => {
            for (x0, x1) in [(1u32, 3u32), (5, 7)] {
                for x in x0..=x1 {
                    put(x, 3, rgba(0xf2f2f5));
                    put(x, 6, rgba(0xf2f2f5));
                }
                put(x0, 4, rgba(0xf2f2f5));
                put(x0, 5, rgba(0xf2f2f5));
                put(x1, 4, rgba(0xf2f2f5));
                put(x1, 5, rgba(0xf2f2f5));
            }
            put(4, 4, rgba(0xf2f2f5));
        }
        "visor" => {
            for x in 0..8 {
                for y in 3..6 {
                    put(x, y, rgba(0x9b6bff));
                }
            }
        }
        "mask-med" | "mask-black" => {
            let c = if key == "mask-med" { 0xbfe3f5 } else { 0x25252b };
            for x in 0..8 {
                for y in 5..8 {
                    put(x, y, rgba(c));
                }
            }
            put(3, 6, rgba(0xffffff));
            put(4, 6, rgba(0xffffff));
        }
        "bandana" => {
            for x in 0..8 {
                for y in 5..8 {
                    put(x, y, rgba(0xd63030));
                }
            }
            for (x, y) in [(1, 6), (3, 7), (5, 6), (6, 7)] {
                put(x, y, rgba(0xffffff));
            }
        }
        _ => {}
    }
}

/// A capa do launcher: 64x32 com o desenho no canto de 22x17 (fora: de costas em (1,1), por
/// dentro em (12,1)).
fn builtin_cape(key: &str) -> Option<RgbaImage> {
    let p = CAPES.iter().find(|p| p.key == key)?;
    let mut img = RgbaImage::new(64, 32);
    let (main, alt) = (rgba(p.main), rgba(p.alt));
    fill(&mut img, (0, 0, 22, 17), shade(main, 0.75));
    fill(&mut img, (1, 1, 10, 16), main);
    fill(&mut img, (12, 1, 10, 16), shade(main, 0.65));
    // Borda e faixa central do lado de fora, para ler de costas.
    fill(&mut img, (1, 1, 10, 1), alt);
    fill(&mut img, (1, 16, 10, 1), alt);
    fill(&mut img, (5, 3, 2, 11), alt);
    fill(&mut img, (3, 7, 6, 2), alt);
    Some(img)
}

/// A skin que vale quando nada foi escolhido.
pub fn default_skin() -> RgbaImage {
    let mut img = RgbaImage::new(64, 64);
    let skin = rgba(0xb98a68);
    let hair = rgba(0x3b2a1a);
    let teal = rgba(0x1ba6a6);
    let jeans = rgba(0x3c44aa);
    let shoe = rgba(0x6b6b72);
    for b in [HEAD, r_arm(false), l_arm(false)] {
        for r in faces(b, 0..b.h) {
            fill(&mut img, r, skin);
        }
    }
    // Cabelo.
    fill(&mut img, (8, 0, 8, 8), hair);
    for x0 in [0u32, 8, 16, 24] {
        fill(&mut img, (x0, 8, 8, 2), hair);
    }
    fill(&mut img, (24, 8, 8, 8), hair);
    // Rosto.
    for (x, y, c) in [
        (1u32, 4u32, 0xffffffu32),
        (2, 4, 0x4b3e8a),
        (5, 4, 0x4b3e8a),
        (6, 4, 0xffffff),
        (3, 5, 0x8a5a3c),
        (4, 5, 0x8a5a3c),
        (2, 6, 0x5a3a24),
        (3, 6, 0x5a3a24),
        (4, 6, 0x5a3a24),
        (5, 6, 0x5a3a24),
    ] {
        set(&mut img, 8 + x, 8 + y, rgba(c));
    }
    for r in faces(BODY, 0..12) {
        fill(&mut img, r, teal);
    }
    for b in [r_arm(false), l_arm(false)] {
        for r in faces(b, 0..4) {
            fill(&mut img, r, teal);
        }
    }
    for b in [R_LEG, L_LEG] {
        for r in faces(b, 0..12) {
            fill(&mut img, r, jeans);
        }
        for r in faces(b, 10..12) {
            fill(&mut img, r, shoe);
        }
    }
    img
}

// ---------------------------------------------------------------------------------------------
// Validação das imagens importadas.
// ---------------------------------------------------------------------------------------------

fn decode_png(bytes: &[u8]) -> Result<RgbaImage, String> {
    if !bytes.starts_with(b"\x89PNG\r\n\x1a\n") {
        return Err("O arquivo não é um PNG.".into());
    }
    let img = image::load_from_memory_with_format(bytes, image::ImageFormat::Png)
        .map_err(|e| format!("PNG inválido: {e}"))?;
    let (w, h) = (img.width(), img.height());
    if w == 0 || h == 0 || w > MAX_SIDE || h > MAX_SIDE {
        return Err(format!("Tamanho de imagem não aceito: {w}x{h}."));
    }
    Ok(img.to_rgba8())
}

/// Copia um membro 4x12x4 espelhado (a skin antiga 64x32 só tinha o direito).
fn mirror_limb(img: &mut RgbaImage, src: (u32, u32), dst: (u32, u32)) {
    let (w, h, d) = (4u32, 12u32, 4u32);
    let copy = |img: &mut RgbaImage, s: Rect, t: Rect| {
        for y in 0..s.3 {
            for x in 0..s.2 {
                let p = *img.get_pixel(s.0 + x, s.1 + y);
                img.put_pixel(t.0 + (s.2 - 1 - x), t.1 + y, p);
            }
        }
    };
    let (su, sv) = src;
    let (du, dv) = dst;
    copy(img, (su + d, sv, w, d), (du + d, dv, w, d));
    copy(img, (su + d + w, sv, w, d), (du + d + w, dv, w, d));
    copy(img, (su, sv + d, d, h), (du + d + w, dv + d, d, h));
    copy(img, (su + d, sv + d, w, h), (du + d, dv + d, w, h));
    copy(img, (su + d + w, sv + d, d, h), (du, dv + d, d, h));
    copy(img, (su + 2 * d + w, sv + d, w, h), (du + 2 * d + w, dv + d, w, h));
}

/// Uma skin 64x64, ou a antiga 64x32 refeita em 64x64 (como o jogo a lê).
pub fn normalize_skin(img: &RgbaImage) -> Result<RgbaImage, String> {
    let ok64 = img.width() == 64 && img.height() == 64;
    let ok32 = img.width() == 64 && img.height() == 32;
    if !ok64 && !ok32 {
        return Err(format!(
            "A skin precisa ter 64x64 ou 64x32 pixels (este arquivo tem {}x{}).",
            img.width(),
            img.height()
        ));
    }
    let mut out = RgbaImage::new(64, 64);
    imageops::replace(&mut out, img, 0, 0);
    if ok32 {
        mirror_limb(&mut out, (0, 16), (16, 48));
        mirror_limb(&mut out, (40, 16), (32, 48));
    }
    Ok(out)
}

/// Uma capa como o jogo a lê: 64x32 (ou 22x17, ou esses tamanhos em dobro, triplo...), posta
/// no canto de uma tela 64x32.
pub fn normalize_cape(img: &RgbaImage) -> Result<RgbaImage, String> {
    let (w, h) = (img.width(), img.height());
    let mut out = RgbaImage::new(64, 32);
    if w % 64 == 0 && h * 2 == w {
        let small = imageops::resize(img, 64, 32, imageops::FilterType::Nearest);
        imageops::replace(&mut out, &small, 0, 0);
    } else if w % 22 == 0 && h % 17 == 0 && w / 22 == h / 17 {
        let small = imageops::resize(img, 22, 17, imageops::FilterType::Nearest);
        imageops::replace(&mut out, &small, 0, 0);
    } else {
        return Err(format!(
            "A capa precisa ter 64x32 ou 22x17 pixels, ou esses tamanhos ampliados (este arquivo tem {w}x{h})."
        ));
    }
    if !out.pixels().any(|p| p[3] > 0) {
        return Err("A capa está totalmente transparente.".into());
    }
    Ok(out)
}

/// Se uma skin 64x64 tem os braços finos (o lado de fora do braço direito tem 3 de largura).
pub fn is_slim(skin: &RgbaImage) -> bool {
    skin.width() == 64 && skin.height() >= 32 && skin.get_pixel(54, 20)[3] == 0 && skin.get_pixel(55, 20)[3] == 0
}

/// Valida o arquivo de uma categoria e devolve a imagem como ela fica guardada.
pub fn validate(cat: Category, bytes: &[u8]) -> Result<RgbaImage, String> {
    let img = decode_png(bytes)?;
    match cat {
        Category::Cape => normalize_cape(&img),
        Category::Skin => normalize_skin(&img),
        _ => {
            let skin = normalize_skin(&img)?;
            let reg = region(cat, false, false);
            let any = reg
                .base
                .iter()
                .chain(reg.outer.iter())
                .any(|r| (r.1..r.1 + r.3).any(|y| (r.0..r.0 + r.2).any(|x| skin.get_pixel(x, y)[3] > 0)));
            if !any {
                return Err(format!(
                    "O arquivo não tem pixels na região de {} da skin; use um PNG 64x64 com a peça no lugar dela.",
                    cat.label().to_lowercase()
                ));
            }
            Ok(skin)
        }
    }
}

fn apply_imported(skin: &mut RgbaImage, cat: Category, slim: bool, img: &RgbaImage) {
    let reg = region(cat, slim, false);
    for r in reg.base.iter().chain(reg.outer.iter()) {
        for y in r.1..(r.1 + r.3).min(64) {
            for x in r.0..(r.0 + r.2).min(64) {
                let mut d = *skin.get_pixel(x, y);
                alpha_over(&mut d, *img.get_pixel(x, y));
                skin.put_pixel(x, y, d);
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// O armazenamento.
// ---------------------------------------------------------------------------------------------

/// Escreve um arquivo inteiro de uma vez (escreve ao lado e renomeia).
fn write_atomic(path: &Path, bytes: &[u8]) -> Result<(), String> {
    if let Some(dir) = path.parent() {
        std::fs::create_dir_all(dir).map_err(|e| format!("{}: {e}", dir.display()))?;
    }
    let tmp = path.with_extension("tmp");
    std::fs::write(&tmp, bytes).map_err(|e| format!("{}: {e}", tmp.display()))?;
    std::fs::rename(&tmp, path).map_err(|e| format!("{}: {e}", path.display()))
}

pub fn png_bytes(img: &RgbaImage) -> Vec<u8> {
    let mut out = std::io::Cursor::new(Vec::new());
    let _ = img.write_to(&mut out, image::ImageFormat::Png);
    out.into_inner()
}

fn clean_name(path: &Path) -> String {
    let stem = path.file_stem().and_then(|s| s.to_str()).unwrap_or("Arquivo");
    let name: String = stem.chars().filter(|c| !c.is_control()).take(24).collect();
    if name.trim().is_empty() {
        "Arquivo".into()
    } else {
        name
    }
}

/// A pasta da personalização, na pasta de dados do launcher.
pub fn default_root() -> PathBuf {
    crate::backend::data_dir().join("customize")
}

/// Valida `path` e guarda o resultado em `root/imports`. Não mexe no índice (`Store::add`):
/// roda fora da tela.
pub fn import_file(root: &Path, cat: Category, path: &Path) -> Result<Imported, String> {
    let len = std::fs::metadata(path).map_err(|e| format!("{}: {e}", path.display()))?.len();
    if len > MAX_FILE {
        return Err(format!("{}: o arquivo passa de 2 MB.", path.display()));
    }
    let bytes = std::fs::read(path).map_err(|e| format!("{}: {e}", path.display()))?;
    let img = validate(cat, &bytes).map_err(|e| format!("{}: {e}", clean_name(path)))?;
    let png = png_bytes(&img);
    let mut h = Sha1::new();
    h.update(&png);
    let hex: String = h.finalize().iter().take(6).map(|b| format!("{b:02x}")).collect();
    let id = format!("i-{}-{hex}", cat.key());
    write_atomic(&root.join("imports").join(format!("{id}.png")), &png)?;
    Ok(Imported {
        id,
        category: cat,
        name: clean_name(path),
        slim: cat == Category::Skin && is_slim(&img),
    })
}

/// O que o launcher guarda da personalização.
pub struct Store {
    root: PathBuf,
    pub library: Vec<Imported>,
    /// O que foi salvo por último (o que o jogo recebe).
    pub saved: Outfit,
}

impl Store {
    pub fn open(root: PathBuf) -> Store {
        let library: Vec<Imported> = std::fs::read(root.join("library.json"))
            .ok()
            .and_then(|b| serde_json::from_slice(&b).ok())
            .unwrap_or_default();
        let saved: Outfit = std::fs::read(root.join("outfit.json"))
            .ok()
            .and_then(|b| serde_json::from_slice(&b).ok())
            .unwrap_or_default();
        let mut store = Store { root, library, saved };
        // Um arquivo que sumiu da pasta sai da lista.
        let root = store.root.clone();
        store.library.retain(|i| root.join("imports").join(format!("{}.png", i.id)).is_file());
        store
    }

    pub fn root(&self) -> &Path {
        &self.root
    }

    fn save_library(&self) -> Result<(), String> {
        let json = serde_json::to_vec_pretty(&self.library).map_err(|e| e.to_string())?;
        write_atomic(&self.root.join("library.json"), &json)
    }

    /// Põe um arquivo importado na lista (e a grava). Já importado: não repete.
    pub fn add(&mut self, item: Imported) -> Result<(), String> {
        if !self.library.iter().any(|i| i.id == item.id) {
            self.library.push(item);
        }
        self.save_library()
    }

    /// Tira um arquivo importado da lista e do disco.
    pub fn remove(&mut self, id: &str) -> Result<(), String> {
        self.library.retain(|i| i.id != id);
        let _ = std::fs::remove_file(self.root.join("imports").join(format!("{id}.png")));
        self.save_library()
    }

    fn image(&self, id: &str) -> Option<RgbaImage> {
        if !id.starts_with("i-") || id.contains(['/', '\\', '.']) {
            return None;
        }
        image::open(self.root.join("imports").join(format!("{id}.png"))).ok().map(|i| i.to_rgba8())
    }

    /// As peças de uma categoria: as do launcher e depois as importadas.
    pub fn parts(&self, cat: Category) -> Vec<PartInfo> {
        let mut v: Vec<PartInfo> = builtin_keys(cat)
            .into_iter()
            .map(|(k, name)| PartInfo { id: format!("b:{}:{k}", cat.key()), name, imported: false })
            .collect();
        v.extend(self.library.iter().filter(|i| i.category == cat).map(|i| PartInfo {
            id: i.id.clone(),
            name: i.name.clone(),
            imported: true,
        }));
        v
    }

    pub fn is_slim(&self, outfit: &Outfit) -> bool {
        outfit
            .skin
            .as_ref()
            .and_then(|id| self.library.iter().find(|i| &i.id == id))
            .is_some_and(|i| i.slim)
    }

    /// A skin completa do que se veste.
    pub fn compose(&self, outfit: &Outfit) -> RgbaImage {
        let slim = self.is_slim(outfit);
        let mut skin = outfit
            .skin
            .as_deref()
            .and_then(|id| self.image(id))
            .unwrap_or_else(default_skin);
        for cat in [
            Category::Shirt,
            Category::Pants,
            Category::Shorts,
            Category::Shoes,
            Category::Hat,
            Category::Accessory,
        ] {
            let Some(id) = outfit.get(cat) else { continue };
            if let Some(key) = id.strip_prefix(&format!("b:{}:", cat.key())) {
                match cat {
                    Category::Hat => paint_hat(&mut skin, key),
                    Category::Accessory => paint_accessory(&mut skin, key),
                    _ => paint_clothes(&mut skin, cat, slim, key),
                }
            } else if let Some(img) = self.image(id) {
                apply_imported(&mut skin, cat, slim, &img);
            }
        }
        skin
    }

    /// A capa escolhida, em 64x32.
    pub fn cape(&self, outfit: &Outfit) -> Option<RgbaImage> {
        let id = outfit.cape.as_deref()?;
        match id.strip_prefix("b:cape:") {
            Some(key) => builtin_cape(key),
            None => self.image(id),
        }
    }

    /// Guarda a escolha: `outfit.json`, a skin completa (`skin.png`) e a capa (`cape.png`), que
    /// o jogo lê. A escolha padrão apaga os dois PNG: o jogo volta à aparência original.
    pub fn save(&mut self, outfit: &Outfit) -> Result<(), String> {
        let json = serde_json::to_vec_pretty(outfit).map_err(|e| e.to_string())?;
        let skin_path = self.root.join("skin.png");
        let cape_path = self.root.join("cape.png");
        let wears_parts = outfit.skin.is_some()
            || [Category::Shirt, Category::Pants, Category::Shorts, Category::Shoes, Category::Hat, Category::Accessory]
                .iter()
                .any(|c| outfit.get(*c).is_some());
        if wears_parts {
            write_atomic(&skin_path, &png_bytes(&self.compose(outfit)))?;
        } else {
            let _ = std::fs::remove_file(&skin_path);
        }
        match self.cape(outfit) {
            Some(cape) => write_atomic(&cape_path, &png_bytes(&cape))?,
            None => {
                let _ = std::fs::remove_file(&cape_path);
            }
        }
        write_atomic(&self.root.join("outfit.json"), &json)?;
        self.saved = outfit.clone();
        Ok(())
    }

    /// A skin completa do que foi salvo, para enviar à conta Microsoft ou usar noutro lugar.
    pub fn export_skin(&self, dest: &Path) -> Result<(), String> {
        let skin = self.compose(&self.saved);
        write_atomic(dest, &png_bytes(&skin))
    }
}

/// Passa ao jogo o que foi salvo: a skin completa e a capa (variáveis lidas por
/// `horizon-client-render`). Nada salvo: o jogo fica como era.
pub fn apply_to_command(cmd: &mut std::process::Command) {
    let root = default_root();
    let skin = root.join("skin.png");
    let cape = root.join("cape.png");
    if skin.is_file() {
        let slim = std::fs::read(root.join("outfit.json"))
            .ok()
            .and_then(|b| serde_json::from_slice::<Outfit>(&b).ok())
            .map(|o| Store::open(root.clone()).is_slim(&o))
            .unwrap_or(false);
        cmd.env("HORIZON_OFFLINE_SKIN", &skin)
            .env("HORIZON_OFFLINE_SKIN_MODEL", if slim { "slim" } else { "classic" });
    }
    if cape.is_file() {
        cmd.env("HORIZON_OFFLINE_CAPE", &cape);
    }
}

// ---------------------------------------------------------------------------------------------
// O desenho do personagem.
// ---------------------------------------------------------------------------------------------

/// Um pedaço do espaço do personagem (unidades de pixel da skin; y para cima, com os pés em 0)
/// e a ampliação.
#[derive(Clone, Copy, Debug)]
pub struct View {
    /// Giro em graus: 0 de frente, 90 pelo lado esquerdo do personagem, 180 de costas.
    pub yaw: i32,
    pub x0: f32,
    /// O topo do quadro.
    pub y0: f32,
    pub w: f32,
    pub h: f32,
    pub scale: f32,
}

impl View {
    /// O personagem inteiro.
    pub fn full(yaw: i32) -> View {
        View { yaw, x0: -12., y0: 33.5, w: 24., h: 34.5, scale: 9. }
    }
}

struct Solid {
    min: [f32; 3],
    max: [f32; 3],
    b: Bx,
    /// Textura: 0 a skin, 1 a capa.
    cape: bool,
}

fn solids(slim: bool, with_cape: bool) -> Vec<Solid> {
    let inflate = |min: [f32; 3], max: [f32; 3], e: f32| {
        ([min[0] - e, min[1] - e, min[2] - e], [max[0] + e, max[1] + e, max[2] + e])
    };
    let aw = if slim { 3. } else { 4. };
    let parts: [([f32; 3], [f32; 3], Bx, Bx, f32); 6] = [
        ([-4., 24., -4.], [4., 32., 4.], HEAD, HEAD_OUT, 0.5),
        ([-4., 12., -2.], [4., 24., 2.], BODY, BODY_OUT, 0.25),
        ([-4. - aw, 12., -2.], [-4., 24., 2.], r_arm(slim), r_arm_out(slim), 0.25),
        ([4., 12., -2.], [4. + aw, 24., 2.], l_arm(slim), l_arm_out(slim), 0.25),
        ([-4., 0., -2.], [0., 12., 2.], R_LEG, R_LEG_OUT, 0.25),
        ([0., 0., -2.], [4., 12., 2.], L_LEG, L_LEG_OUT, 0.25),
    ];
    let mut v = Vec::new();
    for (min, max, base, outer, e) in parts {
        v.push(Solid { min, max, b: base, cape: false });
        let (omin, omax) = inflate(min, max, e);
        v.push(Solid { min: omin, max: omax, b: outer, cape: false });
    }
    if with_cape {
        v.push(Solid { min: [-5., 8., -3.2], max: [5., 24., -2.3], b: bx(0, 0, 10, 16, 1), cape: true });
    }
    v
}

/// Onde o raio entra na caixa: a distância e a face (eixo, lado).
fn hit(o: [f32; 3], d: [f32; 3], s: &Solid) -> Option<(f32, usize, bool)> {
    let (mut tn, mut tf) = (f32::NEG_INFINITY, f32::INFINITY);
    let mut face = (0usize, false);
    for i in 0..3 {
        if d[i].abs() < 1e-6 {
            if o[i] < s.min[i] || o[i] > s.max[i] {
                return None;
            }
            continue;
        }
        let inv = 1. / d[i];
        let (mut a, mut b) = ((s.min[i] - o[i]) * inv, (s.max[i] - o[i]) * inv);
        let mut max_side = false;
        if a > b {
            std::mem::swap(&mut a, &mut b);
            max_side = true;
        }
        if a > tn {
            tn = a;
            face = (i, max_side);
        }
        tf = tf.min(b);
    }
    (tn <= tf && tf >= 0. && tn.is_finite()).then_some((tn, face.0, face.1))
}

fn texel(img: &RgbaImage, x: f32, y: f32, r: Rect) -> Rgba<u8> {
    let px = (x.floor().max(r.0 as f32) as u32).min(r.0 + r.2 - 1);
    let py = (y.floor().max(r.1 as f32) as u32).min(r.1 + r.3 - 1);
    *img.get_pixel(px.min(img.width() - 1), py.min(img.height() - 1))
}

fn color_at(
    s: &Solid,
    axis: usize,
    max_side: bool,
    p: [f32; 3],
    skin: &RgbaImage,
    cape: Option<&RgbaImage>,
) -> Option<Rgba<u8>> {
    let size = [s.max[0] - s.min[0], s.max[1] - s.min[1], s.max[2] - s.min[2]];
    let fy = ((s.max[1] - p[1]) / size[1]).clamp(0., 1.);
    let Bx { u, v, w, h, d } = s.b;
    let (wf, hf, df) = (w as f32, h as f32, d as f32);
    if s.cape {
        let cape = cape?;
        let c = match (axis, max_side) {
            // De costas: o lado de fora da capa.
            (2, false) => {
                let fx = ((s.max[0] - p[0]) / size[0]).clamp(0., 1.);
                texel(cape, 1. + fx * 10., 1. + fy * 16., (1, 1, 10, 16))
            }
            // De frente: o lado de dentro.
            (2, true) => {
                let fx = ((p[0] - s.min[0]) / size[0]).clamp(0., 1.);
                texel(cape, 12. + fx * 10., 1. + fy * 16., (12, 1, 10, 16))
            }
            (0, true) => texel(cape, 11., 1. + fy * 16., (11, 1, 1, 16)),
            (0, false) => texel(cape, 0., 1. + fy * 16., (0, 1, 1, 16)),
            _ => return None,
        };
        return (c[3] > 0).then_some(c);
    }
    let (tx, ty, rect) = match (axis, max_side) {
        (2, true) => {
            let fx = ((p[0] - s.min[0]) / size[0]).clamp(0., 1.);
            ((u + d) as f32 + fx * wf, (v + d) as f32 + fy * hf, (u + d, v + d, w, h))
        }
        (2, false) => {
            let fx = ((s.max[0] - p[0]) / size[0]).clamp(0., 1.);
            ((u + 2 * d + w) as f32 + fx * wf, (v + d) as f32 + fy * hf, (u + 2 * d + w, v + d, w, h))
        }
        (0, true) => {
            let fx = ((s.max[2] - p[2]) / size[2]).clamp(0., 1.);
            ((u + d + w) as f32 + fx * df, (v + d) as f32 + fy * hf, (u + d + w, v + d, d, h))
        }
        (0, false) => {
            let fx = ((p[2] - s.min[2]) / size[2]).clamp(0., 1.);
            (u as f32 + fx * df, (v + d) as f32 + fy * hf, (u, v + d, d, h))
        }
        _ => return None,
    };
    let c = texel(skin, tx, ty, rect);
    (c[3] > 0).then_some(c)
}

/// Desenha o personagem com `skin` (64x64) e `cape` (64x32) vistos por `view`: a projeção é
/// ortogonal e cada ponto lê a textura da skin como o jogo lê, então o que se vê é o que o jogo
/// mostra, de frente, de lado ou de costas.
pub fn render(skin: &RgbaImage, cape: Option<&RgbaImage>, slim: bool, view: &View) -> RgbaImage {
    let width = (view.w * view.scale).round().max(1.) as u32;
    let height = (view.h * view.scale).round().max(1.) as u32;
    let mut out = RgbaImage::new(width, height);
    let list = solids(slim, cape.is_some());
    let th = (view.yaw as f32).to_radians();
    let (sin, cos) = th.sin_cos();
    let dir = [-sin, 0., -cos];
    for iy in 0..height {
        let y = view.y0 - (iy as f32 + 0.5) / view.scale;
        for ix in 0..width {
            let x = view.x0 + (ix as f32 + 0.5) / view.scale;
            // A câmera olha para -z a partir de z = 60; gira-se o raio para o espaço do modelo.
            let z = 60.;
            let o = [x * cos + z * sin, y, -x * sin + z * cos];
            let mut best: Option<(f32, Rgba<u8>)> = None;
            for s in &list {
                let Some((t, axis, max_side)) = hit(o, dir, s) else { continue };
                if best.is_some_and(|(bt, _)| bt <= t) {
                    continue;
                }
                let p = [o[0] + dir[0] * t, o[1], o[2] + dir[2] * t];
                if let Some(c) = color_at(s, axis, max_side, p, skin, cape) {
                    best = Some((t, c));
                }
            }
            if let Some((_, c)) = best {
                out.put_pixel(ix, iy, c);
            }
        }
    }
    out
}

impl Store {
    /// A miniatura de uma peça: ela vestida no personagem padrão, no pedaço que a mostra.
    pub fn thumbnail(&self, cat: Category, id: &str) -> RgbaImage {
        let mut o = Outfit::default();
        o.set(cat, Some(id.to_string()));
        let skin = self.compose(&o);
        let cape = self.cape(&o);
        let s = 7.;
        let (yaw, x0, y0, w, h) = match cat {
            Category::Shirt => (0, -8., 26., 16., 16.),
            Category::Pants | Category::Shorts => (0, -8., 15., 16., 16.),
            Category::Shoes => (0, -5.5, 7.5, 11., 11.),
            Category::Hat | Category::Accessory => (0, -5.5, 33.5, 11., 11.),
            Category::Cape => (180, -8., 27., 16., 16.),
            Category::Skin => (0, -8., 33., 16., 16.),
        };
        render(&skin, cape.as_ref(), false, &View { yaw, x0, y0, w, h, scale: s })
    }
}

#[cfg(test)]
mod tests;
