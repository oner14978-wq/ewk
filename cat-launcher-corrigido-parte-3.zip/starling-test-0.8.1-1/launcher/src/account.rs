//! The launcher's accounts: offline only. A player picks a name and plays; there is no sign-in,
//! no ownership check and no token of any kind. The profiles (name, a UUID made from the name,
//! an optional local skin and cape) are kept by [`crate::offline_accounts`] in
//! `offline_accounts.json`.
//!
//! This module also holds the secret store (the OS keychain, a file of the launcher's own where
//! there is none, or memory): the launcher keeps its Tailscale access token there
//! (`internet.rs`). It keeps nothing for accounts.
//!
//! The game gets the player's name in `HORIZON_PLAYER_NAME`; nothing else is handed over.
pub mod session;

use crate::offline_accounts::OfflineAccounts;
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::{Mutex, OnceLock};
use std::time::Duration;

/// The keychain service name every secret is stored under.
pub const SERVICE: &str = crate::identity::KEYCHAIN_SERVICE;

// ----- The keychain --------------------------------------------------------------------------------

/// Where secrets are kept: the OS keychain, a file of the launcher's own when there is none, or
/// memory in tests.
pub trait SecretStore: Send + Sync {
    fn get(&self, key: &str) -> Result<Option<String>, String>;
    fn set(&self, key: &str, secret: &str) -> Result<(), String>;
    fn delete(&self, key: &str) -> Result<(), String>;
    /// False for memory: secrets are gone when the launcher closes.
    fn persistent(&self) -> bool;
    /// A shared lock for read/renew/write operations; memory stores need only the process lock.
    fn lock_file(&self) -> Option<PathBuf> {
        None
    }
    /// The in-process half of that lock. The system keychain is one per computer, so every
    /// handle to it shares the process-wide lock; a memory store's secrets are its own, and so
    /// is its lock: two of them (one per unit test) never wait for each other.
    fn operations(&self) -> &Mutex<()> {
        session::process_lock()
    }
}

#[derive(Default)]
pub struct MemoryStore(Mutex<HashMap<String, String>>, Mutex<()>);
impl SecretStore for MemoryStore {
    fn get(&self, key: &str) -> Result<Option<String>, String> {
        Ok(self.0.lock().unwrap().get(key).cloned())
    }
    fn set(&self, key: &str, secret: &str) -> Result<(), String> {
        self.0.lock().unwrap().insert(key.into(), secret.into());
        Ok(())
    }
    fn delete(&self, key: &str) -> Result<(), String> {
        self.0.lock().unwrap().remove(key);
        Ok(())
    }
    fn persistent(&self) -> bool {
        false
    }
    fn operations(&self) -> &Mutex<()> {
        &self.1
    }
}

/// How long a call to the system keyring may take before the launcher gives up on it (#12179). An
/// unlock prompt the player is typing a password into counts as an answer still coming, so this is
/// longer than a working keyring ever takes, short enough that Play says what is wrong.
pub const KEYCHAIN_WAIT: Duration = Duration::from_secs(20);

/// What the launcher says when the system keyring didn't answer within `wait`.
pub fn keyring_no_answer(wait: Duration) -> String {
    crate::i18n::trf(
        "Your system keyring didn't answer within {seconds} seconds. Make sure it is running and unlocked, then restart the launcher.",
        &[("seconds", &wait.as_secs().max(1).to_string())],
    )
}

/// One call to a [`Bounded`] keyring: its answer, or that the caller gave up on it.
struct Call<T> {
    answer: Option<T>,
    gave_up: bool,
}

/// A keyring whose calls give up after `wait` (#12179): a Secret Service that never answers (a
/// stuck KWallet or GNOME Keyring daemon) otherwise holds the account lock forever, and Play stays
/// on "Starting…" with nothing said. Each call runs on a thread of its own; one given up on keeps
/// running there, and while it does, later calls fail at once instead of piling up behind it.
pub struct Bounded {
    keyring: std::sync::Arc<dyn SecretStore>,
    wait: Duration,
    /// Calls given up on that haven't come back yet.
    stuck: std::sync::Arc<std::sync::atomic::AtomicUsize>,
}

impl Bounded {
    pub fn new(keyring: impl SecretStore + 'static, wait: Duration) -> Self {
        Self {
            keyring: std::sync::Arc::new(keyring),
            wait,
            stuck: Default::default(),
        }
    }

    fn call<T: Send + 'static>(
        &self,
        f: impl FnOnce(&dyn SecretStore) -> Result<T, String> + Send + 'static,
    ) -> Result<T, String> {
        use std::sync::atomic::Ordering::SeqCst;
        let no_answer = || {
            let said = keyring_no_answer(self.wait);
            eprintln!("Horizon: {said}");
            Err(said)
        };
        if self.stuck.load(SeqCst) > 0 {
            return no_answer();
        }
        let call = std::sync::Arc::new((
            Mutex::new(Call::<Result<T, String>> {
                answer: None,
                gave_up: false,
            }),
            std::sync::Condvar::new(),
        ));
        let (keyring, stuck, theirs) = (self.keyring.clone(), self.stuck.clone(), call.clone());
        let spawned = std::thread::Builder::new()
            .name("keyring".into())
            .spawn(move || {
                let answer = f(keyring.as_ref());
                let (slot, done) = &*theirs;
                let mut slot = slot.lock().unwrap_or_else(|e| e.into_inner());
                if slot.gave_up {
                    stuck.fetch_sub(1, SeqCst);
                } else {
                    slot.answer = Some(answer);
                    done.notify_one();
                }
            });
        if let Err(e) = spawned {
            return Err(e.to_string());
        }
        let (slot, done) = &*call;
        let slot = slot.lock().unwrap_or_else(|e| e.into_inner());
        let (mut slot, _) = done
            .wait_timeout_while(slot, self.wait, |call| call.answer.is_none())
            .unwrap_or_else(|e| e.into_inner());
        if let Some(answer) = slot.answer.take() {
            return answer;
        }
        // Under the call's lock: the thread, when it ends, sees this and counts itself back.
        slot.gave_up = true;
        self.stuck.fetch_add(1, SeqCst);
        drop(slot);
        no_answer()
    }
}

impl SecretStore for Bounded {
    fn get(&self, key: &str) -> Result<Option<String>, String> {
        let key = key.to_string();
        self.call(move |keyring| keyring.get(&key))
    }
    fn set(&self, key: &str, secret: &str) -> Result<(), String> {
        let (key, secret) = (key.to_string(), secret.to_string());
        self.call(move |keyring| keyring.set(&key, &secret))
    }
    fn delete(&self, key: &str) -> Result<(), String> {
        let key = key.to_string();
        self.call(move |keyring| keyring.delete(&key))
    }
    fn persistent(&self) -> bool {
        self.keyring.persistent()
    }
    fn lock_file(&self) -> Option<PathBuf> {
        self.keyring.lock_file()
    }
    fn operations(&self) -> &Mutex<()> {
        self.keyring.operations()
    }
}

/// The secrets file in the launcher's data folder, when no keychain answers (#5095): many Linux
/// systems run no Secret Service, and sign-ins would otherwise last one run. One JSON object, key
/// to secret, encrypted with a key of this computer's ([`seal`]), readable and writable by the
/// player only (0600 on Unix), replaced whole on every write. A lock file beside it keeps each read-modify-replace whole across every launcher and CLI
/// process. The keychain takes its secrets back at the first start it answers ([`Layered`]).
pub struct FileStore {
    path: PathBuf,
}

/// The secrets file's name in the launcher's data folder.
pub const SECRETS_FILE: &str = "account-secrets.json";

impl FileStore {
    pub fn new(path: PathBuf) -> Self {
        Self { path }
    }

    /// The launcher's own: [`SECRETS_FILE`] in its data folder.
    pub fn launcher() -> Self {
        Self::new(crate::backend::data_dir().join(SECRETS_FILE))
    }

    fn shown(&self, e: std::io::Error) -> String {
        format!("{}: {e}", self.path.display())
    }

    /// Runs `f` holding the file's lock (`account-secrets.lock`): other processes wait.
    fn locked<T>(&self, f: impl FnOnce() -> Result<T, String>) -> Result<T, String> {
        self.holding("lock", f)
    }

    /// Runs `f` holding the lock file `account-secrets.<name>`, made if need be.
    fn holding<T>(&self, name: &str, f: impl FnOnce() -> Result<T, String>) -> Result<T, String> {
        if let Some(dir) = self.path.parent() {
            std::fs::create_dir_all(dir).map_err(|e| self.shown(e))?;
        }
        let lock = std::fs::OpenOptions::new()
            .create(true)
            .truncate(false)
            .write(true)
            .open(self.path.with_extension(name))
            .map_err(|e| self.shown(e))?;
        lock.lock().map_err(|e| self.shown(e))?;
        // Closing the file releases the lock, after `f` whatever it answers.
        f()
    }

    /// Whether the file holds a sign-in: not only sign-out marks, and readable.
    fn holds_secrets(&self) -> bool {
        self.entries()
            .is_ok_and(|secrets| secrets.values().any(|secret| secret != SIGNED_OUT))
    }

    fn read(&self) -> Result<std::collections::BTreeMap<String, String>, String> {
        match std::fs::read(&self.path) {
            // Only where the file breaks: serde's own message can quote what the file holds.
            Ok(bytes) => {
                let (json, old) = self.unseal(&bytes)?.ok_or_else(|| {
                    format!(
                        "{} can't be read on this computer: it was written on another one, or changed. \
                         Remove it and sign in again.",
                        self.path.display()
                    )
                })?;
                let secrets = serde_json::from_slice(&json).map_err(|e| {
                    format!(
                        "{} can't be read ({:?} error at line {}, column {}).",
                        self.path.display(),
                        e.classify(),
                        e.line(),
                        e.column()
                    )
                })?;
                // Sealed under the old key: sealed again under this install's. Every read runs
                // under the lock; a write that fails leaves the old file, read again next time.
                if old {
                    let _ = self.write(&secrets);
                }
                Ok(secrets)
            }
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(Default::default()),
            Err(e) => Err(self.shown(e)),
        }
    }

    /// Replaces the file with `secrets` through a temporary file of this write's own beside it, so
    /// a crash leaves the old file or the new one; removes it when there are none left.
    fn write(&self, secrets: &std::collections::BTreeMap<String, String>) -> Result<(), String> {
        if secrets.is_empty() {
            return match std::fs::remove_file(&self.path) {
                Err(e) if e.kind() != std::io::ErrorKind::NotFound => Err(self.shown(e)),
                _ => Ok(()),
            };
        }
        static WRITES: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
        let n = WRITES.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        let tmp = self
            .path
            .with_extension(format!("json.{}.{n}.tmp", std::process::id()));
        let json = serde_json::to_vec(secrets).map_err(|e| e.to_string())?;
        let sealed = self.seal(&json)?;
        let mut options = std::fs::OpenOptions::new();
        options.write(true).create_new(true);
        #[cfg(unix)]
        std::os::unix::fs::OpenOptionsExt::mode(&mut options, 0o600);
        let written = options.open(&tmp).and_then(|mut file| {
            std::io::Write::write_all(&mut file, &sealed)?;
            file.sync_all()
        });
        if let Err(e) = written.and_then(|()| std::fs::rename(&tmp, &self.path)) {
            let _ = std::fs::remove_file(&tmp);
            return Err(self.shown(e));
        }
        Ok(())
    }

    /// The file's entry for `key`, if the file is there.
    fn entry(&self, key: &str) -> Result<Option<String>, String> {
        if !self.path.exists() {
            return Ok(None);
        }
        self.locked(|| Ok(self.read()?.remove(key)))
    }

    /// Everything the file holds, if it is there.
    fn entries(&self) -> Result<std::collections::BTreeMap<String, String>, String> {
        if !self.path.exists() {
            return Ok(Default::default());
        }
        self.locked(|| self.read())
    }

    fn put(&self, key: &str, value: &str) -> Result<(), String> {
        self.locked(|| {
            let mut secrets = self.read()?;
            secrets.insert(key.into(), value.into());
            self.write(&secrets)
        })
    }

    /// The keychain took `key`: removes its entry if it still holds `before`, what was read before
    /// the keychain call. Whether the file still has an entry for it: one another process wrote
    /// since stays, and is read first.
    fn settle(&self, key: &str, before: Option<&str>) -> Result<bool, String> {
        if !self.path.exists() {
            return Ok(false);
        }
        self.locked(|| {
            let mut secrets = self.read()?;
            if before.is_some() && secrets.get(key).map(String::as_str) == before {
                secrets.remove(key);
                self.write(&secrets)?;
                return Ok(false);
            }
            Ok(secrets.contains_key(key))
        })
    }

    /// The install's own secret beside the file (`account-secrets.key`): 32 random bytes, readable
    /// and writable by the player only, made at the first write when `make`. `None` when it isn't
    /// there and not made.
    fn install_secret(&self, make: bool) -> Result<Option<[u8; 32]>, String> {
        let path = self.path.with_extension("key");
        match std::fs::read(&path) {
            Ok(bytes) => <[u8; 32]>::try_from(bytes).map(Some).map_err(|_| {
                format!(
                    "{} is damaged. Remove it and {} and sign in again.",
                    path.display(),
                    self.path.display()
                )
            }),
            Err(e) if e.kind() == std::io::ErrorKind::NotFound && make => {
                let mut secret = [0u8; 32];
                getrandom::fill(&mut secret).map_err(|e| e.to_string())?;
                // Whole or not at all, as the secrets file: a temporary file, then a rename.
                let tmp = path.with_extension(format!("key.{}.tmp", std::process::id()));
                let mut options = std::fs::OpenOptions::new();
                options.write(true).create_new(true);
                #[cfg(unix)]
                std::os::unix::fs::OpenOptionsExt::mode(&mut options, 0o600);
                let written = options.open(&tmp).and_then(|mut file| {
                    std::io::Write::write_all(&mut file, &secret)?;
                    file.sync_all()
                });
                if let Err(e) = written.and_then(|()| std::fs::rename(&tmp, &path)) {
                    let _ = std::fs::remove_file(&tmp);
                    return Err(format!("{}: {e}", path.display()));
                }
                Ok(Some(secret))
            }
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => Ok(None),
            Err(e) => Err(format!("{}: {e}", path.display())),
        }
    }

    /// `json` sealed for the file ([`SEALED`]), under [`file_key`] with this install's secret.
    fn seal(&self, json: &[u8]) -> Result<Vec<u8>, String> {
        use chacha20poly1305::{aead::Aead, KeyInit};
        let key = file_key(&self.install_secret(true)?.expect("made"));
        let mut nonce = [0u8; 12];
        getrandom::fill(&mut nonce).map_err(|e| e.to_string())?;
        let sealed = chacha20poly1305::ChaCha20Poly1305::new(&key)
            .encrypt(&nonce.into(), json)
            .map_err(|_| "the secrets couldn't be sealed".to_string())?;
        Ok([SEALED, &nonce, &sealed].concat())
    }

    /// What [`Self::seal`] sealed, and whether it was sealed in format 1 ([`SEALED_V1`]), to seal
    /// again; `None` for a file in another format, changed, sealed on another computer or by
    /// another install, or whose install secret is gone.
    fn unseal(&self, bytes: &[u8]) -> Result<Option<(Vec<u8>, bool)>, String> {
        use chacha20poly1305::{aead::Aead, KeyInit};
        let (key, old, rest) = if let Some(rest) = bytes.strip_prefix(SEALED) {
            let Some(secret) = self.install_secret(false)? else {
                return Ok(None);
            };
            (file_key(&secret), false, rest)
        } else if let Some(rest) = bytes.strip_prefix(SEALED_V1) {
            (file_key_v1(), true, rest)
        } else {
            return Ok(None);
        };
        let Some((nonce, sealed)) = rest.split_at_checked(12) else {
            return Ok(None);
        };
        let nonce: [u8; 12] = nonce.try_into().expect("12 bytes");
        Ok(chacha20poly1305::ChaCha20Poly1305::new(&key)
            .decrypt(&nonce.into(), sealed)
            .ok()
            .map(|json| (json, old)))
    }
}

/// The secrets file's first bytes: format 2, the JSON sealed with ChaCha20-Poly1305 under
/// [`file_key`], then a random 12-byte nonce and the ciphertext with its tag.
const SEALED: &[u8] = b"HZSECv2\n";

/// Format 1, sealed under [`file_key_v1`]: still read, and sealed again in format 2 at once.
const SEALED_V1: &[u8] = b"HZSECv1\n";

/// This computer's identity: `/etc/machine-id` on Linux, `/etc/hostid` on FreeBSD.
fn machine_id() -> Option<Vec<u8>> {
    ["/etc/machine-id", "/var/lib/dbus/machine-id", "/etc/hostid"]
        .iter()
        .find_map(|path| std::fs::read(path).ok())
        .map(|id| id.trim_ascii().to_vec())
}

/// The secrets file's key: a constant of the launcher's, this computer's identity and the install's
/// own random secret (`account-secrets.key`, 0600). The tokens are never on disk in plain text,
/// and the key is never something every local user can work out (the machine id is readable by
/// all, and some systems have none): it takes the install secret, which only the player can read.
/// The file's mode (0600) is still what keeps other users out; the secret means a copy of the file
/// alone, or one left readable by others while the secret wasn't, can't be read either.
fn file_key(install_secret: &[u8; 32]) -> chacha20poly1305::Key {
    use sha2::Digest;
    let mut hash = sha2::Sha256::new();
    hash.update(b"horizon-launcher account-secrets v2");
    let id = machine_id().unwrap_or_default();
    hash.update((id.len() as u64).to_le_bytes());
    hash.update(&id);
    hash.update(install_secret);
    hash.finalize()
}

/// Format 1's key, only to read a file sealed before format 2: the constant and the machine id,
/// which anyone on the computer can read (the bare constant where there is none).
fn file_key_v1() -> chacha20poly1305::Key {
    use sha2::Digest;
    let mut hash = sha2::Sha256::new();
    hash.update(b"horizon-launcher account-secrets v1");
    if let Some(id) = machine_id() {
        hash.update(id);
    }
    hash.finalize()
}

/// A file entry for an account signed out while the keychain was away: the keychain's copy, if any,
/// counts as gone, and goes at the first start it answers.
const SIGNED_OUT: &str = "";

impl SecretStore for FileStore {
    fn get(&self, key: &str) -> Result<Option<String>, String> {
        self.locked(|| Ok(self.read()?.remove(key)))
    }
    fn set(&self, key: &str, secret: &str) -> Result<(), String> {
        self.locked(|| {
            let mut secrets = self.read()?;
            secrets.insert(key.into(), secret.into());
            self.write(&secrets)
        })
    }
    fn delete(&self, key: &str) -> Result<(), String> {
        self.locked(|| {
            let mut secrets = self.read()?;
            if secrets.remove(key).is_none() {
                return Ok(());
            }
            self.write(&secrets)
        })
    }
    fn persistent(&self) -> bool {
        true
    }
}

/// The Secret Service (GNOME Keyring, KWallet) through oo7, as gpui itself uses it.
#[cfg(any(target_os = "linux", target_os = "freebsd"))]
pub struct SystemStore;
#[cfg(any(target_os = "linux", target_os = "freebsd"))]
impl SystemStore {
    fn keyring() -> Result<oo7::Keyring, String> {
        futures_lite::future::block_on(async {
            // `oo7::Keyring::new` takes `GTK_USE_PORTAL=1` (set by many KDE desktops) for a
            // sandbox, and then keeps the secrets in a file under a key the Secret portal gives
            // per app id. Outside a sandbox that id comes from how the launcher was started (the
            // menu or a terminal), so the file opened in one start and not the next (#3249).
            // Flatpak (`/.flatpak-info`) and Snap (`$SNAP`) keep the portal's file.
            let sandboxed =
                Path::new("/.flatpak-info").exists() || std::env::var_os("SNAP").is_some();
            let keyring = if sandboxed {
                oo7::Keyring::new().await.map_err(|e| e.to_string())?
            } else {
                let service = oo7::dbus::Service::new().await.map_err(|e| e.to_string())?;
                oo7::Keyring::DBus(
                    service
                        .default_collection()
                        .await
                        .map_err(|e| e.to_string())?,
                )
            };
            keyring.unlock().await.map_err(|e| e.to_string())?;
            Ok(keyring)
        })
    }
}
#[cfg(any(target_os = "linux", target_os = "freebsd"))]
impl SecretStore for SystemStore {
    fn get(&self, key: &str) -> Result<Option<String>, String> {
        let keyring = Self::keyring()?;
        futures_lite::future::block_on(async {
            let attributes = vec![("service", SERVICE), ("account", key)];
            let items = keyring
                .search_items(&attributes)
                .await
                .map_err(|e| e.to_string())?;
            let Some(item) = items.into_iter().next() else {
                return Ok(None);
            };
            item.unlock().await.map_err(|e| e.to_string())?;
            let secret = item.secret().await.map_err(|e| e.to_string())?;
            Ok(String::from_utf8(secret.to_vec()).ok())
        })
    }
    fn set(&self, key: &str, secret: &str) -> Result<(), String> {
        let keyring = Self::keyring()?;
        futures_lite::future::block_on(async {
            let attributes = vec![("service", SERVICE), ("account", key)];
            keyring
                .create_item(
                    "Horizon launcher: Minecraft account",
                    &attributes,
                    secret.as_bytes(),
                    true,
                )
                .await
                .map_err(|e| e.to_string())
        })
    }
    fn delete(&self, key: &str) -> Result<(), String> {
        let keyring = Self::keyring()?;
        futures_lite::future::block_on(async {
            let attributes = vec![("service", SERVICE), ("account", key)];
            keyring.delete(&attributes).await.map_err(|e| e.to_string())
        })
    }
    fn persistent(&self) -> bool {
        true
    }
    fn lock_file(&self) -> Option<PathBuf> {
        Some(crate::backend::data_dir().join("account-session.lock"))
    }
}

/// Keychain on macOS, Credential Manager on Windows (the keyring crate). Credential Manager takes at
/// most 2560 bytes of UTF-16 per item and a sign-in's secrets are longer, so on Windows a secret is
/// kept in pieces: the first under the account's key, the rest under `key.1`, `key.2`... The
/// Keychain has no such limit, and every item is a consent prompt for a launcher signature it
/// doesn't know yet — pieces meant several prompts after every self-update (#4912) — so on macOS a
/// secret is one item, and pieces an older launcher left fold into it as they are read.
#[cfg(any(target_os = "macos", target_os = "windows"))]
pub struct SystemStore;

/// Bytes of UTF-8 per keychain item: at most twice as many in UTF-16, well under 2560.
#[cfg(any(target_os = "windows", test))]
const PIECE: usize = 1000;

#[cfg(any(target_os = "macos", target_os = "windows", test))]
fn piece_key(key: &str, n: usize) -> String {
    if n == 0 {
        key.to_string()
    } else {
        format!("{key}.{n}")
    }
}

/// `secret` cut into pieces of at most `PIECE` bytes, on character boundaries.
#[cfg(any(target_os = "windows", test))]
fn split_secret(mut secret: &str) -> Vec<&str> {
    let mut pieces = Vec::new();
    while secret.len() > PIECE {
        let mut cut = PIECE;
        while !secret.is_char_boundary(cut) {
            cut -= 1;
        }
        let (head, tail) = secret.split_at(cut);
        pieces.push(head);
        secret = tail;
    }
    pieces.push(secret);
    pieces
}

/// One keychain item per key: what a secret's pieces are kept in.
#[cfg(any(target_os = "macos", target_os = "windows", test))]
trait Items {
    fn read(&self, key: &str) -> Result<Option<String>, String>;
    fn write(&self, key: &str, piece: &str) -> Result<(), String>;
    /// Removes one item; false when there was none.
    fn remove(&self, key: &str) -> Result<bool, String>;
}

#[cfg(any(target_os = "windows", test))]
fn get_pieces(items: &dyn Items, key: &str) -> Result<Option<String>, String> {
    let Some(mut secret) = items.read(key)? else {
        return Ok(None);
    };
    for n in 1.. {
        match items.read(&piece_key(key, n))? {
            Some(piece) => secret.push_str(&piece),
            None => break,
        }
    }
    Ok(Some(secret))
}

#[cfg(any(target_os = "windows", test))]
fn set_pieces(items: &dyn Items, key: &str, secret: &str) -> Result<(), String> {
    let before = get_pieces(items, key).ok().flatten();
    let pieces = split_secret(secret);
    for (n, piece) in pieces.iter().enumerate() {
        if let Err(e) = items.write(&piece_key(key, n), piece) {
            // New pieces before old ones read back as no secret at all (the account would be
            // signed out at the next start): the old secret goes back, which fit before.
            if n > 0 {
                let _ = delete_pieces(items, key);
                if let Some(before) = &before {
                    for (n, piece) in split_secret(before).iter().enumerate() {
                        let _ = items.write(&piece_key(key, n), piece);
                    }
                }
            }
            return Err(e);
        }
    }
    // Pieces left over from a longer secret would be read back as part of this one.
    for n in pieces.len().. {
        match items.remove(&piece_key(key, n)) {
            Ok(true) => {}
            Ok(false) => break,
            Err(e) => {
                // Some leftovers are already gone, some are still there: the old secret goes back
                // whole, as on a refused write above.
                let _ = delete_pieces(items, key);
                if let Some(before) = &before {
                    for (n, piece) in split_secret(before).iter().enumerate() {
                        let _ = items.write(&piece_key(key, n), piece);
                    }
                }
                return Err(e);
            }
        }
    }
    Ok(())
}

#[cfg(any(target_os = "macos", target_os = "windows", test))]
fn delete_pieces(items: &dyn Items, key: &str) -> Result<(), String> {
    for n in 0.. {
        if !items.remove(&piece_key(key, n))? {
            break;
        }
    }
    Ok(())
}

/// One item per key, the whole secret in it (macOS). A secret an older launcher split over `key.1`,
/// `key.2`, ... reads whole and folds into the one item, so a read touches a single item — and asks
/// once — from then on. A merged item also reads fine as "piece 0" to launchers that still split.
#[cfg(any(target_os = "macos", test))]
fn get_item(items: &dyn Items, key: &str) -> Result<Option<String>, String> {
    let Some(mut secret) = items.read(key)? else {
        return Ok(None);
    };
    let mut split = false;
    for n in 1.. {
        match items.read(&piece_key(key, n))? {
            Some(piece) => {
                secret.push_str(&piece);
                split = true;
            }
            None => break,
        }
    }
    if split {
        let _ = set_item(items, key, &secret);
    }
    Ok(Some(secret))
}

/// Writes `secret` to `key` and removes `key.1`, `key.2`, ... pieces an older, split secret left:
/// they would read back as part of this one. A removal the keychain refuses puts the old items
/// back: the merged secret beside the pieces left would read as a longer, unparseable one, and
/// pieces removed before the failure can't be had again except from here.
#[cfg(any(target_os = "macos", test))]
fn set_item(items: &dyn Items, key: &str, secret: &str) -> Result<(), String> {
    let mut before = Vec::new();
    if let Some(piece) = items.read(key)? {
        before.push((key.to_string(), piece));
        for n in 1.. {
            match items.read(&piece_key(key, n))? {
                Some(piece) => before.push((piece_key(key, n), piece)),
                None => break,
            }
        }
    }
    items.write(key, secret)?;
    for n in 1.. {
        match items.remove(&piece_key(key, n)) {
            Ok(true) => {}
            Ok(false) => break,
            Err(e) => {
                if before.is_empty() {
                    let _ = items.remove(key);
                } else {
                    for (key, piece) in &before {
                        let _ = items.write(key, piece);
                    }
                }
                return Err(e);
            }
        }
    }
    Ok(())
}

/// Credential Manager's error 8 (`ERROR_NOT_ENOUGH_MEMORY`) on a write: not the computer's memory,
/// the player's credential store is full (an undocumented limit of its total size). The Xbox app
/// and the Minecraft Launcher are known to leave hundreds of items there (#4313, #4366).
#[cfg(any(target_os = "windows", test))]
pub const CREDENTIAL_MANAGER_FULL: &str = "Windows Credential Manager is full, so Horizon can't \
     keep your sign-in (Windows error 8; it isn't your computer's memory). Open Credential Manager \
     from the Start menu, go to Windows Credentials and remove entries you no longer use, then sign \
     in again. The Xbox app and the Minecraft Launcher often leave many XblGrts and Xbl| entries \
     there; removing an entry can sign the app that made it out.";

/// What the launcher says for a Windows error code Credential Manager gave when writing an item,
/// when it says more than the code.
#[cfg(any(target_os = "windows", test))]
fn credential_manager_says(code: u32) -> Option<&'static str> {
    const ERROR_NOT_ENOUGH_MEMORY: u32 = 8;
    (code == ERROR_NOT_ENOUGH_MEMORY).then_some(CREDENTIAL_MANAGER_FULL)
}

/// A running executable removed by an older macOS updater cannot create Keychain credentials.
#[cfg(any(target_os = "macos", test))]
pub const MACOS_LAUNCHER_RESTART: &str = "The launcher was updated while it was running. Restart the launcher, then try again.";

#[cfg(any(target_os = "macos", test))]
fn macos_keychain_says(code: i32) -> Option<&'static str> {
    // CSSM's Unix ENOENT: Keychain cannot identify an executable removed by an older updater.
    (code == 100002).then_some(MACOS_LAUNCHER_RESTART)
}

/// The keyring crate's error as the player reads it.
#[cfg(any(target_os = "macos", target_os = "windows"))]
fn write_error(e: keyring::Error) -> String {
    #[cfg(target_os = "macos")]
    if let keyring::Error::PlatformFailure(inner) = &e {
        if let Some(said) = inner
            .downcast_ref::<security_framework::base::Error>()
            .and_then(|error| macos_keychain_says(error.code()))
        {
            return said.to_string();
        }
    }
    #[cfg(target_os = "windows")]
    if let keyring::Error::PlatformFailure(inner) = &e {
        if let Some(said) = inner
            .downcast_ref::<keyring::windows::Error>()
            .and_then(|code| credential_manager_says(code.0))
        {
            return said.to_string();
        }
    }
    e.to_string()
}

/// The OS keychain's items, under [`SERVICE`].
#[cfg(any(target_os = "macos", target_os = "windows"))]
struct KeyringItems;

#[cfg(any(target_os = "macos", target_os = "windows"))]
impl Items for KeyringItems {
    fn read(&self, key: &str) -> Result<Option<String>, String> {
        match keyring::Entry::new(SERVICE, key).and_then(|e| e.get_password()) {
            Ok(secret) => Ok(Some(secret)),
            Err(keyring::Error::NoEntry) => Ok(None),
            Err(e) => Err(e.to_string()),
        }
    }
    fn write(&self, key: &str, piece: &str) -> Result<(), String> {
        keyring::Entry::new(SERVICE, key)
            .and_then(|e| e.set_password(piece))
            .map_err(write_error)
    }
    fn remove(&self, key: &str) -> Result<bool, String> {
        match keyring::Entry::new(SERVICE, key).and_then(|e| e.delete_credential()) {
            Ok(()) => Ok(true),
            Err(keyring::Error::NoEntry) => Ok(false),
            Err(e) => Err(e.to_string()),
        }
    }
}

#[cfg(any(target_os = "macos", target_os = "windows"))]
impl SecretStore for SystemStore {
    #[cfg(target_os = "macos")]
    fn get(&self, key: &str) -> Result<Option<String>, String> {
        get_item(&KeyringItems, key)
    }
    #[cfg(target_os = "windows")]
    fn get(&self, key: &str) -> Result<Option<String>, String> {
        get_pieces(&KeyringItems, key)
    }
    #[cfg(target_os = "macos")]
    fn set(&self, key: &str, secret: &str) -> Result<(), String> {
        set_item(&KeyringItems, key, secret)
    }
    #[cfg(target_os = "windows")]
    fn set(&self, key: &str, secret: &str) -> Result<(), String> {
        set_pieces(&KeyringItems, key, secret)
    }
    fn delete(&self, key: &str) -> Result<(), String> {
        delete_pieces(&KeyringItems, key)
    }
    fn persistent(&self) -> bool {
        true
    }
    fn lock_file(&self) -> Option<PathBuf> {
        Some(crate::backend::data_dir().join("account-session.lock"))
    }
}

pub const NO_KEYCHAIN: &str = "No keychain available: you are signed in until the launcher closes, then you will have to sign in again.";

/// What the keychain answered when [`store`] fell back to memory.
static NO_KEYCHAIN_WHY: OnceLock<String> = OnceLock::new();

/// What the window and the CLI say when sign-ins last only this run: [`NO_KEYCHAIN`] and why.
/// None while the keychain keeps them.
pub fn no_keychain() -> Option<String> {
    if store().persistent() {
        return None;
    }
    Some(match NO_KEYCHAIN_WHY.get() {
        Some(why) => format!("{NO_KEYCHAIN} The keychain said: {why}"),
        None => NO_KEYCHAIN.into(),
    })
}

/// What a keychain this run stopped asking answers.
const KEYCHAIN_AWAY: &str =
    "The keychain didn't answer earlier: sign in again to keep this account.";

/// The keychain, with the secrets file for what it can't keep (#5095). Each call asks both, never a
/// choice made once: a launcher that wrote to the file while the keychain was away still finds its
/// secrets after another process handed them to the keychain. Reads take the file's copy first (it
/// is the newer one), writes go to the keychain and to the file only when it refuses.
///
/// The file's lock is never held across a keychain call, which can wait on an unlock prompt: other
/// processes keep reading and writing the file meanwhile. Every write to the keychain holds a lock of
/// its own instead (`account-secrets.keychain.lock`), with what it writes read under it, so a hand-over
/// never puts back a secret another process renewed or signed out since; only keychain writes wait
/// on a prompt, as they would on the keychain itself. A file entry is only removed if it still holds
/// what was read before the keychain call, so another process's newer write stays. And once the
/// keychain refuses or doesn't answer, this run stops asking it (no prompt after a dismissed
/// prompt), until another process hands it a secret this run saw in the file.
pub struct Layered {
    keychain: Box<dyn SecretStore>,
    file: FileStore,
    away: std::sync::atomic::AtomicBool,
    /// What this run saw in the file and didn't hand over itself: put there, read there, or there
    /// when it started. Gone from the file later, the keychain answers again (another process
    /// handed it).
    parked: Mutex<std::collections::HashSet<String>>,
}

impl Layered {
    /// Starts by handing the keychain what the file kept while it was away, one secret at a time,
    /// up to the first it refuses; sign-outs it missed are done there too. Each is read again under
    /// the keychain's lock: one another process renewed or signed out meanwhile isn't handed over.
    pub fn new(keychain: Box<dyn SecretStore>, file: FileStore) -> Self {
        let layered = Self {
            keychain,
            file,
            away: Default::default(),
            parked: Default::default(),
        };
        let keys: Vec<String> = layered
            .file
            .entries()
            .unwrap_or_default()
            .into_keys()
            .collect();
        // Seen before the hand-over starts: whatever another process hands over meanwhile, this
        // run asks the keychain for it again.
        layered.parked.lock().unwrap().extend(keys.iter().cloned());
        for key in keys {
            let handed = layered.keychain_writes(|| {
                let Some(secret) = layered.file.entry(&key)? else {
                    return Ok(());
                };
                layered.ask(|keychain| match secret.as_str() {
                    SIGNED_OUT => keychain.delete(&key),
                    _ => keychain.set(&key, &secret),
                })?;
                layered.unpark(&key, Some(secret))
            });
            if handed.is_err() {
                break;
            }
        }
        layered
    }

    /// Runs `f`, a write to the keychain and what it reads first, holding the keychain's lock.
    fn keychain_writes<T>(&self, f: impl FnOnce() -> Result<T, String>) -> Result<T, String> {
        self.file.holding("keychain.lock", f)
    }

    fn is_away(&self) -> bool {
        self.away.load(std::sync::atomic::Ordering::Relaxed)
    }

    /// Asks the keychain unless it was away; an error means it is away for the rest of the run.
    fn ask<T>(
        &self,
        call: impl FnOnce(&dyn SecretStore) -> Result<T, String>,
    ) -> Result<T, String> {
        if self.is_away() {
            return Err(KEYCHAIN_AWAY.into());
        }
        let answer = call(self.keychain.as_ref());
        if answer.is_err() {
            self.away.store(true, std::sync::atomic::Ordering::Relaxed);
        }
        answer
    }

    /// Puts `value` in the file for `key`, the keychain being away.
    fn park(&self, key: &str, value: &str) -> Result<(), String> {
        self.file.put(key, value)?;
        self.parked.lock().unwrap().insert(key.into());
        Ok(())
    }

    /// The keychain took `key`: the file's copy read before goes, unless another process wrote since.
    /// Still in the file, it stays counted as seen there, so its hand-over by another process is
    /// noticed.
    fn unpark(&self, key: &str, before: Option<String>) -> Result<(), String> {
        let still_there = self.file.settle(key, before.as_deref())?;
        let mut parked = self.parked.lock().unwrap();
        if still_there {
            parked.insert(key.into());
        } else {
            parked.remove(key);
        }
        Ok(())
    }
}

impl SecretStore for Layered {
    fn get(&self, key: &str) -> Result<Option<String>, String> {
        match self.file.entry(key)? {
            Some(secret) if secret == SIGNED_OUT => return Ok(None),
            Some(secret) => {
                self.parked.lock().unwrap().insert(key.into());
                return Ok(Some(secret));
            }
            None => {}
        }
        // Seen in the file and gone from it: another process handed it to the keychain, which
        // answers again.
        if self.is_away() && self.parked.lock().unwrap().remove(key) {
            self.away.store(false, std::sync::atomic::Ordering::Relaxed);
        }
        self.ask(|keychain| keychain.get(key))
    }
    fn set(&self, key: &str, secret: &str) -> Result<(), String> {
        if self.is_away() {
            return self.park(key, secret);
        }
        self.keychain_writes(|| {
            let before = self.file.entry(key)?;
            match self.ask(|keychain| keychain.set(key, secret)) {
                Ok(()) => self.unpark(key, before),
                Err(_) => self.park(key, secret),
            }
        })
    }
    fn delete(&self, key: &str) -> Result<(), String> {
        // The keychain may hold a copy: the mark hides it until it can go.
        if self.is_away() {
            return self.park(key, SIGNED_OUT);
        }
        self.keychain_writes(|| {
            let before = self.file.entry(key)?;
            match self.ask(|keychain| keychain.delete(key)) {
                Ok(()) => self.unpark(key, before),
                Err(_) => self.park(key, SIGNED_OUT),
            }
        })
    }
    fn persistent(&self) -> bool {
        true
    }
}

/// The OS keychain if it answers, else why not.
fn keychain_or_why() -> Result<Box<dyn SecretStore>, String> {
    // Unit tests never reach the player's keychain.
    #[cfg(all(
        not(test),
        any(
            target_os = "linux",
            target_os = "freebsd",
            target_os = "macos",
            target_os = "windows"
        )
    ))]
    {
        if std::env::var_os("HORIZON_NO_KEYCHAIN").is_some() {
            return Err("HORIZON_NO_KEYCHAIN is set.".into());
        }
        let keychain = Bounded::new(SystemStore, KEYCHAIN_WAIT);
        keychain.get("probe").map(|_| Box::new(keychain) as _)
    }
    #[cfg(not(all(
        not(test),
        any(
            target_os = "linux",
            target_os = "freebsd",
            target_os = "macos",
            target_os = "windows"
        )
    )))]
    Err("This system has no keychain.".into())
}

/// The launcher's secrets (the Tailscale token). Linux and FreeBSD: the Secret Service with the secrets file beside it
/// ([`Layered`], #5095). macOS and Windows: the keychain if it answers. Memory with
/// `HORIZON_NO_KEYCHAIN` (the launcher's own tests) or no keychain on macOS and Windows (said in the
/// UI with [`no_keychain`]).
pub fn store() -> &'static dyn SecretStore {
    static STORE: OnceLock<Box<dyn SecretStore>> = OnceLock::new();
    STORE
        .get_or_init(|| {
            #[cfg(all(not(test), any(target_os = "linux", target_os = "freebsd")))]
            if std::env::var_os("HORIZON_NO_KEYCHAIN").is_none() {
                return Box::new(Layered::new(
                    Box::new(Bounded::new(SystemStore, KEYCHAIN_WAIT)),
                    FileStore::launcher(),
                ));
            }
            keychain_or_why().unwrap_or_else(|why| {
                let _ = NO_KEYCHAIN_WHY.set(why);
                Box::<MemoryStore>::default()
            })
        })
        .as_ref()
}

/// Secrets never written to a file of the launcher's own, the Tailscale access token (it
/// administers the player's whole tailnet): the keychain if it answers, else memory for this run.
/// [`store`] itself on macOS and Windows, where that is what it is.
pub fn keychain() -> &'static dyn SecretStore {
    #[cfg(any(target_os = "linux", target_os = "freebsd"))]
    {
        static KEYCHAIN: OnceLock<Box<dyn SecretStore>> = OnceLock::new();
        KEYCHAIN
            .get_or_init(|| keychain_or_why().unwrap_or_else(|_| Box::<MemoryStore>::default()))
            .as_ref()
    }
    #[cfg(not(any(target_os = "linux", target_os = "freebsd")))]
    store()
}

/// Whether sign-ins sit in the secrets file now, the keychain having refused them (#5095): sign-out
/// marks alone, or a file that can't be read, don't count.
pub fn in_secrets_file() -> bool {
    cfg!(any(target_os = "linux", target_os = "freebsd"))
        && store().persistent()
        && FileStore::launcher().holds_secrets()
}

// ----- Accounts ------------------------------------------------------------------------------------

/// An offline profile, as the launcher shows it (no secrets exist for it).
#[derive(Clone, Debug, PartialEq)]
pub struct Account {
    /// The offline UUID without dashes.
    pub uuid: String,
    pub name: String,
    /// Always none: an offline profile has no skin on a skin server. Kept so the pages that read a
    /// skin URL still compile.
    pub skin: Option<(String, String)>,
    /// Always none, as [`Self::skin`].
    pub cape: Option<String>,
    /// The profile's own skin file, when it has one.
    pub skin_file: Option<PathBuf>,
    /// The profile's own cape file, when it has one.
    pub cape_file: Option<PathBuf>,
}

/// The saved profiles and the one that plays.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct Accounts {
    pub accounts: Vec<Account>,
    /// The UUID of the profile the game starts with.
    pub selected: Option<String>,
    offline: OfflineAccounts,
}

impl Accounts {
    fn from_offline(offline: OfflineAccounts) -> Self {
        let dir = crate::backend::data_dir();
        let accounts = offline
            .accounts
            .iter()
            .map(|a| Account {
                uuid: a.uuid.clone(),
                name: a.name.clone(),
                skin: None,
                cape: None,
                skin_file: a.skin_path(&dir),
                cape_file: a.cape_path(&dir),
            })
            .collect();
        let selected = offline.selected().map(|a| a.uuid.clone());
        Self {
            accounts,
            selected,
            offline,
        }
    }

    pub fn load() -> Self {
        Self::from_offline(OfflineAccounts::load())
    }

    pub fn save(&self) -> Result<(), String> {
        self.offline.save()
    }

    /// The profile that plays: the selected one, else the first; none while there is no profile.
    pub fn selected(&self) -> Option<&Account> {
        self.selected
            .as_ref()
            .and_then(|uuid| self.accounts.iter().find(|a| &a.uuid == uuid))
            .or_else(|| self.accounts.first())
    }

    /// A profile by name (any case) or UUID (with or without dashes).
    pub fn find(&self, who: &str) -> Option<&Account> {
        let undashed = who.replace('-', "").to_lowercase();
        self.accounts
            .iter()
            .find(|a| a.name.eq_ignore_ascii_case(who) || a.uuid == undashed)
    }

    /// Makes a profile with this name and selects it (saved by the caller with [`Self::save`]).
    pub fn create(&mut self, name: &str) -> Result<Account, String> {
        let dir = crate::backend::data_dir();
        let made = self.offline.create(&dir, name, None, None)?;
        let offline = std::mem::take(&mut self.offline);
        *self = Self::from_offline(offline);
        self.find(&made.uuid)
            .cloned()
            .ok_or_else(|| "The profile was not kept.".to_owned())
    }

    /// Plays as this profile from now on.
    pub fn play_as(&mut self, who: &str) -> Result<(), String> {
        self.offline.select(who)?;
        let offline = std::mem::take(&mut self.offline);
        *self = Self::from_offline(offline);
        Ok(())
    }

    /// Deletes a profile and its skin and cape.
    pub fn remove(&mut self, who: &str) -> Result<(), String> {
        let dir = crate::backend::data_dir();
        self.offline.remove(&dir, who)?;
        let offline = std::mem::take(&mut self.offline);
        *self = Self::from_offline(offline);
        Ok(())
    }
}

/// Removes what an older launcher kept for Microsoft accounts: their items in the keychain (or
/// the secrets file) and `accounts.json`. It asks the keychain, which can block, so not on the
/// window's thread. Nothing is read from the items and nothing is sent anywhere.
pub fn purge_legacy_microsoft() {
    let path = crate::backend::data_dir().join("accounts.json");
    let Ok(text) = std::fs::read_to_string(&path) else {
        return;
    };
    let uuids: Vec<String> = serde_json::from_str::<serde_json::Value>(&text)
        .ok()
        .and_then(|v| {
            v.get("accounts").and_then(|list| {
                list.as_array().map(|list| {
                    list.iter()
                        .filter_map(|a| a.get("uuid").and_then(|u| u.as_str()).map(str::to_owned))
                        .collect()
                })
            })
        })
        .unwrap_or_default();
    let mut all_gone = true;
    for uuid in uuids {
        if store().delete(&uuid).is_err() {
            all_gone = false;
        }
    }
    // The list stays when a secret could not be removed, so the next start tries again.
    if all_gone {
        let _ = std::fs::remove_file(path);
    }
}

// ----- The game ------------------------------------------------------------------------------------

/// What the game about to start gets from the accounts.
#[derive(Debug, Default)]
pub struct GameSession {
    /// Always none: the game gets no session file.
    pub file: Option<PathBuf>,
    /// Always none: there is nothing to renew.
    pub offline: Option<String>,
    /// The environment the game starts with: the player's name.
    pub env: Vec<(&'static str, String)>,
}

/// The game's session for the selected profile. With no profile yet, the game makes and keeps a
/// name of its own, so Play never waits for one.
pub fn session_for_game(_game_home: &Path) -> Result<GameSession, String> {
    session_for(&Accounts::load(), None)
}

/// [`session_for_game`] for one launch as `who`, without changing the selected profile.
pub fn session_for_game_as(_game_home: &Path, who: &str) -> Result<GameSession, String> {
    session_for(&Accounts::load(), Some(who))
}

fn session_for(accounts: &Accounts, who: Option<&str>) -> Result<GameSession, String> {
    let account = match who {
        Some(who) => Some(
            accounts
                .find(who)
                .ok_or_else(|| format!("No profile {who}. See `horizon-launcher account`."))?,
        ),
        None => accounts.selected(),
    };
    Ok(GameSession {
        env: account
            .map(|a| vec![("HORIZON_PLAYER_NAME", a.name.clone())])
            .unwrap_or_default(),
        ..GameSession::default()
    })
}

/// Who plays a Java instance (the real Minecraft: Java Edition): the selected profile, offline.
pub fn java_player() -> Result<crate::java_launch::Player, String> {
    let accounts = Accounts::load();
    let account = accounts
        .selected()
        .ok_or("Choose a player name first (Settings, Account).")?;
    Ok(crate::java_launch::Player {
        name: account.name.clone(),
        uuid: account.uuid.clone(),
        token: "0".to_owned(),
        xuid: String::new(),
    })
}

/// The selected profile's name for a launch, when there is one.
pub fn playing_name() -> Option<String> {
    Accounts::load().selected().map(|a| a.name.clone())
}
