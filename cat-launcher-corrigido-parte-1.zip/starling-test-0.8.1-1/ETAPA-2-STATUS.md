# ETAPA 2 - remoção do login Microsoft (EM ANDAMENTO, NÃO COMPILADO)

Nada aqui foi compilado nem testado (sem cargo no ambiente).

## Feito (por leitura/edição)
- launcher/src/account.rs reescrito: só contas offline (offline_accounts.json), cofre de segredos mantido (Tailscale usa).
  - Game recebe só HORIZON_PLAYER_NAME; sem token, sem session-file, sem checagem de dono.
  - purge_legacy_microsoft(): apaga segredos antigos + accounts.json (roda em thread no start).
- account/session.rs reduzido ao lock; join_server vira erro (Wardrobe online não funciona sem Microsoft).
- account/tests.rs removido (testes do fluxo Microsoft).
- backend.rs: download do Mojang por dono removido (download_for_owner agora só explica); teste antigo removido.
- backend/messages.rs, backend/developer_play.rs, developer_play.rs: sem NoOwner/Owner/AccountStatus.
- main.rs (parcial): campos/estado de sign-in e owner removidos, mensagens tratadas, play_press sempre libera Play.
- cat_home.rs, glass_home.rs, home.rs: Play sem gate de dono.

## FALTA (não compila ainda)
- main.rs: remover/reescrever account_rows, microsoft_rows, sign_in_parts, account_status_line, sign_in_change,
  owner_screen (render), testes de sign_in_change, preview de Account (struct literal), campos account_input/focus.
- switch_page.rs, glass_account.rs, frame.rs, private_window.rs, wardrobe_page.rs (skin/wardrobe_shown=false), heads.rs
- cli.rs e mcp.rs: subcomandos sign-in/refresh/owner; criar/listar contas offline.
- microsoft.rs, owner_page.rs, private_window.rs: apagar (+ lib.rs mod private_window).
- java_launch.rs: user_type "msa" -> "legacy"; ajustar java_launch/tests.rs.
- tests/owner_gate.rs: reescrever/remover; SIGN_IN_HINT em backend.rs.
- Textos novos em lang/*.json (teste de traduções pode exigir).
- Lado Android/jogo (starling-account, horizon-client): não tocado.
