# ETAPA 3 - nome "Cat Launcher" e ícone do gato (Android) - NÃO COMPILADO

- packaging/android/icons/cat-launcher.jpg: a imagem enviada, sem alteração.
- packaging/android/make_icons.py: gera os ícones a partir dela (só redimensiona; sem redesenhar/recolorir).
- packaging/android/res/: mipmap-m/h/xh/xxh/xxxhdpi/ic_launcher.png (imagem inteira), ic_launcher_foreground.png,
  mipmap-anydpi-v26/ic_launcher.xml (ícone adaptativo), values/ic_launcher_background.xml (#22044B, cor da imagem).
- build_apk.py: LABEL = "Cat Launcher"; variante --preview sem sufixo " Preview"; cópia do ícone antigo (horizon.png) removida.
- Textos visíveis do Android (notificação, diálogos, diagnóstico) agora dizem Cat Launcher.
- Mantidos: id do pacote io.github.juanluci.starling(.preview), nome do arquivo starling-*.apk e a pasta "Starling" no armazenamento
  (mudar quebraria atualização/dados e os scripts de release).
- .github/workflows/build-apk.yml: extrai os zips da raiz do repositório, compila e entrega Cat-Launcher-<abi>.apk.
- NÃO alterado: textos "Starling" dentro da interface do jogo (crates Rust) e o launcher de desktop.
