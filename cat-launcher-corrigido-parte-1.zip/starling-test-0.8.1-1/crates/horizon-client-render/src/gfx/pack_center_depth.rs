//! `centerDepthSmooth`'s input: `depthtex0` at the centre of the screen. A depth texture can
//! only be copied whole, so each frame a one-pixel pass loads that texel into a 1x1 `R32Uint`
//! target, copied to one of a few small buffers and read back frames later without waiting for
//! the GPU (as `timing.rs` reads its timestamps); `FrameUniforms` smooths the latest value.
//! The target holds the depth's bits, not the float: OpenGL renders to `R32Uint` everywhere
//! (GLES 3.0 core), while an `R32Float` target needs `EXT_color_buffer_float`, which llvmpipe
//! and some drivers lack (#2386).

use std::sync::Arc;
use std::sync::atomic::{AtomicU8, Ordering};

const SLOTS: usize = 3;
const FREE: u8 = 0;
/// Copied this frame: mapped once the frame is submitted.
const COPIED: u8 = 1;
const PENDING: u8 = 2;
const MAPPED: u8 = 3;
/// One row of a texture copy, the alignment wgpu asks of `bytes_per_row`.
const ROW: u32 = wgpu::COPY_BYTES_PER_ROW_ALIGNMENT;

const SHADER: &str = "
// A depth view bound as unfilterable float: naga's GLSL backend cannot
// `textureLoad` a depth texture, and the texel is the same value.
@group(0) @binding(0) var depth: texture_2d<f32>;
@vertex fn vs(@builtin(vertex_index) i: u32) -> @builtin(position) vec4<f32> {
    let p = vec2<f32>(f32((i << 1u) & 2u), f32(i & 2u));
    return vec4<f32>(p * 2.0 - 1.0, 0.0, 1.0);
}
// The depth's bits, read back as the f32 they are.
@fragment fn fs() -> @location(0) vec4<u32> {
    let centre = vec2<i32>(textureDimensions(depth) / 2u);
    return vec4<u32>(bitcast<u32>(textureLoad(depth, centre, 0).r), 0u, 0u, 1u);
}
";

struct Slot {
    buffer: wgpu::Buffer,
    state: Arc<AtomicU8>,
}

pub struct CenterDepth {
    slots: Vec<Slot>,
    pipeline: wgpu::RenderPipeline,
    layout: wgpu::BindGroupLayout,
    /// The 1x1 target the centre texel is loaded into.
    texel: wgpu::Texture,
    texel_view: wgpu::TextureView,
    /// The bind group of the depth texture it reads, made again when that texture changes.
    group: Option<(wgpu::Texture, wgpu::BindGroup)>,
    /// The depth last read back: GL window depth, 0..1.
    latest: Option<f32>,
}

impl CenterDepth {
    pub fn new(device: &wgpu::Device) -> Self {
        let slots = (0..SLOTS)
            .map(|_| Slot {
                buffer: device.create_buffer(&wgpu::BufferDescriptor {
                    label: Some("Shader pack centre depth"),
                    size: u64::from(ROW),
                    usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ,
                    mapped_at_creation: false,
                }),
                state: Arc::new(AtomicU8::new(FREE)),
            })
            .collect();
        let layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("Shader pack centre depth"),
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Texture {
                    sample_type: wgpu::TextureSampleType::Float { filterable: false },
                    view_dimension: wgpu::TextureViewDimension::D2,
                    multisampled: false,
                },
                count: None,
            }],
        });
        let module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("Shader pack centre depth"),
            source: wgpu::ShaderSource::Wgsl(SHADER.into()),
        });
        let pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("Shader pack centre depth"),
            bind_group_layouts: &[Some(&layout)],
            immediate_size: 0,
        });
        let format = wgpu::TextureFormat::R32Uint;
        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("Shader pack centre depth"),
            layout: Some(&pipeline_layout),
            vertex: wgpu::VertexState {
                module: &module,
                entry_point: Some("vs"),
                compilation_options: Default::default(),
                buffers: &[],
            },
            primitive: Default::default(),
            depth_stencil: None,
            multisample: Default::default(),
            fragment: Some(wgpu::FragmentState {
                module: &module,
                entry_point: Some("fs"),
                compilation_options: Default::default(),
                targets: &[Some(format.into())],
            }),
            multiview_mask: None,
            cache: None,
        });
        let texel = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("Shader pack centre depth"),
            size: wgpu::Extent3d {
                width: 1,
                height: 1,
                depth_or_array_layers: 1,
            },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::COPY_SRC,
            view_formats: &[],
        });
        let texel_view = texel.create_view(&Default::default());
        Self {
            slots,
            pipeline,
            layout,
            texel,
            texel_view,
            group: None,
            latest: None,
        }
    }

    /// Loads the centre texel of `depth` (a `Depth32Float` texture that can be bound) and
    /// copies it into a free slot; with none free (the GPU is behind), this frame is skipped.
    pub fn copy(
        &mut self,
        device: &wgpu::Device,
        encoder: &mut wgpu::CommandEncoder,
        depth: &wgpu::Texture,
    ) {
        let Some(slot) = self
            .slots
            .iter()
            .find(|s| s.state.load(Ordering::Acquire) == FREE)
        else {
            return;
        };
        if self.group.as_ref().is_none_or(|(t, _)| t != depth) {
            let view = depth.create_view(&Default::default());
            let group = device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: Some("Shader pack centre depth"),
                layout: &self.layout,
                entries: &[wgpu::BindGroupEntry {
                    binding: 0,
                    resource: wgpu::BindingResource::TextureView(&view),
                }],
            });
            self.group = Some((depth.clone(), group));
        }
        let Some((_, group)) = &self.group else {
            return;
        };
        {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("Shader pack centre depth"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &self.texel_view,
                    depth_slice: None,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color::WHITE),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                ..Default::default()
            });
            pass.set_pipeline(&self.pipeline);
            pass.set_bind_group(0, group, &[]);
            pass.draw(0..3, 0..1);
        }
        encoder.copy_texture_to_buffer(
            self.texel.as_image_copy(),
            wgpu::TexelCopyBufferInfo {
                buffer: &slot.buffer,
                layout: wgpu::TexelCopyBufferLayout {
                    offset: 0,
                    bytes_per_row: Some(ROW),
                    rows_per_image: Some(1),
                },
            },
            self.texel.size(),
        );
        slot.state.store(COPIED, Ordering::Release);
    }

    /// The readback of what the frame copied, to start by calling it right after the frame's
    /// submission: on the submit thread when the frame goes there, as culling's readback.
    pub fn submitted(&mut self) -> Option<impl FnOnce() + Send + 'static> {
        let copied: Vec<_> = self
            .slots
            .iter()
            .filter(|s| s.state.load(Ordering::Acquire) == COPIED)
            .map(|s| {
                s.state.store(PENDING, Ordering::Release);
                (s.buffer.clone(), s.state.clone())
            })
            .collect();
        (!copied.is_empty()).then_some(move || {
            for (buffer, state) in copied {
                buffer
                    .slice(..)
                    .map_async(wgpu::MapMode::Read, move |result| {
                        let next = if result.is_ok() { MAPPED } else { FREE };
                        state.store(next, Ordering::Release);
                    });
            }
        })
    }

    /// Once the GPU has finished the frame (`screenshot-sequence`), the depth it copied, as
    /// the next frame reads it: an error unless exactly that one sample was read back, never
    /// an older one.
    pub fn take_completed(&mut self, device: &wgpu::Device) -> Result<f32, String> {
        device
            .poll(wgpu::PollType::Poll)
            .map_err(|e| e.to_string())?;
        let state = |s: &Slot| s.state.load(Ordering::Acquire);
        let mut mapped = self.slots.iter().filter(|s| state(s) == MAPPED);
        let (Some(slot), None) = (mapped.next(), mapped.next()) else {
            return Err("the frame's centre depth wasn't read back alone".into());
        };
        if self
            .slots
            .iter()
            .any(|s| !matches!(state(s), FREE | MAPPED))
        {
            return Err("the frame's centre depth wasn't read back alone".into());
        }
        let depth = slot
            .buffer
            .slice(..4)
            .get_mapped_range()
            .map(|bytes| bytemuck::pod_read_unaligned::<f32>(&bytes[..4]))
            .map_err(|e| e.to_string());
        slot.buffer.unmap();
        slot.state.store(FREE, Ordering::Release);
        let depth = depth?;
        if !depth.is_finite() {
            return Err("the centre depth isn't finite".into());
        }
        self.latest = Some(depth.clamp(0.0, 1.0));
        Ok(depth.clamp(0.0, 1.0))
    }

    /// The newest depth read back so far, `None` before the first arrives.
    pub fn collect(&mut self, device: &wgpu::Device) -> Option<f32> {
        let _ = device.poll(wgpu::PollType::Poll);
        for slot in &self.slots {
            if slot.state.load(Ordering::Acquire) != MAPPED {
                continue;
            }
            let depth = slot
                .buffer
                .slice(..4)
                .get_mapped_range()
                .ok()
                .map(|bytes| bytemuck::pod_read_unaligned::<f32>(&bytes[..4]));
            slot.buffer.unmap();
            slot.state.store(FREE, Ordering::Release);
            if let Some(depth) = depth.filter(|d| d.is_finite()) {
                self.latest = Some(depth.clamp(0.0, 1.0));
            }
        }
        self.latest
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn test_device() -> Option<(wgpu::Device, wgpu::Queue)> {
        let adapter = crate::gfx::test_gpu::adapter()?;
        Some(crate::gfx::test_gpu::device(&adapter))
    }

    fn clear(encoder: &mut wgpu::CommandEncoder, view: &wgpu::TextureView, depth: f32) {
        encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
            depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                view,
                depth_ops: Some(wgpu::Operations {
                    load: wgpu::LoadOp::Clear(depth),
                    store: wgpu::StoreOp::Store,
                }),
                stencil_ops: None,
            }),
            ..Default::default()
        });
    }

    /// Inline and on the submit thread: each finished frame's depth, then none left to
    /// take; several outstanding samples are refused.
    #[test]
    #[ignore = "requires a host GPU"]
    fn a_finished_frame_s_depth_is_taken_alone_never_an_older_one() {
        let Some((device, raw)) = test_device() else {
            return;
        };
        let depth = device.create_texture(&wgpu::TextureDescriptor {
            label: None,
            size: wgpu::Extent3d {
                width: 3,
                height: 3,
                depth_or_array_layers: 1,
            },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Depth32Float,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING,
            view_formats: &[],
        });
        let view = depth.create_view(&Default::default());
        for threaded in [false, true] {
            let queue = super::super::submit::Queue::new(raw.clone(), threaded);
            if threaded {
                assert!(queue.threaded(), "deferred submit unavailable");
            }
            let mut center = CenterDepth::new(&device);
            assert!(center.take_completed(&device).is_err());
            for value in [0.125, 0.75, 0.25] {
                let mut encoder = device.create_command_encoder(&Default::default());
                clear(&mut encoder, &view, value);
                center.copy(&device, &mut encoder, &depth);
                let after = center.submitted().expect("one copied sample");
                if threaded {
                    let job = super::super::submit::Job {
                        encoder,
                        surface: None,
                        after: Some(Box::new(after)),
                    };
                    assert!(queue.submit_later(job).is_ok());
                    queue.wait();
                } else {
                    queue.submit([encoder.finish()]);
                    after();
                }
                device
                    .poll(wgpu::PollType::Wait {
                        submission_index: None,
                        timeout: Some(std::time::Duration::from_secs(30)),
                    })
                    .unwrap();
                assert_eq!(center.take_completed(&device).unwrap(), value);
                assert_eq!(center.collect(&device), Some(value));
                assert!(
                    center.take_completed(&device).is_err(),
                    "no stale latest fallback"
                );
            }
            // Several outstanding copies are ambiguous, even after they all map.
            let mut encoder = device.create_command_encoder(&Default::default());
            for _ in 0..SLOTS {
                center.copy(&device, &mut encoder, &depth);
            }
            queue.submit([encoder.finish()]);
            center.submitted().unwrap()();
            device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
            assert!(center.take_completed(&device).is_err());
        }
    }

    /// Frames that go to the submit thread start their readback there: the centre depth
    /// follows the frames instead of keeping the first ones' depth.
    #[test]
    fn the_centre_depth_follows_frames_submitted_on_the_submit_thread() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let queue = super::super::submit::Queue::new(queue, true);
        if !queue.threaded() {
            return;
        }
        let depth = device.create_texture(&wgpu::TextureDescriptor {
            label: None,
            size: wgpu::Extent3d {
                width: 4,
                height: 4,
                depth_or_array_layers: 1,
            },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Depth32Float,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING,
            view_formats: &[],
        });
        let view = depth.create_view(&Default::default());
        let mut center = CenterDepth::new(&device);
        let mut latest = None;
        for frame in 1..=4 * SLOTS {
            let value = frame as f32 / 16.0;
            let mut encoder = device.create_command_encoder(&Default::default());
            clear(&mut encoder, &view, value);
            center.copy(&device, &mut encoder, &depth);
            let after = center
                .submitted()
                .map(|f| Box::new(f) as super::super::submit::AfterSubmit);
            let job = super::super::submit::Job {
                encoder,
                surface: None,
                after,
            };
            assert!(queue.submit_later(job).is_ok());
            queue.wait();
            let _ = device.poll(wgpu::PollType::wait_indefinitely());
            latest = center.collect(&device);
            assert_eq!(latest, Some(value), "frame {frame}");
        }
        assert_eq!(latest, Some(0.75));
    }

    /// A depth texture cleared to a known depth comes back as that depth, a frame or more
    /// later, without the frame waiting for it.
    #[test]
    fn the_centre_depth_comes_back() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let depth = device.create_texture(&wgpu::TextureDescriptor {
            label: None,
            size: wgpu::Extent3d {
                width: 9,
                height: 7,
                depth_or_array_layers: 1,
            },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Depth32Float,
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING,
            view_formats: &[],
        });
        let view = depth.create_view(&Default::default());
        let mut center = CenterDepth::new(&device);
        assert_eq!(center.collect(&device), None);
        let mut encoder = device.create_command_encoder(&Default::default());
        encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
            depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                view: &view,
                depth_ops: Some(wgpu::Operations {
                    load: wgpu::LoadOp::Clear(0.375),
                    store: wgpu::StoreOp::Store,
                }),
                stencil_ops: None,
            }),
            ..Default::default()
        });
        center.copy(&device, &mut encoder, &depth);
        queue.submit([encoder.finish()]);
        center.submitted().expect("a copy to read back")();
        let _ = device.poll(wgpu::PollType::wait_indefinitely());
        assert_eq!(center.collect(&device), Some(0.375));
        // Its slot is free again: every slot can be used once more.
        for _ in 0..SLOTS {
            let mut encoder = device.create_command_encoder(&Default::default());
            center.copy(&device, &mut encoder, &depth);
            queue.submit([encoder.finish()]);
            center.submitted().expect("a free slot")();
        }
        let _ = device.poll(wgpu::PollType::wait_indefinitely());
        assert_eq!(center.collect(&device), Some(0.375));
    }
}
