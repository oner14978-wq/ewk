//! Bind prepared registry states to model choices; bake each transformed model
//! once and share its geometry across positions. Resource failure recovery and
//! resource-pack reloads remain separate work.
use crate::{Result, sprites::Sprites};
use horizon_assets::{
    bake::{BlockModelTransform, ModelQuad, RenderType, bake_block_model},
    blockstate::{
        BlockStateDefinition, Variant, VariantSet,
        bind::{Properties, PropertySchema, PropertyValues, SelectedModels},
        choice::CompiledChoices,
    },
    model::Direction,
};
use horizon_core::{
    position::BlockPos,
    random::{LegacyRandom, position_seed},
};
use horizon_world::{
    chunk::BlockState,
    registry::{BlockRegistry, BlockStateId},
};
use serde_json::Value;
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    sync::OnceLock,
};

/// `prepareQuadShape`: the quad's bounds, whether it is partial (smaller than
/// the block face) and whether it is cubic (flush with the block boundary, or
/// flat on a full collision shape). A function of the quad's positions and the
/// block's `isCollisionShapeFullBlock` only, so it is baked per face, once for
/// each.
#[derive(Clone, Copy)]
pub struct QuadShape {
    /// The quad's bounds by face index (`mesher::lighting`'s `SizeInfo`
    /// order: down, up, north, south, west, east), and `1.0 - the bound`.
    pub bounds: [f32; 12],
    pub partial: bool,
    pub cubic: bool,
}
impl QuadShape {
    pub fn new(positions: &[[f32; 3]; 4], face: Direction, full: bool) -> Self {
        // `SizeInfo` indices into the face shape.
        const DOWN: usize = 0;
        const UP: usize = 1;
        const NORTH: usize = 2;
        const SOUTH: usize = 3;
        const WEST: usize = 4;
        const EAST: usize = 5;
        let (mut min, mut max) = ([32f32; 3], [-32f32; 3]);
        for p in positions {
            for i in 0..3 {
                min[i] = min[i].min(p[i]);
                max[i] = max[i].max(p[i]);
            }
        }
        let mut bounds = [0f32; 12];
        for (index, value) in [
            (WEST, min[0]),
            (EAST, max[0]),
            (DOWN, min[1]),
            (UP, max[1]),
            (NORTH, min[2]),
            (SOUTH, max[2]),
        ] {
            bounds[index] = value;
            bounds[index + 6] = 1.0 - value;
        }
        let (lo, hi) = (1.0e-4f32, 0.9999f32);
        let partial =
            |a: usize, b: usize| min[a] >= lo || min[b] >= lo || max[a] <= hi || max[b] <= hi;
        let (partial, cubic) = match face {
            Direction::Down => (partial(0, 2), min[1] == max[1] && (min[1] < lo || full)),
            Direction::Up => (partial(0, 2), min[1] == max[1] && (max[1] > hi || full)),
            Direction::North => (partial(0, 1), min[2] == max[2] && (min[2] < lo || full)),
            Direction::South => (partial(0, 1), min[2] == max[2] && (max[2] > hi || full)),
            Direction::West => (partial(1, 2), min[0] == max[0] && (min[0] < lo || full)),
            Direction::East => (partial(1, 2), min[0] == max[0] && (max[0] > hi || full)),
        };
        QuadShape {
            bounds,
            partial,
            cubic,
        }
    }
}
pub struct BakedFace {
    pub quad: ModelQuad,
    pub layer: u32,
    /// The texels under the quad's UVs are all opaque (`SpriteContents.computeTransparency`):
    /// drawn in the solid layer without an alpha test.
    pub opaque: bool,
    /// Fractional alpha: drawn in the sorted translucent pass.
    pub translucent: bool,
    /// The Fusion connecting texture rule its sprite joins by ([`crate::fusion`]), plus one:
    /// two bytes, within the padding every face already has.
    pub fusion: Option<std::num::NonZeroU16>,
    /// `prepareQuadShape` of the quad, indexed by the block's `full` flag: the
    /// mesher would otherwise recompute it for every face of every block.
    pub shapes: [QuadShape; 2],
    /// The quad's own UVs in `TerrainVertex` fixed point, which the mesh
    /// otherwise recomputes for every face of every block.
    pub uv_fixed: [[u16; 2]; 4],
}
impl BakedFace {
    pub fn new(
        quad: ModelQuad,
        layer: u32,
        opaque: bool,
        translucent: bool,
        fusion: Option<std::num::NonZeroU16>,
    ) -> Self {
        let shapes = [false, true].map(|full| QuadShape::new(&quad.positions, quad.facing, full));
        let uv_fixed = crate::mesher::baked_uv(quad.uv);
        Self {
            quad,
            layer,
            opaque,
            translucent,
            fusion,
            shapes,
            uv_fixed,
        }
    }
}
pub struct BakedModel {
    pub ambient_occlusion: bool,
    /// The model's particle slot also exists for models without block faces.
    pub particle: Option<u32>,
    pub faces: Vec<BakedFace>,
    pub cube: Option<[super::cube::CubeStyle; 6]>,
}
type VariantKey = (String, [u8; 3], bool);
/// Empty by default: no state has a model (a dedicated server, which draws
/// nothing).
#[derive(Default)]
pub struct StateModels {
    /// Each definition's choices, a variant standing as its index in `baked`.
    choices: Vec<CompiledChoices<u32>>,
    /// All baked alternatives per definition, invalidated before mutable model access.
    bounds: OnceLock<Vec<Option<[[f32; 3]; 2]>>>,
    /// By state id: its definition in `choices` and the models it selects.
    states: Vec<Option<(usize, SelectedModels)>>,
    single_models: Vec<Option<u32>>,
    /// Every transformed model once, with the variant it was baked from.
    baked: Vec<(Variant, BakedModel)>,
    /// The kinetic parts' models no blockstate names, by model and turns: their place in `baked`.
    partials: BTreeMap<VariantKey, u32>,
    /// Standalone models by id: their index in `baked`.
    standalone: BTreeMap<String, u32>,
}
fn key(variant: &Variant) -> VariantKey {
    (variant.model.clone(), variant.rotations, variant.uv_lock)
}
/// The models the kinetic blocks of a content root turn or move besides their own (`half`,
/// `extra`, `head`, `pole` and `models` in its kinetic.json, which horizon-client's mod_content
/// writes); none for vanilla's.
fn partial_models(root: &crate::resource_source::ResourceSource) -> BTreeSet<String> {
    let mut out = BTreeSet::new();
    if let Ok(bytes) = root.read("kinetic.json") {
        let parts: BTreeMap<String, Value> = serde_json::from_slice(&bytes).unwrap_or_default();
        for part in parts.values() {
            for k in ["half", "extra", "head", "pole"] {
                out.extend(part[k].as_str().map(str::to_owned));
            }
            // A part's other models (a belt's).
            for m in part["models"].as_array().into_iter().flatten() {
                out.extend(m.as_str().map(str::to_owned));
            }
        }
    }
    // Any block's models besides its own (block-models.json: a blaze burner's blaze).
    if let Ok(bytes) = root.read("block-models.json") {
        let blocks: BTreeMap<String, Vec<String>> =
            serde_json::from_slice(&bytes).unwrap_or_default();
        out.extend(blocks.into_values().flatten());
    }
    out
}
/// Bakes model `name` of `library`, turned and UV-locked as a variant says.
fn bake_variant(
    sprites: &mut Sprites,
    library: &horizon_assets::resolve::ModelLibrary,
    name: &str,
    turns: [u8; 3],
    lock: bool,
) -> Result<BakedModel> {
    bake_resolved(sprites, &library.resolve(name)?, turns, lock)
}
/// Bakes a resolved `model`, turned and UV-locked as a variant says.
fn bake_resolved(
    sprites: &mut Sprites,
    model: &horizon_assets::resolve::ResolvedCuboidModel,
    turns: [u8; 3],
    lock: bool,
) -> Result<BakedModel> {
    let particle = model
        .material("particle")?
        .map(|material| sprites.insert(&material.sprite))
        .transpose()?;
    let faces: Vec<BakedFace> = bake_block_model(model, BlockModelTransform::new(turns, lock))?
        .into_iter()
        .map(|quad| {
            let layer = sprites.insert(&quad.material.sprite)?;
            // A model's `render_type` replaces the pass its sprite would pick.
            let (translucent, opaque) = match quad.render_type {
                Some(RenderType::Translucent | RenderType::Tripwire) => (true, false),
                Some(RenderType::Solid) => (false, true),
                Some(RenderType::Cutout | RenderType::CutoutMipped) => (false, false),
                None | Some(RenderType::Unsupported) => (
                    quad.material.force_translucent || sprites.translucent[layer as usize],
                    sprites.region_opaque(layer, &quad.uv),
                ),
            };
            Ok(BakedFace::new(quad, layer, opaque, translucent, None))
        })
        .collect::<Result<_>>()?;
    let cube = super::cube::cube_styles(&faces);
    Ok(BakedModel {
        ambient_occlusion: model.ambient_occlusion,
        particle,
        faces,
        cube,
    })
}
/// The definitions a blockstate file holds, bottom first: the layers of a
/// file the pack overlay stacked (`packs::BLOCKSTATE_LAYERS`), else the
/// file itself.
fn definition_layers(text: &str) -> std::result::Result<Vec<String>, String> {
    if !text.contains(crate::packs::BLOCKSTATE_LAYERS) {
        return Ok(vec![text.to_owned()]);
    }
    let value: Value = serde_json::from_str(text).map_err(|e| e.to_string())?;
    match value.get(crate::packs::BLOCKSTATE_LAYERS) {
        Some(Value::Array(layers)) => Ok(layers.iter().map(Value::to_string).collect()),
        _ => Ok(vec![text.to_owned()]),
    }
}
/// Each state's model from definitions bound bottom first: the topmost one
/// that binds the state, as (its layer, its selection). A higher pack's
/// definition replaces only the states it binds (`putAll` in
/// `loadBlockStateDefinitionStack`).
fn topmost(layers: Vec<Vec<Option<SelectedModels>>>) -> Vec<Option<(usize, SelectedModels)>> {
    let mut picked: Vec<Option<(usize, SelectedModels)>> = Vec::new();
    for (layer, bound) in layers.into_iter().enumerate() {
        picked.resize(picked.len().max(bound.len()), None);
        for (slot, selected) in picked.iter_mut().zip(bound) {
            if let Some(selected) = selected {
                *slot = Some((layer, selected));
            }
        }
    }
    picked
}
impl StateModels {
    pub fn load(
        root: &crate::resource_source::ResourceRoot,
        registry: &BlockRegistry,
        blocks: &[&str],
        sprites: &mut Sprites,
    ) -> Result<Self> {
        let facts: BTreeMap<String, Value> =
            serde_json::from_slice(&fs::read(root.prepared().join("model-states.json"))?)?;
        Self::from_facts(root.source(), registry, blocks, sprites, &facts)
    }
    /// Bind and bake models using an already parsed model-state document.
    pub fn from_facts(
        root: &crate::resource_source::ResourceSource,
        registry: &BlockRegistry,
        blocks: &[&str],
        sprites: &mut Sprites,
        facts: &BTreeMap<String, Value>,
    ) -> Result<Self> {
        Self::from_facts_with_models(
            root,
            registry,
            blocks,
            sprites,
            facts,
            &crate::model_library::ParsedModels::default(),
        )
    }
    pub(crate) fn from_facts_with_models(
        root: &crate::resource_source::ResourceSource,
        registry: &BlockRegistry,
        blocks: &[&str],
        sprites: &mut Sprites,
        facts: &BTreeMap<String, Value>,
        models: &crate::model_library::ParsedModels,
    ) -> Result<Self> {
        let mut choices = Vec::new();
        let mut states = vec![None; registry.len()];
        let mut variants = BTreeSet::new();
        let mut by_name: std::collections::HashMap<&str, Vec<BlockStateId>> =
            std::collections::HashMap::new();
        for i in 0..registry.len() {
            let id = BlockStateId(i as u32);
            if let Some(state) = registry.state(id) {
                by_name.entry(state.name.as_str()).or_default().push(id);
            }
        }
        for block in blocks.iter().copied().collect::<BTreeSet<_>>() {
            // Vanilla blocks come bare; content mods' blocks with their namespace.
            let (namespace, path) = block.split_once(':').unwrap_or(("minecraft", block));
            let name = format!("{namespace}:{path}");
            let facts = facts.get(&name).ok_or("missing block model state schema")?;
            let schema: PropertySchema = facts["schema"]
                .as_object()
                .ok_or("invalid model schema")?
                .iter()
                .map(|(key, value)| {
                    let values = if let Some(range) = value.get("integer") {
                        PropertyValues::Integer {
                            minimum: i32::try_from(
                                range[0]
                                    .as_i64()
                                    .ok_or("invalid integer property minimum")?,
                            )?,
                            maximum: i32::try_from(
                                range[1]
                                    .as_i64()
                                    .ok_or("invalid integer property maximum")?,
                            )?,
                        }
                    } else {
                        PropertyValues::Named(
                            value["named"]
                                .as_array()
                                .ok_or("missing named property values")?
                                .iter()
                                .map(|v| {
                                    v.as_str()
                                        .map(str::to_owned)
                                        .ok_or("invalid named property value")
                                })
                                .collect::<std::result::Result<_, _>>()?,
                        )
                    };
                    Ok((key.clone(), values))
                })
                .collect::<Result<_>>()?;
            let possible: Vec<Properties> = serde_json::from_value(facts["states"].clone())?;
            // Vanilla's BlockStateModelLoader: a definition that does not
            // read or bind is logged and left out; with none left the block
            // gets no model, and the other blocks still load. A file several
            // packs provide binds each pack's definition on its own, bottom
            // first (`loadBlockStateDefinitionStack`).
            let layers = match root
                .read_to_string(&format!("assets/{namespace}/blockstates/{path}.json"))
                .map_err(|e| e.to_string())
                .and_then(|text| definition_layers(&text))
            {
                Ok(layers) => layers,
                Err(e) => {
                    log::warn!(
                        "Horizon: blockstate definition of {namespace}:{path} not loaded: {e}"
                    );
                    continue;
                }
            };
            let mut loaded = Vec::with_capacity(layers.len());
            for text in &layers {
                let layer = BlockStateDefinition::from_json(text)
                    .map_err(|e| e.to_string())
                    .and_then(|definition| {
                        let bound = definition
                            .bind(&schema, &possible)
                            .map_err(|e| e.to_string())?;
                        Ok((definition, bound))
                    });
                match layer {
                    Ok(layer) => loaded.push(layer),
                    Err(e) => log::warn!(
                        "Horizon: blockstate definition of {namespace}:{path} not loaded: {e}"
                    ),
                }
            }
            if loaded.is_empty() {
                continue;
            }
            let native_order: Vec<_> = by_name
                .get(name.as_str())
                .map(Vec::as_slice)
                .unwrap_or_default()
                .iter()
                .map(|&id| (id, &registry.state(id).expect("indexed state").properties))
                .collect();
            if native_order.len() != possible.len()
                || native_order
                    .iter()
                    .zip(&possible)
                    .any(|((_, a), b)| *a != b)
            {
                return Err(
                    "model state definitions disagree with the imported block registry".into(),
                );
            }
            let (definitions, bound): (Vec<_>, Vec<_>) = loaded.into_iter().unzip();
            let first = choices.len();
            for ((id, _), picked) in native_order.into_iter().zip(topmost(bound)) {
                if let Some((layer, selected)) = picked {
                    states[id.0 as usize] = Some((first + layer, selected));
                }
            }
            for definition in definitions {
                for choice in definition
                    .variants
                    .iter()
                    .flatten()
                    .map(|(_, choice)| choice)
                    .chain(
                        definition
                            .multipart
                            .iter()
                            .flatten()
                            .map(|selector| &selector.variant),
                    )
                {
                    match choice {
                        VariantSet::Single(v) => {
                            variants.insert(key(v));
                        }
                        VariantSet::Weighted(v) => variants.extend(v.iter().map(|(v, _)| key(v))),
                    }
                }
                choices.push(CompiledChoices::new(&definition)?);
            }
        }
        // Kinetic parts' turning models no blockstate names (a gearbox's shaft ends, a crank's
        // handle), baked at every quarter turn about x and y.
        let partials = partial_models(root);
        for name in &partials {
            for x in 0..4u8 {
                for y in 0..4u8 {
                    variants.insert((name.clone(), [x, y, 0], false));
                }
            }
        }
        let names: Vec<String> = variants.iter().map(|(name, _, _)| name.clone()).collect();
        let library = match models.block_library(root, names.clone()) {
            Ok(library) => library,
            Err(e) => {
                log::warn!("Horizon: block models incomplete ({e}); using the missing model");
                models.block_library_or_missing(root, names)?
            }
        };
        let resolved: Vec<_> = variants
            .iter()
            .map(|(name, ..)| library.resolve(name))
            .collect();
        // Every texture the models name, decoded side by side before the bake adds them one
        // by one in its own order.
        sprites.prefetch(
            resolved
                .iter()
                .flatten()
                .flat_map(|model| model.textures.values())
                .map(|material| material.sprite.as_str()),
        );
        let mut baked = Vec::with_capacity(variants.len());
        let mut index = BTreeMap::new();
        for ((name, turns, lock), model) in variants.into_iter().zip(resolved) {
            let model = bake_resolved(sprites, &model?, turns, lock)?;
            index.insert((name.clone(), turns, lock), baked.len() as u32);
            let variant = Variant {
                model: name,
                rotations: turns,
                uv_lock: lock,
            };
            baked.push((variant, model));
        }
        // Every variant of every definition was baked above.
        let choices: Vec<_> = choices.iter().map(|c| c.map(|v| index[&key(v)])).collect();
        let partials = index
            .into_iter()
            .filter(|((name, ..), _)| partials.contains(name))
            .collect();
        let single_models = states
            .iter()
            .map(|state| {
                let (choice, selected) = state.as_ref()?;
                choices[*choice].single_variant(selected).copied()
            })
            .collect();
        Ok(Self {
            choices,
            bounds: OnceLock::new(),
            states,
            single_models,
            baked,
            partials,
            standalone: BTreeMap::new(),
        })
    }
    /// A kinetic part's model no blockstate names, baked at these quarter turns about x and y
    /// (z 0).
    pub fn partial(&self, model: &str, turns: [u8; 3]) -> Option<&BakedModel> {
        let i = self.partials.get(&(model.to_owned(), turns, false))?;
        Some(&self.baked[*i as usize].1)
    }
    /// Bakes `names`, models no blockstate needs to name (vanilla's
    /// standalone models, NeoForge's `ModelEvent.RegisterStandalone`), as
    /// they are, unturned, for [`Self::standalone`]. One a block state
    /// already bakes unturned is shared. A model that doesn't read (missing,
    /// or a parent missing) is logged and left out, as a missing blockstate
    /// is; the others still bake.
    pub(crate) fn bake_standalone(
        &mut self,
        root: &crate::resource_source::ResourceSource,
        sprites: &mut Sprites,
        models: &crate::model_library::ParsedModels,
        names: &[String],
    ) -> Result<()> {
        for name in names {
            if self.standalone.contains_key(name) {
                continue;
            }
            if let Some(i) = self
                .baked
                .iter()
                .position(|(v, _)| v.model == *name && v.rotations == [0; 3] && !v.uv_lock)
            {
                self.standalone.insert(name.clone(), i as u32);
                continue;
            }
            let model = models
                .block_library(root, vec![name.clone()])
                .and_then(|library| bake_variant(sprites, &library, name, [0; 3], false));
            match model {
                Ok(model) => {
                    self.standalone
                        .insert(name.clone(), self.baked.len() as u32);
                    let variant = Variant {
                        model: name.clone(),
                        rotations: [0; 3],
                        uv_lock: false,
                    };
                    self.baked.push((variant, model));
                }
                Err(e) => log::warn!("Horizon: standalone model {name} not loaded: {e}"),
            }
        }
        Ok(())
    }
    /// Every baked model with the variant it was baked from, to change its faces.
    pub fn models_mut(&mut self) -> impl Iterator<Item = (&Variant, &mut BakedModel)> {
        self.bounds.take();
        self.baked
            .iter_mut()
            .map(|(variant, model)| (&*variant, model))
    }
    /// A model baked by [`Self::bake_standalone`], by id (`mymod:block/shaft_half`).
    pub fn standalone(&self, name: &str) -> Option<&BakedModel> {
        self.model_by_slot(self.standalone_slot(name)?)
    }
    /// Resolve a standalone name once, without copying its baked geometry.
    pub fn standalone_slot(&self, name: &str) -> Option<u32> {
        self.standalone.get(name).copied()
    }
    /// Slots of registered standalone models, including models shared with block states.
    pub fn standalone_slots(&self) -> impl Iterator<Item = u32> + '_ {
        self.standalone.values().copied()
    }
    /// Geometry in this catalog's existing baked store.
    pub fn model_by_slot(&self, slot: u32) -> Option<&BakedModel> {
        self.baked.get(slot as usize).map(|(_, model)| model)
    }
    pub fn collect(
        &self,
        state: BlockStateId,
        position: BlockPos,
    ) -> Result<Vec<(&Variant, &BakedModel)>> {
        // Blocks use their position seed; contained/displayed blocks can supply one.
        self.collect_seeded(state, position_seed(position))
    }
    /// `BlockStateModel.particleMaterial`: the particle sprite layer of the
    /// state's first variant (see `CompiledChoices::particle_variant`).
    pub fn particle(&self, state: BlockStateId) -> Option<u32> {
        let (choice, selected) = self.state(state)?;
        let model = self.choices[*choice].particle_variant(selected)?;
        self.baked[*model as usize].1.particle
    }
    /// Envelope of every weighted/multipart alternative in the state's definition.
    /// Includes transformed resource-pack faces outside the unit cube. Empty or
    /// non-finite geometry has no usable envelope and keeps the original draw path.
    pub fn render_bounds(&self, state: BlockStateId) -> Option<[[f32; 3]; 2]> {
        let (definition, _) = self.state(state)?;
        let bounds = self.bounds.get_or_init(|| {
            self.choices
                .iter()
                .map(|choices| {
                    let mut lo = glam::Vec3::splat(f32::INFINITY);
                    let mut hi = glam::Vec3::splat(f32::NEG_INFINITY);
                    let mut valid = true;
                    // `map` visits every choice, without consuming the render RNG.
                    choices.map(|&index| {
                        for face in &self.baked[index as usize].1.faces {
                            for p in face.quad.positions {
                                let p = glam::Vec3::from_array(p);
                                valid &= p.is_finite();
                                lo = lo.min(p);
                                hi = hi.max(p);
                            }
                        }
                    });
                    (valid && lo.is_finite() && hi.is_finite())
                        .then_some([lo.to_array(), hi.to_array()])
                })
                .collect()
        });
        bounds.get(*definition).copied().flatten()
    }

    pub fn collect_seeded(
        &self,
        state: BlockStateId,
        seed: i64,
    ) -> Result<Vec<(&Variant, &BakedModel)>> {
        let mut models = Vec::new();
        self.each_seeded(state, seed, |(variant, model)| {
            models.push((variant, model))
        })?;
        Ok(models)
    }
    /// The models a block draws at `position`, into `out` (cleared first):
    /// `collect` for the mesher, which reuses one list for every block.
    pub fn models_at<'a>(
        &'a self,
        state: BlockStateId,
        position: BlockPos,
        out: &mut Vec<&'a BakedModel>,
    ) -> Result<()> {
        out.clear();
        if let Some(Some(model)) = self.single_models.get(state.0 as usize) {
            out.push(&self.baked[*model as usize].1);
            return Ok(());
        }
        self.each_seeded(state, position_seed(position), |(_, model)| out.push(model))
    }
    fn each_seeded<'a>(
        &'a self,
        state: BlockStateId,
        seed: i64,
        mut f: impl FnMut(&'a (Variant, BakedModel)),
    ) -> Result<()> {
        let (choice, selected) = self.state(state).ok_or("unbound gallery block state")?;
        let mut random = LegacyRandom::new(seed);
        self.choices[*choice].for_each(selected, &mut random, |&model| {
            f(&self.baked[model as usize]);
        })?;
        Ok(())
    }
    fn state(&self, state: BlockStateId) -> Option<&(usize, SelectedModels)> {
        self.states.get(state.0 as usize)?.as_ref()
    }
}

pub fn descriptor(name: &str, overrides: &[(&str, &str)]) -> BlockState {
    BlockState {
        name: format!("minecraft:{name}"),
        properties: overrides
            .iter()
            .map(|(k, v)| ((*k).to_owned(), (*v).to_owned()))
            .collect(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model_library::ParsedModels;

    /// #7013: a pack's blockstate file that defines only some states (here
    /// a fence gate's `powered=true` ones) keeps vanilla's model for the
    /// rest, as vanilla binds each pack's definition and lets a higher one
    /// replace only what it binds.
    #[test]
    fn a_partial_pack_blockstate_keeps_vanilla_for_the_other_states() {
        let schema: PropertySchema = BTreeMap::from([(
            "powered".to_owned(),
            PropertyValues::Named(BTreeSet::from(["false".to_owned(), "true".to_owned()])),
        )]);
        let states: Vec<Properties> = ["false", "true"]
            .iter()
            .map(|p| BTreeMap::from([("powered".to_owned(), (*p).to_owned())]))
            .collect();
        let stacked = serde_json::json!({ crate::packs::BLOCKSTATE_LAYERS: [
            {"variants":{"":{"model":"minecraft:block/oak_fence_gate"}}},
            {"variants":{"powered=true":{"model":"minecraft:block/stone"}}}
        ]})
        .to_string();
        let layers = definition_layers(&stacked).unwrap();
        assert_eq!(layers.len(), 2);
        let bound = layers
            .iter()
            .map(|text| {
                BlockStateDefinition::from_json(text)
                    .unwrap()
                    .bind(&schema, &states)
                    .unwrap()
            })
            .collect();
        let picked = topmost(bound);
        assert_eq!(picked[0], Some((0, SelectedModels::Variant(0))));
        assert_eq!(picked[1], Some((1, SelectedModels::Variant(0))));
        // A file that isn't stacked is one definition.
        let plain = r#"{"variants":{"":{"model":"minecraft:block/stone"}}}"#;
        assert_eq!(definition_layers(plain).unwrap(), vec![plain.to_owned()]);
    }

    struct Fixture(std::path::PathBuf);
    impl Fixture {
        fn write(&self, name: &str, json: &str) {
            let (namespace, path) = name.split_once(':').unwrap();
            let path = self
                .0
                .join(format!("assets/{namespace}/models/{path}.json"));
            fs::create_dir_all(path.parent().unwrap()).unwrap();
            fs::write(path, json).unwrap();
        }
    }
    impl Drop for Fixture {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.0);
        }
    }

    #[test]
    fn archive_models_bind_prepared_states_and_load_world_texture_features_in_place() -> Result<()>
    {
        use crate::resource_source::{ResourceRoot, ResourceSource};
        use std::io::Write;
        use {horizon_core::nbt::Tag, horizon_world::DATA_VERSION};
        let fixture = Fixture(
            std::env::temp_dir().join(format!("horizon-world-archive-{}", std::process::id())),
        );
        let prepared = fixture.0.join("prepared");
        fs::create_dir_all(&prepared)?;
        fs::write(
            prepared.join("model-states.json"),
            br#"{"demo:stone":{"schema":{},"states":[{}]}}"#,
        )?;
        let state = BlockState {
            name: "demo:stone".into(),
            properties: Default::default(),
        };
        let registry = BlockRegistry::from_nbt(&Tag::compound([
            ("DataVersion", Tag::Int(DATA_VERSION)),
            ("states", Tag::List(vec![state.to_nbt()])),
            ("defaults", Tag::compound([("demo:stone", Tag::Int(0))])),
        ]))?;
        let mut png = Vec::new();
        {
            let mut encoder = png::Encoder::new(&mut png, 16, 16);
            encoder.set_color(png::ColorType::Rgba);
            encoder.set_depth(png::BitDepth::Eight);
            encoder
                .write_header()?
                .write_image_data(&[10, 20, 30, 255].repeat(256))?;
        }
        let jar = fixture.0.join("world.jar");
        let mut writer = zip::ZipWriter::new(fs::File::create(&jar)?);
        for (name, bytes) in [
            ("model-states.json", b"this is not the prepared schema".as_slice()),
            ("assets/demo/blockstates/stone.json", br#"{"variants":{"":{"model":"demo:block/child"}}}"#),
            ("assets/demo/models/block/child.json", br#"{"loader":"fusion:model","type":"fusion:connecting","parent":"demo:block/base"}"#),
            ("assets/demo/models/block/base.json", br##"{"textures":{"all":"demo:block/stone","particle":"#all"},"elements":[{"from":[0,0,0],"to":[16,16,16],"faces":{"north":{"texture":"#all"}}}]}"##),
            ("assets/demo/textures/block/stone.png.mcmeta", br#"{"fusion":{"type":"connecting","layout":"simple"}}"#),
            ("assets/demo/optifine/ctm/stone.properties", b"matchBlocks=demo:stone\nmethod=fixed\ntiles=./tile\n"),
        ] {
            writer.start_file(name, zip::write::SimpleFileOptions::default())?;
            writer.write_all(bytes)?;
        }
        for (name, color) in [
            ("assets/demo/textures/block/stone.png", [10, 20, 30, 255]),
            ("assets/demo/textures/block/stone_e.png", [30, 40, 50, 255]),
            ("assets/demo/optifine/ctm/tile.png", [50, 60, 70, 255]),
            ("assets/demo/optifine/ctm/tile_e.png", [70, 80, 90, 255]),
            (
                "assets/demo/textures/emissive/glow.png",
                [90, 100, 110, 255],
            ),
        ] {
            let mut bytes = Vec::new();
            {
                let mut encoder = png::Encoder::new(&mut bytes, 16, 16);
                encoder.set_color(png::ColorType::Rgba);
                encoder.set_depth(png::BitDepth::Eight);
                encoder
                    .write_header()?
                    .write_image_data(&color.repeat(256))?;
            }
            writer.start_file(name, zip::write::SimpleFileOptions::default())?;
            writer.write_all(&bytes)?;
        }
        writer.finish()?;
        let root = ResourceRoot::new(
            prepared.clone(),
            fixture.0.join("cache"),
            ResourceSource::archive(&jar)?,
        );
        let mut sprites = Sprites::with_disk_cache(&root);
        let mut catalog = StateModels::load(&root, &registry, &["demo:stone"], &mut sprites)?;
        let base = sprites.layers["demo:block/stone"];
        let picked = catalog.collect(BlockStateId(0), BlockPos::new(0, 0, 0))?;
        assert_eq!(picked.len(), 1);
        assert_eq!(
            picked[0].1.faces.len(),
            1,
            "parent geometry loaded from the jar"
        );
        assert_eq!(picked[0].1.faces[0].layer, base);
        assert_eq!(picked[0].1.particle, Some(base));
        assert!(
            sprites
                .try_insert_limited("demo:block/stone", png.len() as u64 - 1)
                .is_err(),
            "the byte limit also applies to cached layers"
        );
        assert_eq!(
            sprites.try_insert_limited("demo:block/stone", png.len() as u64)?,
            base
        );
        let _fusion = crate::fusion::FusionTextures::load(
            root.source(),
            &registry,
            &mut sprites,
            &mut catalog,
        );
        assert!(
            catalog.collect(BlockStateId(0), BlockPos::new(0, 0, 0))?[0]
                .1
                .faces[0]
                .fusion
                .is_some()
        );
        let connected = crate::connected::ConnectedTextures::load(
            root.source(),
            &registry,
            &mut sprites,
            |_, _| Some(base),
        );
        assert!(!connected.is_empty());
        crate::native_emissive::load(root.source(), &mut sprites);
        assert!(sprites.layers.contains_key("demo:emissive/glow"));
        let pairs = crate::native_emissive::load_optifine(root.source(), &mut sprites);
        assert!(pairs.contains(&("demo:block/stone".into(), "demo:block/stone_e".into())));
        assert!(pairs.contains(&(
            "assets/demo/optifine/ctm/tile.png".into(),
            "assets/demo/optifine/ctm/tile_e.png".into()
        )));
        sprites.save_disk_cache();
        sprites.finish();
        let offset = base as usize * (sprites.size * sprites.size * 4) as usize;
        assert_eq!(sprites.pixels[offset..offset + 4], [10, 20, 30, 255]);
        assert!(!prepared.join("assets").exists());
        assert!(!fixture.0.join("assets").exists());
        assert_eq!(
            fs::read_dir(&prepared)?.count(),
            1,
            "asset reads did not touch prepared tables"
        );
        Ok(())
    }

    #[test]
    fn standalone_models_bake_once_and_skip_what_does_not_read() -> Result<()> {
        let fixture = Fixture(
            std::env::temp_dir().join(format!("horizon-standalone-{}", std::process::id())),
        );
        // A half shaft: one element, two faces; a child with its parent's elements.
        fixture.write(
            "lanef:block/shaft_half",
            r##"{"textures":{"side":"lanef:block/shaft"},"elements":[{"from":[6,6,0],"to":[10,10,8],"faces":{"north":{"texture":"#side"},"up":{"texture":"#side"}}}]}"##,
        );
        fixture.write(
            "lanef:block/cog",
            r#"{"parent":"lanef:block/shaft_half","textures":{"side":"lanef:block/cog"}}"#,
        );
        fixture.write("lanef:block/orphan", r#"{"parent":"lanef:block/absent"}"#);
        let mut models = StateModels::default();
        let mut sprites = Sprites::new(crate::resource_source::ResourceSource::directory(
            fixture.0.clone(),
        ));
        let names: Vec<String> = [
            "lanef:block/shaft_half",
            "lanef:block/cog",
            "lanef:block/orphan",
            "lanef:block/absent",
            "lanef:block/shaft_half",
        ]
        .map(str::to_owned)
        .into();
        let parsed = ParsedModels::load(&crate::resource_source::ResourceSource::directory(
            fixture.0.clone(),
        ));
        models.bake_standalone(
            &horizon_assets::resource_source::ResourceSource::directory(fixture.0.to_path_buf()),
            &mut sprites,
            &parsed,
            &names,
        )?;
        let shaft = models.standalone("lanef:block/shaft_half").expect("baked");
        assert_eq!(shaft.faces.len(), 2);
        let cog = models.standalone("lanef:block/cog").expect("baked");
        assert_eq!(cog.faces.len(), 2);
        assert_ne!(cog.faces[0].layer, shaft.faces[0].layer, "its own texture");
        assert!(models.standalone("lanef:block/orphan").is_none());
        assert!(models.standalone("lanef:block/absent").is_none());
        assert!(models.standalone("lanef:block/unnamed").is_none());
        // Named twice, baked once.
        assert_eq!(models.baked.len(), 2);
        // Without a parsed library, the files are read directly.
        let mut direct = StateModels::default();
        direct.bake_standalone(
            &horizon_assets::resource_source::ResourceSource::directory(fixture.0.to_path_buf()),
            &mut sprites,
            &ParsedModels::default(),
            &names,
        )?;
        assert_eq!(
            direct.standalone("lanef:block/cog").map(|m| m.faces.len()),
            Some(2)
        );
        Ok(())
    }

    #[test]
    fn a_standalone_model_a_state_bakes_unturned_is_shared() -> Result<()> {
        let mut models = StateModels::default();
        let variant = |rotations| Variant {
            model: "lanef:block/shared".into(),
            rotations,
            uv_lock: false,
        };
        let empty = || BakedModel {
            ambient_occlusion: true,
            particle: None,
            faces: Vec::new(),
            cube: None,
        };
        models.baked.push((variant([0, 90, 0]), empty()));
        models.baked.push((variant([0; 3]), empty()));
        let names = vec!["lanef:block/shared".to_owned()];
        let root = std::env::temp_dir().join("horizon-standalone-none");
        models.bake_standalone(
            &horizon_assets::resource_source::ResourceSource::directory(root.to_path_buf()),
            &mut Sprites::default(),
            &ParsedModels::default(),
            &names,
        )?;
        assert_eq!(models.baked.len(), 2);
        assert_eq!(models.standalone.get("lanef:block/shared"), Some(&1));
        Ok(())
    }
}

#[cfg(test)]
#[path = "catalog/bounds_tests.rs"]
mod bounds_tests;
