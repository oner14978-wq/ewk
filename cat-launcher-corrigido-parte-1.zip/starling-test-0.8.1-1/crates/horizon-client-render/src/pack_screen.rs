//! The resource pack screen (`PackSelectionScreen` with its two
//! `TransferableSelectionList`s, search box and buttons) and the
//! `ConfirmScreen` an incompatible pack opens, as vanilla's state machine:
//! clicks, the mouse wheel and typing change the selection model, the lists'
//! entries, scroll, selection and focus as the vanilla widgets do, and
//! [`PackScreen::draw`] gives the screen's GUI calls. The game shows it;
//! tools/test_pack_screen_parity.py compares it with vanilla.
use crate::{
    font::Patch,
    hud::{HudAtlas, PACK_ICON_SIZE, PACK_ICON_SLOTS},
    packs::{Position, Selectable, SelectionModel},
    screen_draw::{self as d, Backdrop, Draw, Measure, TextField},
    text::{Style, Text},
};
use std::{collections::HashMap, sync::Arc};

/// `PackCompatibility`.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Compat {
    Compatible,
    TooOld,
    TooNew,
    Unknown,
}

/// The line under the title: where packs come from. A phone has no window to drop files on;
/// they go in the game's folder in its shared storage (`datapacks` for data packs).
fn drop_info(data: bool) -> Text {
    if cfg!(target_os = "android") {
        Text::literal(phone_drop_info(data, phone_game_folder().as_deref()))
    } else {
        tr("pack.dropInfo")
    }
}
/// The game's folder on a phone, unless it is in the app's own files.
fn phone_game_folder() -> Option<std::path::PathBuf> {
    let shared = crate::logging::game_home() != crate::logging::private_home();
    shared.then(|| std::env::current_dir().unwrap_or_default())
}
/// `drop_info` on a phone, for the game's folder. It differs between the builds (Starling,
/// StarlingPreview, StarlingDev): shown from the storage's root, as a file manager does.
fn phone_drop_info(data: bool, folder: Option<&std::path::Path>) -> String {
    let Some(folder) = folder else {
        return "In the app's own files: Open Pack Folder to reach them".into();
    };
    let shown = folder.strip_prefix("/storage/emulated/0").unwrap_or(folder);
    let shown = shown.display();
    if data {
        format!("Put data packs in {shown}/datapacks, mods in {shown}/horizon-mods")
    } else {
        format!("Put packs in {shown}/resourcepacks")
    }
}
/// The footer's first button is 150 wide. With a Catalog button the two share that width, a gap
/// between: each is this wide.
const HALF_BUTTON: f32 = 73.0;
/// Open Folder's label when it shares the slot with Catalog: the longer ones ("Open Pack Folder")
/// don't fit half a button, and a label that doesn't fit scrolls.
pub(crate) const SHORT_OPEN_FOLDER: &str = "Open Folder";
/// The footer's first slot, at `x`: Open Folder's width and, when the page has a Catalog button,
/// its x and width. Open Folder keeps the left half and Catalog takes the right.
pub(crate) fn open_folder_slot(x: f32, catalog: bool) -> (f32, Option<(f32, f32)>) {
    if !catalog {
        return (150.0, None);
    }
    (HALF_BUTTON, Some((x + 150.0 - HALF_BUTTON, HALF_BUTTON)))
}
impl Compat {
    fn key(self) -> &'static str {
        match self {
            Compat::TooOld => "old",
            Compat::TooNew => "new",
            Compat::Unknown => "unknown",
            Compat::Compatible => "compatible",
        }
    }
}
/// `PackSource`: how the description is decorated.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Source {
    Default,
    BuiltIn,
    Feature,
    World,
    Server,
}

/// A pack as the screen shows it.
#[derive(Clone, Debug, PartialEq)]
pub struct PackInfo {
    pub id: String,
    pub title: Text,
    pub description: Text,
    /// The description component's own (root) style.
    pub description_style: Style,
    pub source: Source,
    pub compat: Compat,
    /// The pack's `pack.png` ([`load_icon`]); none draws `unknown_pack`.
    pub icon: Option<Arc<[u8]>>,
    pub required: bool,
    pub position: Position,
    pub fixed: bool,
}
impl PackInfo {
    pub fn selectable(&self) -> Selectable {
        Selectable {
            id: self.id.clone(),
            required: self.required,
            position: self.position,
            fixed: self.fixed,
            compatible: self.compat == Compat::Compatible,
        }
    }
    /// `PackSource.decorate` merged with the entry's grey
    /// (`getExtendedDescription`, `ComponentUtils.mergeStyles`), and the style of
    /// its root, which the ellipsis of a cut description takes.
    fn extended_description(&self) -> (Text, Style) {
        let gray = Style::color(0x808080);
        let key = match self.source {
            Source::Default => {
                let mut root = self.description_style.clone();
                root.inherit(&gray);
                return (self.description.clone().with_style(&gray), root);
            }
            Source::BuiltIn => "pack.source.builtin",
            Source::Feature => "pack.source.feature",
            Source::World => "pack.source.world",
            Source::Server => "pack.source.server",
        };
        let t = Text::translate(
            "pack.nameAndSource",
            &[self.description.clone(), Text::translate(key, &[])],
        )
        .with_color(d::GRAY);
        (t, Style::color(d::GRAY))
    }
}
/// A `pack.png` as the pack screen draws it: RGBA, stretched to a
/// `PACK_ICON_SIZE` square by nearest texels, as vanilla's icon texture is
/// sampled into its 32x32 square. None when it does not decode, where
/// `loadPackIcon` falls back to `unknown_pack`.
pub fn load_icon(png: &[u8]) -> Option<Arc<[u8]>> {
    scale_icon(crate::hud::decode_bytes(png).ok()?)
}
/// A project icon Modrinth served (PNG, WebP or JPEG,
/// [`crate::hud::decode_image_bytes`]), scaled as [`load_icon`] scales a pack's.
pub fn load_fetched_icon(bytes: &[u8]) -> Option<Arc<[u8]>> {
    scale_icon(crate::hud::decode_image_bytes(bytes).ok()?)
}
fn scale_icon((w, h, rgba): (u32, u32, Vec<u8>)) -> Option<Arc<[u8]>> {
    if w == 0 || h == 0 {
        return None;
    }
    let size = u64::from(PACK_ICON_SIZE);
    let mut out = Vec::with_capacity((size * size * 4) as usize);
    for y in 0..size {
        let sy = ((2 * y + 1) * u64::from(h) / (2 * size)) as usize;
        for x in 0..size {
            let sx = ((2 * x + 1) * u64::from(w) / (2 * size)) as usize;
            let at = (sy * w as usize + sx) * 4;
            out.extend_from_slice(&rgba[at..at + 4]);
        }
    }
    Some(out.into())
}
/// Points the icon blits of `draws` at the atlas's pack icon slots and writes the `icons` they
/// name into them, one slot per blit (vanilla registers a texture per icon). Icons past the last
/// slot keep `unknown_pack`.
pub fn bind_icon_slots(
    icons: &HashMap<String, Arc<[u8]>>,
    draws: &mut [Draw],
    atlas: &HudAtlas,
    patches: &mut Vec<Patch>,
) {
    let mut slots = 0..PACK_ICON_SLOTS;
    for draw in draws {
        let Draw::Blit { texture, .. } = draw else {
            continue;
        };
        let Some(icon) = icons.get(texture.as_str()) else {
            continue;
        };
        let Some(slot) = slots.next() else {
            return;
        };
        let sprite = format!("horizon/pack-icon{slot}");
        let Some(rect) = atlas.sprites.get(&sprite) else {
            return;
        };
        patches.push(Patch {
            x: (rect.u0 * atlas.width as f32).round() as u32,
            y: (rect.v0 * atlas.height as f32).round() as u32,
            width: PACK_ICON_SIZE,
            height: PACK_ICON_SIZE,
            rgba: icon.to_vec(),
        });
        *texture = sprite;
    }
}
/// `PackSelectionScreen.loadPackIcon`'s texture for a pack with an icon.
pub fn icon_texture(id: &str) -> String {
    let sanitized: String = id
        .to_lowercase()
        .chars()
        .map(|c| {
            if c.is_ascii_lowercase() || c.is_ascii_digit() || "_-./".contains(c) {
                c
            } else {
                '_'
            }
        })
        .collect();
    let bytes: Vec<u8> = id.encode_utf16().flat_map(u16::to_le_bytes).collect();
    let hash: String = crate::skins::sha1(&bytes)
        .iter()
        .map(|b| format!("{b:02x}"))
        .collect();
    format!("pack/{sanitized}/{hash}/icon")
}

#[derive(Clone, Debug, PartialEq)]
enum Row {
    Header,
    Pack(String),
}
#[derive(Clone, Debug)]
struct Entry {
    row: Row,
    y: i32,
    height: i32,
}
/// A `TransferableSelectionList`.
#[derive(Clone, Debug)]
struct List {
    selected_side: bool,
    x: i32,
    y: i32,
    width: i32,
    height: i32,
    scroll: f64,
    entries: Vec<Entry>,
    /// `getSelected`, an index into `entries`.
    selected: Option<usize>,
    /// The list has a focused child (possibly an entry it no longer holds).
    focused: bool,
    /// The pointer's last y while the scrollbar is held (`scrolling`).
    held: Option<f64>,
}
impl List {
    fn new(selected_side: bool, height: i32) -> Self {
        Self {
            selected_side,
            x: 0,
            y: 33,
            width: 200,
            height,
            scroll: 0.0,
            entries: Vec::new(),
            selected: None,
            focused: false,
            held: None,
        }
    }
    fn bottom(&self) -> i32 {
        self.y + self.height
    }
    fn row_left(&self) -> i32 {
        self.x + self.width / 2 - self.row_width() / 2
    }
    fn row_width(&self) -> i32 {
        self.width - 4
    }
    fn content_height(&self) -> i32 {
        self.entries.iter().map(|e| e.height).sum::<i32>() + 4
    }
    fn max_scroll(&self) -> i32 {
        (self.content_height() - self.height).max(0)
    }
    fn scrollable(&self) -> bool {
        self.max_scroll() > 0
    }
    /// `TransferableSelectionList.Entry.getWidth`.
    fn entry_width(&self) -> i32 {
        self.row_width() - if self.scrollable() { 6 } else { 0 }
    }
    fn next_y(&self) -> i32 {
        self.y + 2 - self.scroll as i32 + self.entries.iter().map(|e| e.height).sum::<i32>()
    }
    fn add(&mut self, row: Row, height: i32) {
        let y = self.next_y();
        self.entries.push(Entry { row, y, height });
    }
    fn reposition(&mut self) {
        let mut y = self.y + 2 - self.scroll as i32;
        for e in &mut self.entries {
            e.y = y;
            y += e.height;
        }
    }
    fn set_scroll(&mut self, v: f64) {
        self.scroll = v.clamp(0.0, self.max_scroll() as f64);
        self.reposition();
    }
    fn scroll_to(&mut self, i: usize) {
        let e = &self.entries[i];
        let top = e.y - self.y - 2;
        if top < 0 {
            self.set_scroll(self.scroll + top as f64);
        }
        let e = &self.entries[i];
        let bottom = self.bottom() - e.y - e.height - 2;
        if bottom < 0 {
            self.set_scroll(self.scroll - bottom as f64);
        }
    }
    fn set_selected(&mut self, i: Option<usize>) {
        self.selected = i;
        if let Some(i) = i {
            let e = &self.entries[i];
            let top = e.y + 2 < self.y;
            let bottom = e.y + 2 + e.height - 4 > self.bottom();
            if top || bottom {
                self.scroll_to(i);
            }
        }
    }
    fn update_size(&mut self, width: i32, height: i32, x: i32, y: i32) {
        self.width = width;
        self.height = height;
        self.x = x;
        self.y = y;
        self.reposition();
        if let Some(i) = self.selected {
            self.scroll_to(i);
        }
        self.set_scroll(self.scroll);
    }
    fn is_over(&self, x: f64, y: f64) -> bool {
        x >= self.x as f64
            && y >= self.y as f64
            && x < (self.x + self.width) as f64
            && y < self.bottom() as f64
    }
    /// `getEntryAtPosition`.
    fn entry_at(&self, x: i32, y: i32) -> Option<usize> {
        let (left, w) = (self.row_left(), self.entry_width());
        self.entries
            .iter()
            .position(|e| x >= left && x < left + w && y >= e.y && y < e.y + e.height)
    }
    fn scroll_bar_x(&self) -> i32 {
        self.x + self.width - 6
    }
    fn scroller_height(&self) -> i32 {
        ((self.height * self.height) as f32 / self.content_height() as f32) as i32
    }
    /// `AbstractScrollArea.mouseDragged` while the scrollbar is held.
    fn drag(&mut self, y: f64) {
        let Some(last) = self.held else { return };
        if y < self.y as f64 {
            self.set_scroll(0.0);
        } else if y > self.bottom() as f64 {
            self.set_scroll(self.max_scroll() as f64);
        } else {
            let max = self.max_scroll().max(1) as f64;
            let bar = self.scroller_height().clamp(32, self.height - 8);
            let scale = (max / (self.height - bar) as f64).max(1.0);
            self.set_scroll(self.scroll + (y - last) * scale);
        }
        self.held = Some(y);
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Focus {
    None,
    Search,
    List(usize),
    /// Open Pack Folder (0) or Done (1).
    Button(usize),
}

/// The open `ConfirmScreen` for an incompatible pack.
#[derive(Clone, Debug)]
struct Confirm {
    id: String,
    title: Text,
    message: Text,
}

/// What a click on the screen asks the game to do.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Action {
    None,
    /// The Open Pack Folder button.
    OpenFolder,
    /// The Done button (`onClose`: commit).
    Done,
    /// Horizon's own: the options button on the card of this pack, which has Polytone options.
    Options(String),
    /// Horizon's own: a Modrinth hit the player picked, to download into the
    /// packs folder. The screen does not know where that is.
    BrowsePick(usize),
    /// The Catalog button (Android).
    Catalog,
}

/// The pack screen and its state.
#[derive(Clone, Debug)]
pub struct PackScreen {
    /// `resourcePack.title`, or `dataPack.title` from Create World.
    pub title: Text,
    pub width: i32,
    pub height: i32,
    pub in_world: bool,
    pub packs: Vec<PackInfo>,
    pub model: SelectionModel,
    search: TextField,
    focus: Focus,
    /// 0: available, 1: selected.
    lists: [List; 2],
    confirm: Option<Confirm>,
    /// The selection changed since the screen opened.
    pub changed: bool,
    /// The packs' icons by their [`icon_texture`], and the browser's.
    pub icons: HashMap<String, Arc<[u8]>>,
    /// Horizon's own Add button and its Modrinth list, when the player has
    /// turned `packBrowser` on. Off, the screen stays vanilla's exactly
    /// (tools/test_pack_screen_parity.py).
    pub browser: Option<crate::pack_browser::Browser>,
    /// Which backdrop this screen wants drawn behind it this frame
    /// ([`Backdrop`]). Vanilla's own pack screen never asks for one.
    pub backdrop: Backdrop,
    /// The `icons` keys that came from the browser rather than from an
    /// installed pack. Each decoded icon is `PACK_ICON_SIZE` squared in RGBA
    /// (64 KiB), and a search brings twenty, so without this they piled up in
    /// `icons` for the rest of the session: every search added twenty more
    /// and none were ever freed.
    browser_icons: Vec<String>,
    /// Whether that button is drawn at all.
    pub browsing_allowed: bool,
    /// The packs with Polytone options (#11486): their cards carry an options button.
    pub with_options: std::collections::BTreeSet<String>,
    /// The browser's own search box, separate from the one that filters the
    /// player's installed packs.
    browser_search: TextField,
    /// The browser's search box has the keyboard.
    browser_focus: bool,
    /// Data packs and world mods (Create New World's) rather than resource packs.
    pub data: bool,
    /// A Catalog button beside the footer's two (`OptionsUi::offer_catalog`).
    pub catalog: bool,
}

fn tr(key: &str) -> Text {
    Text::translate(key, &[])
}

/// The Add button is square. The button sprite is a nine-slice built for a
/// height of 20; drawn shorter, neither it nor its label sits right, so the
/// button keeps that height and is centred on the shorter search box.
const ADD_SIZE: i32 = 20;
/// The options button on a pack's card.
const OPTIONS_SIZE: i32 = 16;
/// A card in the grid: its icon beside its name, author and description.
const ROW_H: i32 = 74;
/// The air around a card's contents.
const CARD_PAD: i32 = 6;
/// The sidebar of filters down the left.
const SIDEBAR_W: i32 = 108;
/// The bar across the top holding Back and the search box.
const TOPBAR_H: i32 = 30;
/// A filter row in the sidebar.
const FILTER_H: i32 = 15;
/// The panels' colours, dark over whatever is behind them.
const PANEL: i32 = 0xF0_14_17_22u32 as i32;
const CARD: i32 = 0xFF_1E_22_30u32 as i32;
const CARD_HOVER: i32 = 0xFF_2A_30_42u32 as i32;
const SIDEBAR_BG: i32 = 0xFF_10_12_1Bu32 as i32;
/// The Install button: Modrinth's green, dimmed once a pack is in.
const GREEN: i32 = 0xFF_1B_D9_6Au32 as i32;
const GREEN_HOVER: i32 = 0xFF_3B_E8_85u32 as i32;
const INSTALLED_GREEN: i32 = 0xFF_2A_5E_3Fu32 as i32;
const GREEN_EDGE: i32 = 0xFF_0E_7A_3Cu32 as i32;
/// The icon drawn at the left of a row.
const ICON: i32 = 34;
/// The browser's search box and the button beside it.
const BROWSER_SEARCH_W: i32 = 200;
const SEARCH_BTN_W: i32 = 56;
/// The Back and Install buttons.
const BACK_W: i32 = 60;
const BACK_H: i32 = 20;
const INSTALL_W: i32 = 70;

impl PackScreen {
    /// `PackSelectionScreen.init`: the lists filled, the search box focused.
    pub fn new(
        m: &Measure,
        title: Text,
        width: i32,
        height: i32,
        in_world: bool,
        packs: Vec<PackInfo>,
        selected: &[String],
    ) -> Self {
        let model = SelectionModel::new(packs.iter().map(PackInfo::selectable).collect(), selected);
        let mut search = TextField::new(0, 0, 200, 15);
        search.hint = Some(tr("gui.packSelection.search").with_style(&Style {
            color: Some(d::GRAY),
            italic: Some(true),
            ..Style::default()
        }));
        let icons = packs
            .iter()
            .filter_map(|p| Some((icon_texture(&p.id), p.icon.clone()?)))
            .collect();
        let mut s = Self {
            title,
            width,
            height,
            in_world,
            packs,
            icons,
            model,
            search,
            focus: Focus::None,
            lists: [List::new(false, height - 66), List::new(true, height - 66)],
            confirm: None,
            browser: None,
            browsing_allowed: false,
            with_options: Default::default(),
            backdrop: Backdrop::None,
            browser_icons: Vec::new(),
            browser_search: {
                let mut field = TextField::new(0, 0, BROWSER_SEARCH_W, 18);
                field.hint = Some(tr("horizon.pack.searchHint").with_style(&Style {
                    color: Some(d::GRAY),
                    italic: Some(true),
                    ..Style::default()
                }));
                field
            },
            browser_focus: false,
            changed: false,
            data: false,
            catalog: false,
        };
        s.reposition(m);
        s.populate(None);
        s.set_focus(Focus::Search);
        s
    }
    /// The screen for data packs (`CreateWorldScreen.openDataPackSelectionScreen`).
    pub fn for_data(mut self, m: &Measure) -> Self {
        self.data = true;
        self.reposition(m);
        self
    }
    fn title(&self) -> Text {
        if self.data {
            // Starling: the world's content mods are chosen here too.
            Text::literal("Select Mods and Data Packs")
        } else {
            self.title.clone()
        }
    }
    fn info(&self, id: &str) -> Option<&PackInfo> {
        self.packs.iter().find(|p| p.id == id)
    }
    /// The header layout: title, drop info and search box, centred.
    fn header(&self, m: &Measure) -> [(i32, i32); 3] {
        let tw = m.width(&self.title());
        let dw = m.width(&drop_info(self.data));
        let col = tw.max(dw).max(200);
        let frame = self.width.max(col);
        let lx = (0.5 * (frame - col) as f32) as i32;
        let cell = |w: i32| lx + (0.5 * (col - w) as f32) as i32;
        [(cell(tw), 4), (cell(dw), 17), (cell(200), 30)]
    }
    /// The footer's two buttons.
    fn footer(&self) -> [(i32, i32); 2] {
        let frame = self.width.max(308);
        let x = (0.5 * (frame - 308) as f32) as i32;
        let y = self.height - 33 + (0.5f32 * 13.0).round() as i32;
        [(x, y), (x + 158, y)]
    }
    /// A footer button's width: Open Folder shares its slot with Catalog when there is one.
    fn footer_w(&self, i: usize) -> i32 {
        match i {
            0 => open_folder_slot(0.0, self.catalog).0 as i32,
            _ => 150,
        }
    }
    /// The Catalog button, if it has one: x, y and width.
    fn catalog_button(&self) -> Option<(i32, i32, i32)> {
        let (footer_x, y) = self.footer()[0];
        let (x, width) = open_folder_slot(footer_x as f32, self.catalog).1?;
        Some((x as i32, y, width as i32))
    }
    /// Whether `(x, y)` is on the Catalog button.
    fn on_catalog(&self, x: f64, y: f64) -> bool {
        self.catalog_button().is_some_and(|(bx, by, width)| {
            x >= bx as f64 && y >= by as f64 && x < (bx + width) as f64 && y < (by + 20) as f64
        })
    }
    /// `repositionElements`.
    fn reposition(&mut self, m: &Measure) {
        let (sx, sy) = self.header(m)[2];
        self.search.x = sx;
        self.search.y = sy;
        let content = self.height - 49 - 33;
        let w = self.width;
        self.lists[0].update_size(200, content, w / 2 - 15 - 200, 49);
        self.lists[1].update_size(200, content, w / 2 + 15, 49);
    }
    /// `AbstractContainerEventHandler.setFocused` on the screen.
    fn set_focus(&mut self, f: Focus) {
        if self.focus == f {
            return;
        }
        match self.focus {
            Focus::Search => self.search.focused = false,
            Focus::List(i) => self.lists[i].focused = false,
            Focus::None | Focus::Button(_) => {}
        }
        if f == Focus::Search {
            self.search.focused = true;
        }
        self.focus = f;
    }
    fn shown(&self, side: usize) -> Vec<String> {
        let value = self.search.value.to_lowercase();
        let blank = self.search.value.trim().is_empty()
            && self.search.value.chars().all(char::is_whitespace);
        let list = if side == 1 {
            &self.model.selected
        } else {
            &self.model.unselected
        };
        list.iter()
            .filter(|p| {
                blank
                    || p.id.to_lowercase().contains(&value)
                    || self.info(&p.id).is_some_and(|i| {
                        i.title.plain().to_lowercase().contains(&value)
                            || i.description.plain().to_lowercase().contains(&value)
                    })
            })
            .map(|p| p.id.clone())
            .collect()
    }
    /// `TransferableSelectionList.updateList`.
    fn update_list(&mut self, side: usize, ids: Vec<String>, transferred: Option<&str>) {
        let l = &mut self.lists[side];
        l.entries.clear();
        l.selected = None;
        l.add(Row::Header, 13);
        l.set_selected(None);
        for id in ids {
            let hit = transferred == Some(id.as_str());
            self.lists[side].add(Row::Pack(id), 36);
            if hit {
                self.set_focus(Focus::List(side));
                let l = &mut self.lists[side];
                l.focused = true;
                let i = l.entries.len() - 1;
                l.set_selected(Some(i));
            }
        }
        let l = &mut self.lists[side];
        l.set_scroll(l.scroll);
    }
    /// `populateLists`: both lists, then again through the search filter.
    fn populate(&mut self, transferred: Option<&str>) {
        let all = |m: &SelectionModel, side: bool| -> Vec<String> {
            (if side { &m.selected } else { &m.unselected })
                .iter()
                .map(|p| p.id.clone())
                .collect()
        };
        self.update_list(1, all(&self.model, true), transferred);
        self.update_list(0, all(&self.model, false), transferred);
        self.filter(transferred);
    }
    /// `updateFilteredEntries`.
    fn filter(&mut self, transferred: Option<&str>) {
        let (sel, avail) = (self.shown(1), self.shown(0));
        self.update_list(1, sel, transferred);
        self.update_list(0, avail, transferred);
    }
    /// The pack's index in its model list.
    fn model_index(&self, side: usize, id: &str) -> Option<usize> {
        let list = if side == 1 {
            &self.model.selected
        } else {
            &self.model.unselected
        };
        list.iter().position(|p| p.id == id)
    }
    fn flags(&self, side: usize, id: &str) -> (bool, bool, bool, bool) {
        let Some(i) = self.model_index(side, id) else {
            return (false, false, false, false);
        };
        let s = side == 1;
        (
            self.model.can_select(s, i),
            self.model.can_unselect(s, i),
            self.model.can_move_up(s, i),
            self.model.can_move_down(s, i),
        )
    }
    fn overlay(&self, id: &str) -> bool {
        self.info(id).is_none_or(|p| !p.fixed || !p.required)
    }

    /// Whether a left click activates a footer or confirmation button.
    /// Pack entries and the search field do not play widget click sounds.
    pub fn button_at(&self, m: &Measure, x: f64, y: f64) -> bool {
        let buttons = if let Some(c) = &self.confirm {
            self.confirm_layout(m, c).2
        } else {
            self.footer()
        };
        (self.confirm.is_none() && self.on_catalog(x, y))
            || buttons.into_iter().enumerate().any(|(i, (bx, by))| {
                let w = if self.confirm.is_none() {
                    self.footer_w(i)
                } else {
                    150
                };
                x >= bx as f64 && y >= by as f64 && x < (bx + w) as f64 && y < (by + 20) as f64
            })
    }
    /// A left click (`Screen.mouseClicked`).
    pub fn click(&mut self, m: &Measure, x: f64, y: f64) -> Action {
        if self.confirm.is_some() {
            return self.confirm_click(m, x, y);
        }
        if let Some(action) = self.browser_click(m, x, y) {
            return action;
        }
        if self.search.contains(x, y) {
            self.search.click(m, x, false);
            self.set_focus(Focus::Search);
            return Action::None;
        }
        for side in 0..2 {
            if !self.lists[side].is_over(x, y) {
                continue;
            }
            let l = &self.lists[side];
            let scrolling = l.scrollable()
                && x >= l.scroll_bar_x() as f64
                && x <= (l.scroll_bar_x() + 6) as f64
                && y >= l.y as f64
                && y < l.bottom() as f64;
            // updateScrolling: a press on the scroller holds it.
            if scrolling {
                self.lists[side].held = Some(y);
                self.set_focus(Focus::List(side));
                return Action::None;
            }
            let l = &self.lists[side];
            let hit = l.entry_at(x as i32, y as i32);
            if let Some(i) = hit
                && let Some((id, bx, by)) = self.options_button(side, i)
                && d::inside((x as i32, y as i32), bx, by, OPTIONS_SIZE, OPTIONS_SIZE)
            {
                return Action::Options(id);
            }
            let mut took = false;
            if let Some(i) = hit {
                took = true;
                match l.entries[i].row.clone() {
                    Row::Header => {
                        let l = &mut self.lists[side];
                        l.focused = true;
                        l.set_selected(Some(i));
                    }
                    Row::Pack(id) => {
                        let current = self.entry_click(m, side, i, &id, x as i32, y as i32);
                        if self.lists[side]
                            .entries
                            .iter()
                            .any(|e| e.row == Row::Pack(id.clone()))
                        {
                            let l = &mut self.lists[side];
                            l.focused = true;
                            if current {
                                l.set_selected(Some(i));
                            }
                        }
                    }
                }
            }
            if took {
                self.set_focus(Focus::List(side));
            }
            return Action::None;
        }
        for (i, (bx, by)) in self.footer().into_iter().enumerate() {
            let w = self.footer_w(i);
            if x >= bx as f64 && y >= by as f64 && x < (bx + w) as f64 && y < (by + 20) as f64 {
                self.set_focus(Focus::Button(i));
                return if i == 0 {
                    Action::OpenFolder
                } else {
                    Action::Done
                };
            }
        }
        if self.on_catalog(x, y) {
            return Action::Catalog;
        }
        Action::None
    }
    /// `PackEntry.mouseClicked`; true when the entry clicked is still the
    /// list's own (nothing was repopulated).
    fn entry_click(
        &mut self,
        m: &Measure,
        side: usize,
        i: usize,
        id: &str,
        x: i32,
        y: i32,
    ) -> bool {
        if !self.overlay(id) {
            return true;
        }
        let e = &self.lists[side].entries[i];
        let (cx, cy) = (self.lists[side].row_left() + 2, e.y + 2);
        let (rx, ry) = (x - cx, y - cy);
        let (sel, unsel, up, down) = self.flags(side, id);
        let icon = (0..32).contains(&rx) && (0..32).contains(&ry);
        let left = (0..16).contains(&rx) && (0..32).contains(&ry);
        let top_right = (16..32).contains(&rx) && (0..16).contains(&ry);
        let bottom_right = (16..32).contains(&rx) && (16..32).contains(&ry);
        let index = self.model_index(side, id).unwrap_or(0);
        let s = side == 1;
        if sel && icon {
            if self
                .info(id)
                .is_some_and(|p| p.compat != Compat::Compatible)
            {
                self.open_confirm(id);
                return true;
            }
            self.model.activate(s, index, true);
        } else if unsel && left {
            self.model.activate(s, index, false);
        } else if up && top_right {
            self.model.move_by(s, index, true);
        } else if down && bottom_right {
            self.model.move_by(s, index, false);
        } else {
            return true;
        }
        self.changed = true;
        self.populate(Some(id));
        let _ = m;
        false
    }
    /// `handlePackSelection` of an incompatible pack: the ConfirmScreen
    /// (the pack screen loses its focus as `Gui.setScreen` clears it).
    fn open_confirm(&mut self, id: &str) {
        let compat = self.info(id).map_or(Compat::Unknown, |p| p.compat);
        self.set_focus(Focus::None);
        for l in &mut self.lists {
            l.focused = false;
        }
        self.confirm = Some(Confirm {
            id: id.to_owned(),
            title: tr("pack.incompatible.confirm.title"),
            message: tr(&format!("pack.incompatible.confirm.{}", compat.key())),
        });
    }
    /// The ConfirmScreen's layout: title, message lines and the two buttons.
    fn confirm_layout(
        &self,
        m: &Measure,
        c: &Confirm,
    ) -> ((i32, i32), (Vec<(Text, i32)>, i32, i32), [(i32, i32); 2]) {
        let max = self.width - 50;
        let lines = d::label_lines(m, &c.message, max, 15, &Style::default());
        let mw = d::label_width(&lines, max);
        let mh = lines.len() as i32 * 9;
        let tw = m.width(&c.title);
        let col = tw.max(mw).max(304);
        let total = 9 + 8 + mh + 8 + 36;
        let lx = (0.5 * (self.width - col) as f32) as i32;
        let ly = (0.5 * (self.height - total) as f32) as i32;
        let cell = |w: i32| lx + (0.5 * (col - w) as f32) as i32;
        let by = ly + 9 + 8 + mh + 8 + 16;
        let bx = cell(304);
        (
            (cell(tw), ly),
            (lines, cell(mw), ly + 17),
            [(bx, by), (bx + 154, by)],
        )
    }
    fn confirm_click(&mut self, m: &Measure, x: f64, y: f64) -> Action {
        let Some(c) = self.confirm.clone() else {
            return Action::None;
        };
        let (_, _, buttons) = self.confirm_layout(m, &c);
        for (i, (bx, by)) in buttons.into_iter().enumerate() {
            if x >= bx as f64 && y >= by as f64 && x < (bx + 150) as f64 && y < (by + 20) as f64 {
                // The callback: back to the pack screen (repositioned), then select.
                self.confirm = None;
                self.reposition(m);
                if i == 0
                    && let Some(index) = self.model_index(0, &c.id)
                {
                    self.model.activate(false, index, true);
                    self.changed = true;
                    self.populate(Some(&c.id));
                }
                return Action::None;
            }
        }
        Action::None
    }
    /// The focus, the lists' rows, scroll and selection (for debugging).
    pub fn debug(&self) -> String {
        format!(
            "{:?} {:?}",
            self.focus,
            self.lists
                .iter()
                .map(|l| (
                    l.scroll,
                    l.selected,
                    l.focused,
                    l.entries.iter().map(|e| e.y).collect::<Vec<_>>()
                ))
                .collect::<Vec<_>>()
        )
    }
    /// Whether the confirmation screen is shown.
    pub fn confirming(&self) -> bool {
        self.confirm.is_some()
    }
    /// Escape on the confirmation screen answers no.
    pub fn cancel_confirm(&mut self, m: &Measure) -> bool {
        if self.confirm.take().is_some() {
            self.reposition(m);
            return true;
        }
        false
    }
    /// The mouse wheel (`AbstractScrollArea.mouseScrolled`).
    /// The pointer moved with the button held: a held scrollbar follows it.
    pub fn drag(&mut self, y: f64) {
        for l in &mut self.lists {
            l.drag(y);
        }
    }
    /// `onRelease`.
    pub fn release(&mut self) {
        for l in &mut self.lists {
            l.held = None;
        }
    }
    pub fn scroll(&mut self, x: f64, y: f64, amount: f64) {
        if self.confirm.is_some() || self.search.contains(x, y) {
            return;
        }
        for l in &mut self.lists {
            if l.is_over(x, y) {
                l.set_scroll(l.scroll - amount * 18.0);
                return;
            }
        }
    }
    /// Typed text, when the search box has the focus.
    pub fn type_text(&mut self, m: &Measure, s: &str) {
        if self.browser.is_some() {
            self.browser_search.insert_text(m, s);
            return;
        }
        if self.confirm.is_none() && self.focus == Focus::Search && self.search.insert_text(m, s) {
            self.filter(None);
        }
    }
    /// Ctrl+A/C/V/X in the search box; false when it does not have the focus.
    pub fn shortcut(
        &mut self,
        m: &Measure,
        shortcut: crate::clipboard::EditShortcut,
        clipboard: &mut dyn crate::clipboard::Clipboard,
    ) -> bool {
        if !self.search_focused() {
            return false;
        }
        if self.search.shortcut(m, shortcut, clipboard) {
            self.filter(None);
        }
        true
    }
    /// Backspace in the search box.
    pub fn erase(&mut self, m: &Measure, count: isize) {
        if self.browser.is_some() {
            self.browser_search.delete_chars(m, -count);
            return;
        }
        if self.confirm.is_none()
            && self.focus == Focus::Search
            && self.search.delete_chars(m, -count)
        {
            self.filter(None);
        }
    }
    /// Whether `(x, y)` (GUI pixels) is on the focused search box.
    pub fn search_at(&self, x: f32, y: f32) -> bool {
        self.search_focused() && self.search.contains(f64::from(x), f64::from(y))
    }
    /// Keeps a browser icon, remembering it so [`Self::release_browser_icons`]
    /// can free it again. The installed packs' own icons are not touched.
    pub fn keep_browser_icon(&mut self, key: String, icon: Arc<[u8]>) {
        if self.icons.insert(key.clone(), icon).is_none() {
            self.browser_icons.push(key);
        }
    }
    /// Frees every icon the browser downloaded. Called when it closes: the
    /// pack lists behind it never drew these.
    pub fn release_browser_icons(&mut self) {
        for key in self.browser_icons.drain(..) {
            self.icons.remove(&key);
        }
        self.icons.shrink_to_fit();
    }
    /// Runs the browser's search on what is typed in its box. The screen
    /// calls this for the Search button and for Enter.
    pub fn browser_submit(&mut self) {
        let query = self.browser_search.value.clone();
        if let Some(browser) = &mut self.browser {
            browser.query = query;
            browser.search();
        }
    }
    /// Whether the browser's own search box has the keyboard, so the game
    /// sends it typing rather than treating it as a hotkey.
    pub fn browser_typing(&self) -> bool {
        // The browser has one text field, so it always takes typing. Clearing
        // it on a click elsewhere made typing after picking a filter or a card
        // go nowhere, and Search then submitted stale text.
        self.browser.is_some()
    }
    pub fn search_focused(&self) -> bool {
        // The browser's own box counts: the game routes typing by this.
        self.browser_typing() || (self.confirm.is_none() && self.focus == Focus::Search)
    }
    /// The search box, its text and selection (the on-screen keyboard's editor on Android).
    pub fn search_field(&self) -> &TextField {
        &self.search
    }
    /// The on-screen keyboard's editor's text, already through the box's filter, and selection
    /// in the focused search box (Android); the lists filter again when the text changed.
    pub fn set_search(&mut self, m: &Measure, value: &str, cursor: usize, anchor: usize) {
        if !self.search_focused() {
            return;
        }
        let changed = value != self.search.value;
        if changed {
            self.search.set_value(m, value);
        }
        self.search.move_cursor_to(m, anchor, false);
        self.search.move_cursor_to(m, cursor, true);
        if changed {
            self.filter(None);
        }
    }
    /// Resize (`Screen.init` on a new size: `repositionElements`).
    pub fn resize(&mut self, m: &Measure, width: i32, height: i32) {
        self.width = width;
        self.height = height;
        self.reposition(m);
    }
    /// `PackSelectionModel.commit`: the selection as options.txt stores it.
    pub fn commit(&self) -> Vec<String> {
        self.model.commit()
    }
    /// Points the icon blits of `draws` at the atlas's pack icon slots and
    /// writes the icons into them, one slot per icon drawn (vanilla registers a
    /// texture per pack). Icons past the last slot keep `unknown_pack`.
    pub fn bind_icons(&self, draws: &mut [Draw], atlas: &HudAtlas, patches: &mut Vec<Patch>) {
        bind_icon_slots(&self.icons, draws, atlas, patches);
    }

    /// The shown screen's calls (`Screen.extractRenderState`); `blink_ms`
    /// is the time since the search box took the focus.
    pub fn draw(&self, m: &Measure, mouse: (i32, i32), blink_ms: u64, now_ms: i64) -> Vec<Draw> {
        let mut out = Vec::new();
        // PackSelectionScreen, or the ConfirmScreen over it (its title and
        // its message).
        crate::widgets::begin_screen(|| match &self.confirm {
            Some(c) => crate::widgets::ScreenInfo::new(
                "packs/confirm",
                crate::widgets::join_for_narration(&[&c.title.plain(), &c.message.plain()]),
            ),
            None => crate::widgets::ScreenInfo::new("packs", self.title().plain()),
        });
        if let Some(c) = &self.confirm {
            let ((tx, ty), (lines, mx, my), buttons) = self.confirm_layout(m, c);
            d::string_widget(&mut out, m, &c.title, tx, ty, 0);
            d::label(&mut out, &lines, mx, my, self.width - 50, true);
            for ((bx, by), key) in buttons.into_iter().zip(["gui.yes", "gui.no"]) {
                let hover = d::inside(mouse, bx, by, 150, 20);
                crate::widgets::widget_cursor(hover, true);
                d::button(&mut out, m, &tr(key), bx, by, 150, 20, true, hover, now_ms);
            }
            return out;
        }
        let [(tx, ty), (dx, dy), _] = self.header(m);
        d::string_widget(&mut out, m, &self.title(), tx, ty, 0);
        d::string_widget(
            &mut out,
            m,
            &drop_info(self.data).with_color(d::GRAY),
            dx,
            dy,
            0,
        );
        self.search.draw(&mut out, m, blink_ms, None);
        for side in 0..2 {
            self.draw_list(&mut out, m, side, mouse);
        }
        let open_folder = if self.catalog {
            tr(SHORT_OPEN_FOLDER)
        } else {
            tr("pack.openFolder")
        };
        self.draw_footer(&mut out, m, mouse, now_ms, [&open_folder, &tr("gui.done")]);
        self.draw_browser(&mut out, m, mouse, now_ms);
        if let Some((x, y, width)) = self.catalog_button() {
            let hover = d::inside(mouse, x, y, width, 20);
            crate::widgets::widget_cursor(hover, true);
            d::button(
                &mut out,
                m,
                &tr("Catalog"),
                x,
                y,
                width,
                20,
                true,
                hover,
                now_ms,
            );
        }
        out
    }
    /// The Add button and the screen it opens. `None` leaves the click to
    /// the vanilla screen beneath.
    fn browser_click(&mut self, m: &Measure, x: f64, y: f64) -> Option<Action> {
        if !self.browsing_allowed {
            return None;
        }
        let point = (x as i32, y as i32);
        if self.browser.is_some() {
            let (bx, by) = self.back_button();
            if d::inside(point, bx, by, BACK_W, BACK_H) {
                self.browser = None;
                self.browser_focus = false;
                // Back to the vanilla pack screen, which wants no backdrop.
                self.backdrop = Backdrop::None;
                self.release_browser_icons();
                return Some(Action::None);
            }
            let (qx, qy) = self.browser_search_box();
            if d::inside(point, qx, qy, BROWSER_SEARCH_W, 18) {
                self.browser_search.x = qx;
                self.browser_search.y = qy;
                self.browser_search.click(m, x, false);
                self.browser_focus = true;
                return Some(Action::None);
            }
            let (sx2, sy2) = self.browser_search_button();
            if d::inside(point, sx2, sy2, SEARCH_BTN_W, 18) {
                self.browser_submit();
                return Some(Action::None);
            }
            for i in 0..crate::pack_browser::FILTERS.len() as i32 {
                let (fx, fy, fw, fh) = self.filter_box(i);
                if d::inside(point, fx, fy, fw, fh) {
                    let query = self.browser_search.value.clone();
                    if let Some(browser) = &mut self.browser {
                        if !browser.filters.insert(i as usize) {
                            browser.filters.remove(&(i as usize));
                        }
                        // A filter is only meaningful once it is searched on.
                        browser.query = query;
                        browser.search();
                    }
                    return Some(Action::None);
                }
            }
            let fits = self.browser_row_count();
            let busy = self.browser.as_ref().is_some_and(|b| b.busy);
            let hits = self.browser.as_ref().map_or(0, |b| b.hits.len() as i32);
            for i in 0..hits.min(fits) {
                let (ix, iy) = self.install_button(i);
                if d::inside(point, ix, iy, INSTALL_W, BACK_H) {
                    if busy {
                        return Some(Action::None);
                    }
                    return Some(Action::BrowsePick(i as usize));
                }
            }
            // The screen is modal: nothing beneath it takes the click.
            return Some(Action::None);
        }
        let (bx, by) = self.add_button(m);
        if d::inside(point, bx, by, ADD_SIZE, ADD_SIZE) {
            let mut browser = crate::pack_browser::Browser::new();
            // Opens on the text already in the search box, so a player who
            // searched their own packs first keeps the term; it is then the
            // browser's box that carries it.
            browser.query = self.search.value.clone();
            browser.search();
            self.browser_search.set_value(m, &self.search.value);
            self.browser_focus = true;
            self.browser = Some(browser);
            // Horizon's own screen, so it may ask for the menu panorama.
            self.backdrop = Backdrop::Panorama;
            return Some(Action::None);
        }
        None
    }
    /// The Back button, top left of the browser.
    fn back_button(&self) -> (i32, i32) {
        (8, 8)
    }
    /// The browser's search box and the button beside it.
    fn browser_search_box(&self) -> (i32, i32) {
        let total = BROWSER_SEARCH_W + 4 + SEARCH_BTN_W;
        let left = BACK_W + 16;
        let centred = (self.width - total) / 2;
        (centred.max(left), 5)
    }
    fn browser_search_button(&self) -> (i32, i32) {
        let (x, y) = self.browser_search_box();
        (x + BROWSER_SEARCH_W + 4, y)
    }
    /// The Install button of row `i`.
    fn install_button(&self, i: i32) -> (i32, i32) {
        // Top right, beside the name. It used to sit bottom right, where the
        // description ran under it.
        let (cx, cy, cw, _) = self.card_box(i);
        (cx + cw - INSTALL_W - CARD_PAD, cy + CARD_PAD)
    }
    /// The browser's content column: centred, and never wider than it reads
    /// comfortably.
    fn browser_area(&self) -> (i32, i32, i32, i32) {
        let x = SIDEBAR_W + 6;
        let top = TOPBAR_H + 6;
        let w = (self.width - x - 6).max(120);
        let h = (self.height - top - 6).max(ROW_H);
        (x, top, w, h)
    }
    /// Two columns where there is room for them, otherwise one.
    fn browser_columns(&self) -> i32 {
        let (_, _, w, _) = self.browser_area();
        if w >= 360 { 2 } else { 1 }
    }
    /// The card at `i`: its box in the grid.
    fn card_box(&self, i: i32) -> (i32, i32, i32, i32) {
        let (px, py, pw, _) = self.browser_area();
        let cols = self.browser_columns();
        let cw = (pw - 6 * (cols - 1)) / cols;
        let (cx, cy) = (i % cols, i / cols);
        (px + cx * (cw + 6), py + cy * (ROW_H + 6), cw, ROW_H)
    }
    /// The filter row `i` in the sidebar.
    fn filter_box(&self, i: i32) -> (i32, i32, i32, i32) {
        (6, TOPBAR_H + 18 + i * FILTER_H, SIDEBAR_W - 12, FILTER_H)
    }
    /// How many rows fit the column.
    fn browser_row_count(&self) -> i32 {
        let (_, _, _, ph) = self.browser_area();
        (((ph + 6) / (ROW_H + 6)) * self.browser_columns()).max(0)
    }
    /// Horizon's Add button, and the screen it opens. Nothing is drawn
    /// unless the player turned `packBrowser` on, so the screen's vanilla
    /// parity is untouched by default.
    fn draw_browser(&self, out: &mut Vec<Draw>, m: &Measure, mouse: (i32, i32), now_ms: i64) {
        if !self.browsing_allowed {
            return;
        }
        let Some(browser) = &self.browser else {
            let (bx, by) = self.add_button(m);
            let hover = d::inside(mouse, bx, by, ADD_SIZE, ADD_SIZE);
            d::button(
                out,
                m,
                &tr("horizon.pack.add"),
                bx,
                by,
                ADD_SIZE,
                ADD_SIZE,
                true,
                hover,
                now_ms,
            );
            if hover {
                d::tooltip(out, m, &tr("horizon.pack.addInfo"), mouse);
            }
            return;
        };
        // Modal and opaque: vanilla's own menu background tiled over the
        // whole screen, then a wash, so none of the pack lists shows through.
        d::sprite(out, "gui/menu_background", 0, 0, self.width, self.height);
        d::fill(out, 0, 0, self.width, self.height, PANEL);
        // The sidebar of filters, and the bar across the top.
        d::fill(out, 0, 0, SIDEBAR_W, self.height, SIDEBAR_BG);
        d::fill(out, 0, 0, self.width, TOPBAR_H, SIDEBAR_BG);
        let (bx, by) = self.back_button();
        let back_hover = d::inside(mouse, bx, by, BACK_W, BACK_H);
        crate::widgets::declare_action(
            crate::widgets::Action::Back,
            [bx as f32, by as f32, BACK_W as f32, BACK_H as f32],
            true,
        );
        d::button(
            out,
            m,
            &tr("gui.back"),
            bx,
            by,
            BACK_W,
            BACK_H,
            true,
            back_hover,
            now_ms,
        );
        // The search row: its box and the button that runs it.
        let (qx, qy) = self.browser_search_box();
        let mut field = self.browser_search.clone();
        field.x = qx;
        field.y = qy;
        field.draw(out, m, 0, None);
        let (sbx, sby) = self.browser_search_button();
        d::button(
            out,
            m,
            &tr("horizon.pack.search"),
            sbx,
            sby,
            SEARCH_BTN_W,
            18,
            !browser.busy,
            d::inside(mouse, sbx, sby, SEARCH_BTN_W, 18),
            now_ms,
        );
        // The sidebar's heading and its filters.
        let heading = tr("horizon.pack.filters").with_style(&Style {
            bold: Some(true),
            ..Style::default()
        });
        d::string_widget(out, m, &heading, 6, TOPBAR_H + 5, 0);
        for (i, (key, _, _)) in crate::pack_browser::FILTERS.iter().enumerate() {
            let i = i as i32;
            let (fx, fy, fw, fh) = self.filter_box(i);
            let on = browser.filters.contains(&(i as usize));
            let hover = d::inside(mouse, fx, fy, fw, fh);
            if hover {
                d::fill(out, fx - 2, fy - 1, fx + fw + 2, fy + fh - 1, CARD_HOVER);
            }
            // A small box, filled when the filter is on.
            d::fill(out, fx, fy, fx + 7, fy + 7, 0xFF_44_4C_63u32 as i32);
            if on {
                d::fill(out, fx + 1, fy + 1, fx + 6, fy + 6, 0xFF_6C_C6_4Bu32 as i32);
            }
            let label = tr(key).with_color(if on { d::WHITE as u32 } else { d::GRAY });
            d::string_widget(out, m, &label, fx + 11, fy - 1, 0);
        }
        let (px, py, pw, ph) = self.browser_area();
        let message = if browser.busy && browser.installing.is_none() {
            Some(tr("horizon.pack.addWorking"))
        } else if let Some(status) = &browser.status {
            Some(Text::translate(
                "horizon.pack.addFailed",
                &[Text::literal(status.clone())],
            ))
        } else if browser.hits.is_empty() {
            Some(tr("horizon.pack.addNone"))
        } else {
            None
        };
        if let Some(message) = message {
            let lines = d::label_lines(
                m,
                &message.with_color(d::GRAY),
                pw - 8,
                6,
                &Style::default(),
            );
            d::label(out, &lines, px + 4, py + 20, pw - 8, true);
            return;
        }
        let fits = self.browser_row_count();
        for (i, hit) in browser.hits.iter().enumerate() {
            let i = i as i32;
            if i >= fits {
                break;
            }
            let (cx, cy, cw, ch) = self.card_box(i);
            if cy + ch > py + ph {
                break;
            }
            let over = d::inside(mouse, cx, cy, cw, ch);
            d::fill(
                out,
                cx,
                cy,
                cx + cw,
                cy + ch,
                if over { CARD_HOVER } else { CARD },
            );
            // The icon, once one has arrived: `bind_icons` swaps the texture
            // for the atlas slot it patched the PNG into.
            let texture = icon_texture(&hit.id);
            if self.icons.contains_key(&texture) {
                out.push(Draw::Blit {
                    texture,
                    x: cx + CARD_PAD,
                    y: cy + CARD_PAD,
                    w: ICON,
                    h: ICON,
                    u: 0.0,
                    v: 0.0,
                    src: [PACK_ICON_SIZE as i32, PACK_ICON_SIZE as i32],
                    tex: [PACK_ICON_SIZE as i32, PACK_ICON_SIZE as i32],
                    color: d::WHITE,
                });
            }
            // The name and author sit in the column between the icon and
            // the Install button; the description runs the card's full width
            // under both, so no two of them can overlap.
            let text_x = cx + CARD_PAD + ICON + CARD_PAD;
            let text_w = (cx + cw - CARD_PAD - INSTALL_W - CARD_PAD - text_x).max(20);
            let name = d::label_lines(
                m,
                &Text::literal(hit.title.clone()).with_style(&Style {
                    bold: Some(true),
                    ..Style::default()
                }),
                text_w,
                1,
                &Style::default(),
            );
            d::label(out, &name, text_x, cy + CARD_PAD + 1, text_w, false);
            if !hit.author.is_empty() {
                let author = d::label_lines(
                    m,
                    &Text::literal(hit.author.clone()).with_color(d::GRAY),
                    text_w,
                    1,
                    &Style::default(),
                );
                d::label(out, &author, text_x, cy + CARD_PAD + 12, text_w, false);
            }
            let body_w = (cw - 2 * CARD_PAD).max(20);
            let lines = d::label_lines(
                m,
                &Text::literal(hit.description.clone()).with_color(d::GRAY),
                body_w,
                2,
                &Style::default(),
            );
            // Below the icon, which is the tallest thing in the top row.
            d::label(
                out,
                &lines,
                cx + CARD_PAD,
                cy + CARD_PAD + ICON + 5,
                body_w,
                false,
            );
            let (ix, iy) = self.install_button(i);
            let done = browser.installed.contains(&(i as usize));
            let running = browser.installing == Some(i as usize);
            let label = if done {
                tr("horizon.pack.installed")
            } else if running {
                tr("horizon.pack.installing")
            } else {
                tr("horizon.pack.install")
            };
            // Drawn rather than the vanilla button sprite, so it can be the
            // green the design asks for.
            let hovered = d::inside(mouse, ix, iy, INSTALL_W, BACK_H);
            let face = if done {
                INSTALLED_GREEN
            } else if hovered && !browser.busy {
                GREEN_HOVER
            } else {
                GREEN
            };
            d::fill(out, ix, iy, ix + INSTALL_W, iy + BACK_H, GREEN_EDGE);
            d::fill(
                out,
                ix + 1,
                iy + 1,
                ix + INSTALL_W - 1,
                iy + BACK_H - 1,
                face,
            );
            let lw = m.width(&label);
            d::string_widget(
                out,
                m,
                &label,
                ix + (INSTALL_W - lw) / 2,
                iy + (BACK_H - 8) / 2,
                0,
            );
        }
    }
    /// The options button on the card of row `i` of list `side`, when its pack has
    /// Polytone options: the pack and the button's corner, at the card's right edge.
    fn options_button(&self, side: usize, i: usize) -> Option<(String, i32, i32)> {
        let l = &self.lists[side];
        let e = l.entries.get(i)?;
        let Row::Pack(id) = &e.row else { return None };
        if !self.with_options.contains(id) {
            return None;
        }
        let x = l.row_left() + l.entry_width() - OPTIONS_SIZE - 2;
        let y = e.y + (e.height - OPTIONS_SIZE) / 2;
        Some((id.clone(), x, y))
    }
    /// The options button of a card: a small button with a sliders glyph.
    fn draw_options_button(out: &mut Vec<Draw>, x: i32, y: i32, hover: bool) {
        crate::widgets::narratable(|| {
            crate::widgets::Narratable::button(
                tr("horizon.pack.options").plain(),
                [x as f32, y as f32, OPTIONS_SIZE as f32, OPTIONS_SIZE as f32],
                true,
            )
        });
        let sprite = if hover {
            "widget/button_highlighted"
        } else {
            "widget/button"
        };
        d::sprite(out, sprite, x, y, OPTIONS_SIZE, OPTIONS_SIZE);
        let (line, knob) = if hover {
            (0xFF_C6_C6_C6u32 as i32, -1)
        } else {
            (0xFF_A0_A0_A0u32 as i32, 0xFF_E0_E0_E0u32 as i32)
        };
        // Three sliders, their knobs at different places.
        for (row, at) in [(4, 8), (8, 4), (12, 9)] {
            d::fill(out, x + 3, y + row, x + 13, y + row + 1, line);
            d::fill(out, x + at, y + row - 1, x + at + 2, y + row + 2, knob);
        }
    }
    /// The Add button, just right of the search box.
    fn add_button(&self, m: &Measure) -> (i32, i32) {
        let (sx, sy) = self.header(m)[2];
        // The search box is 15 tall: centre the taller button on it.
        (sx + 204, sy - (ADD_SIZE - 15) / 2)
    }
    /// The footer's two buttons, "Open Pack Folder" and "Done", over their
    /// labels; a label wider than its button scrolls with the clock.
    fn draw_footer(
        &self,
        out: &mut Vec<Draw>,
        m: &Measure,
        mouse: (i32, i32),
        now_ms: i64,
        labels: [&Text; 2],
    ) {
        for (i, ((bx, by), label)) in self.footer().into_iter().zip(labels).enumerate() {
            let w = self.footer_w(i);
            let hover = d::inside(mouse, bx, by, w, 20);
            // The cursor follows the mouse; the highlight also keyboard focus.
            crate::widgets::widget_cursor(hover, true);
            if i == 1 && self.browser.is_none() {
                crate::widgets::declare_action(
                    crate::widgets::Action::Done,
                    [bx as f32, by as f32, 150.0, 20.0],
                    true,
                );
            }
            d::button(
                out,
                m,
                label,
                bx,
                by,
                w,
                20,
                true,
                hover || self.focus == Focus::Button(i),
                now_ms,
            );
            if i == 0 {
                crate::widgets::last_narratable(|n| {
                    n.hint = Some(tr("pack.folderInfo").plain());
                });
            }
            if i == 0 && hover {
                d::tooltip(out, m, &tr("pack.folderInfo"), mouse);
            }
        }
    }
    fn draw_list(&self, out: &mut Vec<Draw>, m: &Measure, side: usize, mouse: (i32, i32)) {
        let l = &self.lists[side];
        let hovered = if l.is_over(mouse.0 as f64, mouse.1 as f64) {
            l.entry_at(mouse.0, mouse.1)
        } else {
            None
        };
        let header = if l.selected_side {
            "pack.selected.title"
        } else {
            "pack.available.title"
        };
        // TransferableSelectionList: the row under the mouse, else the
        // selected one; the header narrates its title, a pack "Selected:
        // <title>".
        crate::widgets::narratable(|| {
            use crate::widgets::{ListKind, Narratable, Row as Narrated};
            let narrated = |i: usize| {
                let text = match &l.entries[i].row {
                    Row::Header => tr(header).plain(),
                    Row::Pack(id) => {
                        let title = self
                            .info(id)
                            .map_or_else(|| Text::literal(id.clone()), |p| p.title.clone());
                        Text::translate("narrator.select", &[title]).plain()
                    }
                };
                Narrated::new(i, text)
            };
            Narratable::list(
                ListKind::Object,
                l.entries.len(),
                hovered.map(narrated),
                l.selected.filter(|i| *i < l.entries.len()).map(narrated),
                [l.x as f32, l.y as f32, l.width as f32, l.height as f32],
            )
            .key(crate::widgets::key_of(&("packs", side)))
            .focused(l.focused)
        });
        let prefix = if self.in_world { "inworld_" } else { "" };
        let right = l.x + l.width;
        d::blit(
            out,
            &format!("textures/gui/{prefix}menu_list_background.png"),
            l.x,
            l.y,
            (right as f32, (l.bottom() + l.scroll as i32) as f32),
            l.width,
            l.height,
            [32, 32],
        );
        out.push(Draw::Scissor {
            x0: l.x.clamp(0, self.width),
            y0: l.y.clamp(0, self.height),
            x1: right.clamp(0, self.width),
            y1: l.bottom().clamp(0, self.height),
        });
        let (left, w) = (l.row_left(), l.entry_width());
        let narrow = if l.scrollable() { 6 } else { 0 };
        let mut tooltip = None;
        for (i, e) in l.entries.iter().enumerate() {
            if e.y + e.height < l.y || e.y > l.bottom() {
                continue;
            }
            if l.selected == Some(i) {
                let color = if l.focused { -1 } else { -8355712 };
                d::fill(out, left, e.y, left + w, e.y + e.height, color);
                d::fill(
                    out,
                    left + 1,
                    e.y + 1,
                    left + w - 1,
                    e.y + e.height - 1,
                    -16777216,
                );
            }
            let (cx, cy) = (left + 2, e.y + 2);
            match &e.row {
                Row::Header => {
                    let t = tr(header).with_style(&Style {
                        underlined: Some(true),
                        bold: Some(true),
                        ..Style::default()
                    });
                    let tw = m.width(&t);
                    d::text(
                        out,
                        t,
                        left + w / 2 - tw / 2,
                        cy + (e.height - 4) / 2 - 4,
                        -1,
                        true,
                    );
                }
                Row::Pack(id) => {
                    let Some(p) = self.info(id) else { continue };
                    if p.compat != Compat::Compatible {
                        d::fill(
                            out,
                            cx - 1,
                            cy - 1,
                            cx + w - 4 + 1,
                            cy + e.height - 4 + 1,
                            -8978432,
                        );
                    }
                    let icon = if p.icon.is_some() {
                        icon_texture(id)
                    } else {
                        "textures/misc/unknown_pack.png".into()
                    };
                    d::blit(out, &icon, cx, cy, (0.0, 0.0), 32, 32, [32, 32]);
                    let (mut name, (mut desc, mut desc_style)) =
                        (p.title.clone(), p.extended_description());
                    let focus_hover = l.selected == Some(i) && l.focused;
                    if self.overlay(id) && (hovered == Some(i) || focus_hover) {
                        d::fill(out, cx, cy, cx + 32, cy + 32, -1601138544);
                        let (rx, ry) = (mouse.0 - cx, mouse.1 - cy);
                        if p.compat != Compat::Compatible {
                            name = tr("pack.incompatible");
                            desc = tr(&format!("pack.incompatible.{}", p.compat.key()))
                                .with_color(d::GRAY);
                            desc_style = Style::color(d::GRAY);
                        }
                        let (sel, unsel, up, down) = self.flags(side, id);
                        let quarter = |x0: i32, x1: i32, y0: i32, y1: i32| {
                            (x0..x1).contains(&rx) && (y0..y1).contains(&ry)
                        };
                        let mut arrow = |name: &str, on: bool| {
                            let s = if on {
                                format!("transferable_list/{name}_highlighted")
                            } else {
                                format!("transferable_list/{name}")
                            };
                            d::sprite(out, &s, cx, cy, 32, 32);
                        };
                        if sel {
                            arrow("select", quarter(0, 32, 0, 32));
                        } else {
                            if unsel {
                                arrow("unselect", quarter(0, 16, 0, 32));
                            }
                            if up {
                                arrow("move_up", quarter(16, 32, 0, 16));
                            }
                            if down {
                                arrow("move_down", quarter(16, 32, 16, 32));
                            }
                        }
                    }
                    let mut max = 157 - narrow;
                    if let Some((_, bx, by)) = self.options_button(side, i) {
                        let hover = hovered == Some(i)
                            && d::inside(mouse, bx, by, OPTIONS_SIZE, OPTIONS_SIZE);
                        Self::draw_options_button(out, bx, by, hover);
                        if hover {
                            tooltip = Some(tr("horizon.pack.optionsInfo"));
                        }
                        max -= OPTIONS_SIZE + 2;
                    }
                    d::string_widget(out, m, &name, cx + 34, cy + 1, max);
                    let lines = d::label_lines(m, &desc, max, 2, &desc_style);
                    d::label(out, &lines, cx + 34, cy + 12, max, false);
                }
            }
        }
        out.push(Draw::NoScissor);
        if let Some(t) = tooltip {
            d::tooltip(out, m, &t, mouse);
        }
        d::blit(
            out,
            &format!("textures/gui/{prefix}header_separator.png"),
            l.x,
            l.y - 2,
            (0.0, 0.0),
            l.width,
            2,
            [32, 2],
        );
        d::blit(
            out,
            &format!("textures/gui/{prefix}footer_separator.png"),
            l.x,
            l.bottom(),
            (0.0, 0.0),
            l.width,
            2,
            [32, 2],
        );
        if l.scrollable() {
            let sh = l.scroller_height().clamp(32, l.height - 8);
            let sy = (l.scroll as i32 * (l.height - sh) / l.max_scroll() + l.y).max(l.y);
            d::sprite(
                out,
                "widget/scroller_background",
                l.scroll_bar_x(),
                l.y,
                6,
                l.height,
            );
            d::sprite(out, "widget/scroller", l.scroll_bar_x(), sy, 6, sh);
        }
    }
}

#[cfg(test)]
mod icon_tests {
    use super::*;

    fn png(w: u32, h: u32, rgba: &[u8]) -> Vec<u8> {
        let mut out = Vec::new();
        let mut encoder = png::Encoder::new(&mut out, w, h);
        encoder.set_color(png::ColorType::Rgba);
        encoder.set_depth(png::BitDepth::Eight);
        encoder
            .write_header()
            .unwrap()
            .write_image_data(rgba)
            .unwrap();
        out
    }
    fn pack(id: &str, icon: Option<Arc<[u8]>>) -> PackInfo {
        PackInfo {
            id: id.into(),
            title: Text::literal(id),
            description: Text::literal(""),
            description_style: Style::default(),
            source: Source::BuiltIn,
            compat: Compat::Compatible,
            icon,
            required: false,
            position: Position::Top,
            fixed: false,
        }
    }

    /// Any size stretches over the whole square, nearest texels, as the
    /// icon texture is sampled into its 32x32 blit.
    #[test]
    fn icons_stretch_to_the_slot_by_nearest_texels() {
        let (red, blue) = ([255, 0, 0, 255], [0, 0, 255, 128]);
        let icon = load_icon(&png(2, 1, &[red, blue].concat())).unwrap();
        let side = PACK_ICON_SIZE as usize;
        assert_eq!(icon.len(), side * side * 4);
        let at = |x: usize, y: usize| &icon[(y * side + x) * 4..][..4];
        assert_eq!((at(0, 0), at(side / 2 - 1, side - 1)), (&red[..], &red[..]));
        assert_eq!(
            (at(side / 2, 0), at(side - 1, side - 1)),
            (&blue[..], &blue[..])
        );
        assert!(load_icon(b"not a png").is_none());
    }

    /// A pack with Polytone options carries an options button on its card, which opens
    /// that pack's options and nothing else; a pack without options has none.
    #[test]
    fn a_card_with_options_opens_its_own_pack_options() {
        let atlas = crate::hud::HudAtlas::build(
            &horizon_assets::resource_source::ResourceSource::directory(
                "/nonexistent/horizon-test-assets".into(),
            ),
        )
        .unwrap();
        let m = Measure(&atlas.font);
        let packs = vec![pack("file/Configurable", None), pack("file/Plain", None)];
        let mut screen = PackScreen::new(&m, tr("resourcePack.title"), 480, 320, false, packs, &[]);
        screen.with_options.insert("file/Configurable".into());
        let row = |screen: &PackScreen, id: &str| {
            screen.lists[0]
                .entries
                .iter()
                .position(|e| e.row == Row::Pack(id.into()))
                .unwrap()
        };
        assert!(
            screen
                .options_button(0, row(&screen, "file/Plain"))
                .is_none()
        );
        let (id, bx, by) = screen
            .options_button(0, row(&screen, "file/Configurable"))
            .unwrap();
        assert_eq!(id, "file/Configurable");
        let (cx, cy) = (bx + OPTIONS_SIZE / 2, by + OPTIONS_SIZE / 2);
        // Hovered, it explains itself.
        let draws = screen.draw(&m, (cx, cy), 0, 0);
        assert!(draws.iter().any(|d| matches!(d, Draw::Tooltip { .. })));
        assert_eq!(
            screen.click(&m, cx as f64, cy as f64),
            Action::Options("file/Configurable".into())
        );
        // The press opened the options, it did not move the pack.
        assert!(screen.commit().is_empty());
    }

    /// Programmer Art and High Contrast draw their own `pack.png`; a pack
    /// without one keeps `unknown_pack`.
    #[test]
    fn drawn_icons_take_atlas_slots() {
        let atlas = crate::hud::HudAtlas::build(
            &horizon_assets::resource_source::ResourceSource::directory(
                (std::path::Path::new("/nonexistent/horizon-test-assets")).to_owned(),
            ),
        )
        .unwrap();
        let m = Measure(&atlas.font);
        let dirt = load_icon(&png(1, 1, &[134, 96, 67, 255])).unwrap();
        let contrast = load_icon(&png(1, 1, &[0, 0, 0, 255])).unwrap();
        let packs = vec![
            pack("programmer_art", Some(dirt.clone())),
            pack("high_contrast", Some(contrast.clone())),
            pack("file/Iconless", None),
        ];
        let screen = PackScreen::new(&m, tr("resourcePack.title"), 480, 320, false, packs, &[]);
        let mut draws = screen.draw(&m, (0, 0), 0, 0);
        let mut patches = Vec::new();
        screen.bind_icons(&mut draws, &atlas, &mut patches);
        let icons: Vec<&str> = draws
            .iter()
            .filter_map(|d| match d {
                Draw::Blit { texture, .. } if texture.contains("pack") => Some(texture.as_str()),
                _ => None,
            })
            .collect();
        // The list shows them sorted by id.
        assert_eq!(
            icons,
            [
                "textures/misc/unknown_pack.png",
                "horizon/pack-icon0",
                "horizon/pack-icon1"
            ]
        );
        assert_eq!(patches.len(), 2);
        for (i, (patch, icon)) in patches.iter().zip([&contrast, &dirt]).enumerate() {
            let rect = atlas.sprites[&format!("horizon/pack-icon{i}")];
            assert_eq!(
                (patch.x, patch.y, patch.width, patch.height),
                (
                    (rect.u0 * atlas.width as f32).round() as u32,
                    (rect.v0 * atlas.height as f32).round() as u32,
                    PACK_ICON_SIZE,
                    PACK_ICON_SIZE
                )
            );
            assert_eq!(&patch.rgba[..], &icon[..]);
        }
    }
}

#[cfg(test)]
mod click_sound_tests {
    use super::*;

    #[test]
    fn a_cards_parts_do_not_overlap_each_other() {
        let atlas = crate::hud::HudAtlas::build(
            &horizon_assets::resource_source::ResourceSource::directory(
                (std::path::Path::new("/nonexistent/horizon-test-assets")).to_owned(),
            ),
        )
        .unwrap();
        let m = Measure(&atlas.font);
        // Both a wide window (two columns) and a narrow one (one column).
        for (w, h) in [(480, 320), (260, 320)] {
            let mut screen =
                PackScreen::new(&m, tr("resourcePack.title"), w, h, false, Vec::new(), &[]);
            screen.browsing_allowed = true;
            let (cx, cy, cw, ch) = screen.card_box(0);
            let (ix, iy) = screen.install_button(0);
            // Install stays inside its card.
            assert!(
                ix >= cx && ix + INSTALL_W <= cx + cw,
                "install escapes the card"
            );
            assert!(
                iy >= cy && iy + BACK_H <= cy + ch,
                "install escapes the card"
            );
            // The name column ends before Install begins, so the two cannot
            // be drawn over one another.
            let text_x = cx + CARD_PAD + ICON + CARD_PAD;
            let text_w = (cx + cw - CARD_PAD - INSTALL_W - CARD_PAD - text_x).max(20);
            assert!(
                text_x + text_w <= ix || text_w == 20,
                "the name column runs under Install"
            );
            // The description starts below the icon rather than across it.
            let description_top = cy + CARD_PAD + ICON + 5;
            assert!(
                description_top >= cy + CARD_PAD + ICON,
                "text over the icon"
            );
            // And it still fits in the card with both its lines.
            assert!(description_top + 18 <= cy + ch, "the description overflows");
        }
    }

    #[test]
    fn the_browsers_search_button_submits_what_was_typed() {
        let atlas = crate::hud::HudAtlas::build(
            &horizon_assets::resource_source::ResourceSource::directory(
                (std::path::Path::new("/nonexistent/horizon-test-assets")).to_owned(),
            ),
        )
        .unwrap();
        let m = Measure(&atlas.font);
        let mut screen = PackScreen::new(
            &m,
            tr("resourcePack.title"),
            480,
            320,
            false,
            Vec::new(),
            &[],
        );
        screen.browsing_allowed = true;
        // The Add button opens the browser.
        let (ax, ay) = screen.add_button(&m);
        screen.click(&m, f64::from(ax) + 2.0, f64::from(ay) + 2.0);
        assert!(screen.browser.is_some(), "the Add button opens the browser");
        // Typing reaches the browser's own box, not the pack filter.
        screen.type_text(&m, "blue");
        assert_eq!(screen.browser_search.value, "blue");
        assert_eq!(screen.search.value, "", "the pack filter is left alone");
        // The Search button sends it to the browser.
        let (sx, sy) = screen.browser_search_button();
        screen.click(&m, f64::from(sx) + 2.0, f64::from(sy) + 2.0);
        assert_eq!(
            screen.browser.as_ref().map(|b| b.query.as_str()),
            Some("blue"),
            "the Search button submits the box's text"
        );
        // The box and the button must not overlap, or one eats the other's
        // clicks.
        let (qx, _) = screen.browser_search_box();
        assert!(sx >= qx + BROWSER_SEARCH_W, "{sx} overlaps the box at {qx}");
    }

    #[test]
    fn only_footer_and_confirmation_buttons_request_a_click_sound() {
        let atlas = crate::hud::HudAtlas::build(
            &horizon_assets::resource_source::ResourceSource::directory(
                (std::path::Path::new("/nonexistent/horizon-test-assets")).to_owned(),
            ),
        )
        .unwrap();
        let m = Measure(&atlas.font);
        let title = tr("resourcePack.title");
        let mut screen = PackScreen::new(&m, title, 480, 320, false, Vec::new(), &[]);
        assert!(!screen.button_at(&m, 0.0, 0.0));
        assert!(!screen.button_at(
            &m,
            screen.search.x as f64 + 1.0,
            screen.search.y as f64 + 1.0
        ));
        let buttons = screen.footer();
        for (i, (x, y)) in buttons.into_iter().enumerate() {
            assert!(screen.button_at(&m, x as f64 + 1.0, y as f64 + 1.0));
            assert!(!screen.button_at(&m, (x + 150) as f64, (y + 20) as f64));
            assert_eq!(
                screen.click(&m, x as f64 + 1.0, y as f64 + 1.0),
                if i == 0 {
                    Action::OpenFolder
                } else {
                    Action::Done
                }
            );
        }
        screen.confirm = Some(Confirm {
            id: "incompatible".into(),
            title: Text::literal("Confirm"),
            message: Text::literal("Use this pack?"),
        });
        let buttons = screen
            .confirm_layout(&m, screen.confirm.as_ref().unwrap())
            .2;
        for (x, y) in buttons {
            assert!(screen.button_at(&m, x as f64 + 1.0, y as f64 + 1.0));
        }
        assert!(!screen.button_at(
            &m,
            screen.footer()[0].0 as f64 + 1.0,
            screen.footer()[0].1 as f64 + 1.0
        ));
        let (x, y) = buttons[1];
        assert_eq!(
            screen.click(&m, x as f64 + 1.0, y as f64 + 1.0),
            Action::None
        );
        assert!(!screen.confirming());
    }
}

#[cfg(test)]
mod catalog_button_tests {
    use super::*;
    use std::path::Path;

    fn atlas() -> HudAtlas {
        HudAtlas::build(&horizon_assets::resource_source::ResourceSource::directory(
            Path::new("/nonexistent/horizon-test-assets").to_path_buf(),
        ))
        .unwrap()
    }

    #[test]
    fn it_takes_the_right_half_of_open_folders_slot_at_a_phones_gui_sizes() {
        let atlas = atlas();
        let m = Measure(&atlas.font);
        for (w, h) in [(427, 240), (533, 240), (600, 270), (800, 360), (1200, 540)] {
            let packs = Vec::new();
            let mut screen = PackScreen::new(&m, tr("resourcePack.title"), w, h, false, packs, &[]);
            screen.catalog = true;
            let (x, y, width) = screen.catalog_button().expect("room for it");
            let [(footer_x, footer_y), (done_x, _)] = screen.footer();
            assert_eq!(y, footer_y, "on the footer's row at {w}x{h}");
            assert!(
                x >= footer_x + screen.footer_w(0),
                "clear of Open Pack Folder at {w}x{h}"
            );
            assert!(x + width <= footer_x + 150, "inside the slot at {w}x{h}");
            assert!(x + width < done_x, "clear of Done at {w}x{h}");
            assert!(y >= screen.lists[0].bottom(), "below the lists at {w}x{h}");
            assert!(screen.button_at(&m, x as f64 + 1.0, y as f64 + 1.0));
            assert_eq!(
                screen.click(&m, x as f64 + 1.0, y as f64 + 1.0),
                Action::Catalog
            );
        }
    }

    #[test]
    fn the_labels_fit_half_a_button() {
        let atlas = atlas();
        let m = Measure(&atlas.font);
        for label in [SHORT_OPEN_FOLDER, "Catalog"] {
            assert!(m.width(&tr(label)) <= HALF_BUTTON as i32 - 4, "{label}");
        }
    }

    #[test]
    fn the_slot_splits_in_two_halves_with_a_gap_and_keeps_its_width() {
        assert_eq!(open_folder_slot(100.0, false), (150.0, None));
        let (open, catalog) = open_folder_slot(100.0, true);
        let (x, width) = catalog.unwrap();
        assert_eq!((open, width), (73.0, 73.0));
        assert_eq!(x, 177.0);
        // The same 150 from the left of Open Folder to the right of Catalog.
        assert_eq!(x + width, 100.0 + 150.0);
        assert!(x - (100.0 + open) > 0.0);
    }

    #[test]
    fn a_screen_without_it_draws_nothing_there_and_a_click_there_is_nothing() {
        let atlas = atlas();
        let m = Measure(&atlas.font);
        let packs = Vec::new();
        let mut screen = PackScreen::new(&m, tr("resourcePack.title"), 800, 360, false, packs, &[]);
        let (x, y) = (screen.footer()[0].0 + 77, screen.footer()[0].1);
        let drawn_at = |screen: &PackScreen| {
            screen
                .draw(&m, (0, 0), 0, 0)
                .iter()
                .any(|d| matches!(d, Draw::Sprite { x: dx, y: dy, .. } if (*dx, *dy) == (x, y)))
        };
        assert!(!drawn_at(&screen));
        // Open Folder keeps its whole button.
        assert_eq!(
            screen.click(&m, x as f64 + 1.0, y as f64 + 1.0),
            Action::OpenFolder
        );
        screen.catalog = true;
        assert!(drawn_at(&screen));
        assert_eq!(
            screen.click(&m, x as f64 + 1.0, y as f64 + 1.0),
            Action::Catalog
        );
        // Open Folder's half still opens the folder.
        let (fx, fy) = screen.footer()[0];
        assert_eq!(
            screen.click(&m, fx as f64 + 1.0, fy as f64 + 1.0),
            Action::OpenFolder
        );
    }

    #[test]
    fn a_confirmation_over_the_screen_hides_it() {
        let atlas = atlas();
        let m = Measure(&atlas.font);
        let packs = Vec::new();
        let mut screen = PackScreen::new(&m, tr("resourcePack.title"), 800, 360, false, packs, &[]);
        screen.catalog = true;
        screen.confirm = Some(Confirm {
            id: "incompatible".into(),
            title: Text::literal("Confirm"),
            message: Text::literal("Use this pack?"),
        });
        let (x, y, _) = screen.catalog_button().unwrap();
        assert!(!screen.button_at(&m, x as f64 + 1.0, y as f64 + 1.0));
        assert_eq!(
            screen.click(&m, x as f64 + 1.0, y as f64 + 1.0),
            Action::None
        );
    }

    #[test]
    fn a_phones_line_names_the_folder_of_the_build_it_is() {
        let info = |data, folder: &str| phone_drop_info(data, Some(Path::new(folder)));
        assert_eq!(
            info(false, "/storage/emulated/0/Starling"),
            "Put packs in Starling/resourcepacks"
        );
        assert_eq!(
            info(false, "/storage/emulated/0/StarlingPreview"),
            "Put packs in StarlingPreview/resourcepacks"
        );
        assert_eq!(
            info(true, "/storage/emulated/0/StarlingPreview"),
            "Put data packs in StarlingPreview/datapacks, mods in StarlingPreview/horizon-mods"
        );
        // Another user's storage: the whole path, the root isn't what a file manager opens on.
        assert_eq!(
            info(false, "/storage/emulated/10/Starling"),
            "Put packs in /storage/emulated/10/Starling/resourcepacks"
        );
    }

    #[test]
    fn a_game_in_the_apps_own_files_points_at_the_folder_button() {
        assert_eq!(
            phone_drop_info(false, None),
            "In the app's own files: Open Pack Folder to reach them"
        );
    }
}

#[cfg(test)]
mod footer_label_tests {
    use super::*;
    use crate::lang::{self, Language};

    /// The footer drawn with these labels (no global language involved) and
    /// the footer buttons' positions.
    fn footer(
        atlas: &HudAtlas,
        open_folder: &Text,
        done: &Text,
        now_ms: i64,
    ) -> (Vec<Draw>, [(i32, i32); 2]) {
        let m = Measure(&atlas.font);
        let screen = PackScreen::new(&m, Text::literal("Packs"), 480, 320, false, Vec::new(), &[]);
        let mut out = Vec::new();
        screen.draw_footer(&mut out, &m, (0, 0), now_ms, [open_folder, done]);
        (out, screen.footer())
    }
    /// Every label drawn in `[bx + 2, bx + 148] x [by, by + 20]` of its button:
    /// the scissor of a scrolling one is that box, and the text sits between
    /// the scissor's calls.
    fn assert_labels_stay_in_their_buttons(draws: &[Draw], buttons: &[(i32, i32)]) -> usize {
        let mut scissors = 0;
        let mut open = None;
        let mut button = 0;
        for d in draws {
            match d {
                Draw::Sprite { x, y, .. } => {
                    button = buttons.iter().position(|b| *b == (*x, *y)).unwrap();
                }
                Draw::Scissor { x0, y0, x1, y1 } => {
                    let (bx, by) = buttons[button];
                    assert_eq!([*x0, *y0, *x1, *y1], [bx + 2, by, bx + 148, by + 20]);
                    assert!(open.replace(()).is_none());
                    scissors += 1;
                }
                Draw::NoScissor => assert!(open.take().is_some()),
                _ => {}
            }
        }
        assert!(open.is_none());
        scissors
    }

    /// The Resource Packs footer with a label wider than its 150 px button
    /// does not panic and scrolls; the short "Done" keeps its centre.
    #[test]
    fn a_footer_label_wider_than_its_button_scrolls() {
        let atlas = crate::hud::HudAtlas::build(
            &horizon_assets::resource_source::ResourceSource::directory(
                (std::path::Path::new("/nonexistent/horizon-test-assets")).to_owned(),
            ),
        )
        .unwrap();
        let m = Measure(&atlas.font);
        let wide = Text::literal("Otvori papku s paketami resursov, i jos nesto");
        assert!(m.width(&wide) > 146);
        let (draws, buttons) = footer(&atlas, &wide, &Text::literal("Done"), 0);
        assert_eq!(assert_labels_stay_in_their_buttons(&draws, &buttons), 1);
        // The clock moves it.
        let x = |draws: &[Draw]| {
            draws
                .iter()
                .find_map(|d| match d {
                    Draw::Text { x, .. } => Some(*x),
                    _ => None,
                })
                .unwrap()
        };
        let (later, _) = footer(&atlas, &wide, &Text::literal("Done"), 2000);
        assert_ne!(x(&draws), x(&later));
        // Both too wide: both scroll.
        let (draws, buttons) = footer(&atlas, &wide, &wide, 0);
        assert_eq!(assert_labels_stay_in_their_buttons(&draws, &buttons), 2);
    }

    /// The real language files: the Resource Packs footer in each of the 143
    /// languages draws without a panic, and in the ones whose "Open Pack
    /// Folder" is wider than the button (Afrikaans and Macedonian among them,
    /// the crash of #6129) it scrolls. A local `Language` per file: the global
    /// language stays as it was.
    #[test]
    #[ignore = "requires prepared language data in HORIZON_TEST_RESOURCES or .local/horizon-client/26.3"]
    fn the_footer_draws_in_every_language_file() {
        let root = std::env::var_os("HORIZON_TEST_RESOURCES")
            .map(std::path::PathBuf::from)
            .unwrap_or_else(|| {
                std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
                    .join("../../.local/horizon-client/26.3")
            });
        let atlas = crate::hud::HudAtlas::build(
            &horizon_assets::resource_source::ResourceSource::directory(root.to_path_buf()),
        )
        .unwrap();
        let m = Measure(&atlas.font);
        let before = lang::code();
        let mut codes: Vec<String> = std::fs::read_dir(root.join("assets/minecraft/lang"))
            .unwrap()
            .filter_map(|e| {
                let name = e.ok()?.file_name().into_string().ok()?;
                name.strip_suffix(".json").map(str::to_owned)
            })
            .collect();
        codes.sort();
        assert!(codes.len() >= 143, "{}", codes.len());
        let mut scrolling = Vec::new();
        for code in &codes {
            let language = Language::load(&[&root], code);
            let label = |key| Text::literal(language.get(key).unwrap_or(key));
            let (open_folder, done) = (label("pack.openFolder"), label("gui.done"));
            for now_ms in [0, 700, 1300, 5000] {
                let (draws, buttons) = footer(&atlas, &open_folder, &done, now_ms);
                let n = assert_labels_stay_in_their_buttons(&draws, &buttons);
                assert_eq!(
                    n,
                    [&open_folder, &done]
                        .iter()
                        .filter(|t| m.width(t) > 146)
                        .count(),
                    "{code}"
                );
                if now_ms == 0 && n > 0 {
                    scrolling.push(code.as_str());
                }
            }
        }
        for code in ["af_za", "mk_mk"] {
            assert!(scrolling.contains(&code), "{code} not in {scrolling:?}");
        }
        assert_eq!(lang::code(), before, "the global language was left alone");
    }
}
