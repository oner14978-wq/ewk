# Cat Launcher — contas offline (etapa 1, NÃO compilada)

Adicionado: `launcher/src/offline_accounts.rs` (registrado em `launcher/src/lib.rs`).
Faz: criar/selecionar/excluir várias contas, nome validado (3–16, letras/dígitos/_),
UUID offline igual ao do Minecraft (MD5 de "OfflinePlayer:<nome>"), skin e capa locais
por perfil, gravação em `offline_accounts.json` + `offline/<uuid>/`. Sem rede, sem token.
Testes unitários incluídos (rodar: `cd launcher && cargo test offline_accounts`).

Ainda NÃO feito (precisa de compilador): ligar às telas (main.rs, glass_account.rs),
tirar o login Microsoft (account.rs, microsoft.rs, owner_page.rs, wardrobe*, cli.rs, mcp.rs,
crate starling-account), passar nome/UUID/skin ao jogo e o APK.
